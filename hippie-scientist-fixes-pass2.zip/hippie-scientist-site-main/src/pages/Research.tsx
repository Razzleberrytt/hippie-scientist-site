import React from 'react'
import { motion } from '@/lib/motion'
import NeuroHerbGraph from '../components/NeuroHerbGraph'
import Meta from '../components/Meta'

const Research: React.FC = () => {
 return (
 <>
 <Meta
 title='Research - The Hippie Scientist'
 description='Latest research in psychedelic science and consciousness studies.'
 path='/research'
 />

 <div className='min-h-screen px-4 pt-20'>
 <div className='mx-auto max-w-7xl'>
 <motion.div
 initial={{ opacity: 0, y: 20 }}
 animate={{ opacity: 1, y: 0 }}
 transition={{ duration: 0.8 }}
 className='mb-20 text-center'
 >
 <h1 className='gradient-text mb-6 text-5xl font-bold md:text-6xl'>Research</h1>
 <p className='text-white/70 mx-auto max-w-3xl text-xl'>
 Exploring the frontiers of consciousness and psychedelic science
 </p>
 </motion.div>

 <div className='glass-card p-8'>
 <h2 className='mb-6 text-center text-3xl font-bold text-white'>Current Studies</h2>
 <ul className='text-white/70 mx-auto mb-6 max-w-xl list-disc space-y-2 pl-5 text-left'>
 <li>Clinical trials evaluating psychedelic-assisted therapy</li>
 <li>Neuroimaging projects exploring brain connectivity</li>
 <li>Longitudinal surveys on integration practices</li>
 </ul>
 <p className='text-white/70 text-center'>
 This list highlights a few ongoing areas of investigation. Check back regularly for
 detailed summaries and links to published papers.
 </p>
 <div className='mt-8'>
 <NeuroHerbGraph />
 </div>
 </div>
 </div>
 </div>
 </>
 )
}

export default Research
