/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly MODE: string
  readonly DEV: boolean
  readonly PROD: boolean
  readonly BASE_URL: string
  readonly VITE_ENABLE_ANALYTICS_ROUTE?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
