---
title: "Kanna (Sceletium) for Mood and Focus"
date: "2024-05-10"
slug: "kanna-mood-focus"
excerpt: "How traditional Sceletium extracts may lift mood and sharpen attention without overstimulation."
tags: ["kanna", "mood", "focus"]
---

Kanna, or *Sceletium tortuosum*, has long been chewed, smoked, and brewed across southern Africa for its calming lift. Today the succulent is finding a new audience among people who want gentle emotional buoyancy without losing clarity. This guide explores how kanna works, what the research says, and how to approach dosage and sourcing responsibly.

## A Brief History of Sceletium Use

Oral histories from the Khoisan and other indigenous groups describe kanna as a social and spiritual herb. Traditionally, harvested aerial parts were fermented to transform alkaloid profiles before being dried and stored. Fermentation reduces oxalate content, making the plant more comfortable on the stomach, and appears to increase mesembrine-type alkaloids that influence serotonin reuptake. When explorers documented kanna in the 17th century, they reported communities chewing quids before long hunts or negotiations, citing improved sociability and steady energy. That historical baseline offers clues for modern users seeking a relaxed yet attentive state.

## Alkaloids and Mechanisms

The primary mesembrine alkaloids—mesembrine, mesembrenone, mesembrenol, and tortuosamine—interact with multiple neural pathways. Laboratory studies indicate mesembrine is a selective serotonin reuptake inhibitor (SSRI) with modest phosphodiesterase-4 (PDE4) inhibition. Mesembrenone appears to inhibit serotonin reuptake and interact with acetylcholinesterase, potentially influencing cognitive flexibility. These actions together may explain why kanna simultaneously smooths anxiety and preserves alertness.

### Serotonin and Mood Regulation

SSRIs increase synaptic serotonin, which underpins mood stability. The difference between kanna and pharmaceutical SSRIs lies in the breadth of its alkaloid profile and the milder potency. Anecdotally, kanna’s lift emerges within 20–40 minutes and dissipates within 4–6 hours, far shorter than prescription antidepressants. For people prone to emotional overarousal, kanna’s acute, reversible boost can feel safer. Nonetheless, because kanna touches serotonergic pathways, it should not be combined with SSRIs, MAO inhibitors, or MDMA.

### PDE4, cAMP, and Focus

PDE4 inhibitors prevent the breakdown of cyclic adenosine monophosphate (cAMP), a messenger that modulates wakefulness, cognition, and inflammation. Pharmaceutical PDE4 inhibitors often cause nausea, but kanna’s gentle activity may increase cAMP only slightly—just enough to sharpen attention without jolting the nervous system. Some users compare kanna’s focus to a mild cup of coffee without jitteriness.

## Forms and Dosage Strategies

Modern kanna products include fermented powder, extracts standardized to mesembrine content, chewing gum, tinctures, and vape e-liquids. Fermented powder remains closest to tradition and is typically dosed between 50 and 200 milligrams for sublingual use. Extracts can range from 2:1 to 20:1 strength; start low and titrate. For cognitive support, many people prefer sublingual or vaporized routes because they offer rapid onset and better bioavailability compared to swallowing capsules.

### Combining Kanna with Other Botanicals

Kanna pairs well with herbs that support dopamine tone or reduce stress hormones. Small amounts of green tea or rhodiola can add energy, while tulsi or lemon balm temper overstimulation. Avoid stacking kanna with other serotonergic compounds like 5-HTP or St. John’s wort unless guided by a clinician. Because kanna promotes sociability, some blend it with cacao for ceremonial settings; however, listen to your body and keep first experiences solo or with trusted friends.

## Safety

> **Safety:** Do not combine kanna with prescription antidepressants, MAO inhibitors, or serotonergic psychedelics. Start with very small doses to watch for blood pressure changes, digestive upset, or mood swings.

Kanna’s adverse reports are rare but worth noting. Some users experience mild headaches, dry mouth, or soft stools when taking higher doses repeatedly. A minority report transient anxiety spikes—often due to taking large doses in stimulating environments. People with bipolar spectrum disorders should introduce kanna cautiously, as serotonin modulation could trigger hypomania. Pregnant and breastfeeding individuals should avoid kanna due to limited safety data.

## Cognitive and Emotional Effects

Anecdotal reports describe kanna as “grounding yet bright.” Users often share experiences of being able to articulate feelings without emotional overwhelm. For focus, kanna seems especially useful for monotonous tasks requiring steady attention. In a small open-label study, participants reported improved stress resilience and cognitive flexibility after several weeks of standardized kanna extract. The combination of serotonin and PDE4 pathways may help reduce mental rumination while preserving working memory.

### Microdosing vs. Acute Use

Microdosing kanna—taking 5–15 milligrams of a high-potency extract—can provide a subtle mood buffer. Acute doses, by contrast, bring a pronounced glow and social ease. If your goal is sustained focus through the workday, microdosing once or twice may be preferable. Reserve higher doses for evenings or social gatherings where you can observe how kanna affects your energy.

## Choosing Responsible Suppliers

Look for vendors that provide third-party testing for alkaloid content and microbial load. Ethical wildcrafting is critical: overharvesting can deplete natural populations. Whenever possible, support cultivated sources or community-led projects that reinvest in South African growers. Transparent suppliers should offer certificates of analysis, discuss fermentation processes, and avoid exaggerated claims.

## Integrating Kanna into Daily Routines

Begin with intention. Consider journaling baseline mood and focus before starting kanna, then track changes over several sessions. Pair your trial with grounding practices like breathwork or walking to notice how kanna shifts your internal dialogue. If you experience improved focus, you might limit use to high-priority projects to maintain sensitivity. Should tolerance arise, take a break of at least a week.

### A Sample Protocol

1. Choose a fermented powder with known alkaloid content.
2. Start with 50 milligrams sublingually on a calm morning.
3. Observe changes over 60 minutes; note mood, motivation, and bodily sensations.
4. If comfortable, adjust dose gradually in 10–25 milligram increments on separate days.
5. After several sessions, experiment with combining kanna with gentle adaptogens like tulsi or bacopa, ensuring there are no serotonergic overlaps.

## Future Directions in Kanna Research

Human trials remain limited, but emerging interest in plant-based anxiolytics may catalyze more rigorous research. Scientists are exploring how mesembrine analogs influence neuroplasticity, as well as kanna’s potential to ease social anxiety, trauma responses, and attention deficits. Until those studies arrive, user reports and ethnobotanical knowledge provide a compass: kanna shines when used intentionally, respectfully, and in moderation.

## References

https://www.frontiersin.org/articles/10.3389/fpsyt.2013.00170/full
https://pubmed.ncbi.nlm.nih.gov/31881670/
https://www.researchgate.net/publication/317296038_Sceletium_tortuosum_a_review_update
https://www.phytotherapymedicines.com/blogs/herbal-monographs/kanna-sceletium-tortuosum

