#!/usr/bin/env node
import fs from "fs";
import path from "path";
import { execSync } from "node:child_process";
import matter from "gray-matter";
import { marked } from "marked";

// Configure marked to ensure proper spacing and semantic tags
marked.setOptions({
  breaks: true,
  headerIds: true,
  mangle: false,
});

const ROOT = process.cwd();
const BLOG_SRC = path.join(ROOT, "content", "blog");
const OUT = path.join(ROOT, "public", "blogdata");
const POSTS_OUT = path.join(OUT, "posts");
const DATA_OUT = path.join(ROOT, "src", "data", "blog", "posts.json");
const PUBLIC_POSTS = path.join(ROOT, "public", "blog", "posts.json");
const DEFAULT_AUTHOR = "The Hippie Scientist";

function iso(d) {
  const date = new Date(d);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString().slice(0, 10);
}

function statISO(p) {
  try {
    const st = fs.statSync(p);
    const fallback = st.birthtimeMs || st.mtimeMs;
    if (fallback) {
      const formatted = iso(fallback);
      if (formatted) return formatted;
    }
  } catch {}
  return iso(Date.now()) ?? new Date().toISOString().slice(0, 10);
}

function escapeAttr(value) {
  if (value === undefined || value === null) return "";
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/"/g, "&quot;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function buildHtmlDocument({ title, description, slug, body, ogImage }) {
  const canonical = `https://thehippiescientist.net/blog/${slug}/`;
  const fallbackDescription = description || "";
  const fallbackImage = ogImage || "/og-default.jpg";
  const pageTitle = `${title} — The Hippie Scientist`;
  const indentedBody = body
    .split("\n")
    .map((line) => (line ? `      ${line}` : ""))
    .join("\n");

  return `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${escapeAttr(pageTitle)}</title>
    <meta name="description" content="${escapeAttr(fallbackDescription)}" />
    <link rel="canonical" href="${escapeAttr(canonical)}" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="${escapeAttr(title)}" />
    <meta property="og:description" content="${escapeAttr(fallbackDescription)}" />
    <meta property="og:url" content="${escapeAttr(canonical)}" />
    <meta property="og:image" content="${escapeAttr(fallbackImage)}" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${escapeAttr(title)}" />
    <meta name="twitter:description" content="${escapeAttr(fallbackDescription)}" />
    <meta name="twitter:image" content="${escapeAttr(fallbackImage)}" />
  </head>
  <body>
    <main id="blog-post">
${indentedBody}
    </main>
  </body>
</html>
`;
}

function ensureCanonical(html, slug) {
  const cleanSlug = String(slug || "").replace(/^\/+|\/+$/g, "");
  if (!cleanSlug) return html;
  const canonicalHref = `https://thehippiescientist.net/blog/${cleanSlug}/`;
  const canonicalTag = `<link rel="canonical" href="${escapeAttr(canonicalHref)}">`;
  const canonicalRe = /<link[^>]+rel=["']canonical["'][^>]*>/i;

  if (canonicalRe.test(html)) {
    return html.replace(canonicalRe, canonicalTag);
  }

  if (/<\/head>/i.test(html)) {
    return html.replace(/<\/head>/i, `    ${canonicalTag}\n  </head>`);
  }

  return `${canonicalTag}\n${html}`;
}

function upsertHeadTag(html, testRe, tag) {
  if (testRe.test(html)) {
    return html.replace(testRe, tag);
  }
  if (/<\/head>/i.test(html)) {
    return html.replace(/<\/head>/i, `    ${tag}\n  </head>`);
  }
  return `${tag}\n${html}`;
}

function ensureSocialMeta(html, { slug, ogImage }) {
  const cleanSlug = String(slug || "").replace(/^\/+|\/+$/g, "");
  const canonicalHref = cleanSlug ? `https://thehippiescientist.net/blog/${cleanSlug}/` : "https://thehippiescientist.net/";
  const image = ogImage || "/og-default.jpg";

  const entries = [
    {
      regex: /<meta[^>]+property=["']og:type["'][^>]*>/i,
      tag: '<meta property="og:type" content="article" />',
    },
    {
      regex: /<meta[^>]+property=["']og:url["'][^>]*>/i,
      tag: `<meta property="og:url" content="${escapeAttr(canonicalHref)}" />`,
    },
    {
      regex: /<meta[^>]+property=["']og:image["'][^>]*>/i,
      tag: `<meta property="og:image" content="${escapeAttr(image)}" />`,
    },
    {
      regex: /<meta[^>]+name=["']twitter:card["'][^>]*>/i,
      tag: '<meta name="twitter:card" content="summary_large_image" />',
    },
    {
      regex: /<meta[^>]+name=["']twitter:image["'][^>]*>/i,
      tag: `<meta name="twitter:image" content="${escapeAttr(image)}" />`,
    },
  ];

  let next = html;
  for (const { regex, tag } of entries) {
    next = upsertHeadTag(next, regex, tag);
  }
  return next;
}

function ensureTitleAndDescription(html, { title, description }) {
  const pageTitle = title ? `${title} — The Hippie Scientist` : "The Hippie Scientist";
  const fallbackDescription = description || "";
  const titleTag = `<title>${escapeAttr(pageTitle)}</title>`;
  const titleRe = /<title>.*?<\/title>/i;

  let next = html;
  if (titleRe.test(next)) {
    next = next.replace(titleRe, titleTag);
  } else if (/<\/head>/i.test(next)) {
    next = next.replace(/<\/head>/i, `    ${titleTag}\n  </head>`);
  } else {
    next = `${titleTag}\n${next}`;
  }

  next = upsertHeadTag(
    next,
    /<meta[^>]+name=["']description["'][^>]*>/i,
    `<meta name="description" content="${escapeAttr(fallbackDescription)}" />`,
  );

  return next;
}

function stripUnsafeMarkdownSyntax(markdown) {
  if (!markdown) return "";

  const withoutModuleLines = markdown
    .split("\n")
    .filter((line) => {
      const trimmed = line.trimStart();
      return !trimmed.startsWith("import ") && !trimmed.startsWith("export ");
    })
    .join("\n");

  const withoutJsx = withoutModuleLines
    .split("\n")
    .filter((line) => {
      const trimmed = line.trim();
      // Remove JSX/component-style tags such as <Callout ...>...</Callout> and </Callout>
      if (/^<\/?[A-Z][\w.-]*\b/.test(trimmed)) return false;
      // Remove embedded JS expression lines often used in MDX
      if (/^\{[\s\S]*\}$/.test(trimmed)) return false;
      return true;
    })
    .join("\n");

  return withoutJsx.replace(/\n{3,}/g, "\n\n").trim();
}


function stripMarkdownToText(markdown) {
  if (!markdown) return "";
  return markdown
    .replace(/```[\s\S]*?```/g, " ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/!\[[^\]]*\]\([^)]*\)/g, " ")
    .replace(/\[[^\]]+\]\([^)]*\)/g, "$1")
    .replace(/^\s{0,3}#{1,6}\s+/gm, "")
    .replace(/^>\s?/gm, "")
    .replace(/^\s*[-*+]\s+/gm, "")
    .replace(/^\s*\d+\.\s+/gm, "")
    .replace(/[>*_~]/g, "")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function toExcerpt(markdown, max = 220) {
  const clean = stripMarkdownToText(markdown);
  if (!clean) return "Research notes focused on mechanisms, context, and safety.";
  if (clean.length <= max) return clean;
  return `${clean.slice(0, max - 1).trimEnd()}…`;
}

function isTargetedNotesTitle(title = "") {
  const normalized = String(title).toLowerCase();
  return [
    "tuesday notes",
    "wednesday notes",
    "daily notes",
    "field notes",
    "cultivar notes",
    "safety & set/setting",
  ].some((pattern) => normalized.includes(pattern));
}

function extractPrimaryHerbFromTitle(title = "") {
  const match = String(title).match(/—\s*([^(\n]+?)(?:\s*\(|$)/);
  return match ? match[1].trim() : "";
}

function includesTerm(haystack = "", needle = "") {
  const source = String(haystack).toLowerCase();
  const value = String(needle).toLowerCase().trim();
  if (!value) return false;
  return source.includes(value);
}

function hasNotesConsistencyMismatch({ title = "", summary = "", content = "" }) {
  if (!isTargetedNotesTitle(title)) return false;
  const herb = extractPrimaryHerbFromTitle(title);
  if (!herb) return true;

  const summaryMatches = includesTerm(summary, herb);
  const contentMatches = includesTerm(content, herb);
  const dailyClause =
    summary.toLowerCase().includes("daily notes on") &&
    !summary.toLowerCase().includes(`daily notes on ${herb.toLowerCase()}`);

  return !summaryMatches || !contentMatches || dailyClause;
}

function normalizeTitleForSimilarity(title = "") {
  return String(title)
    .toLowerCase()
    .replace(/\([^)]*notes\)/g, "")
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function validateDuplicatePostMetadata(rows = []) {
  const duplicateTitles = new Map();
  const duplicateSlugs = new Map();
  const nearDuplicateBuckets = new Map();

  for (const row of rows) {
    const titleKey = String(row.title || "").trim().toLowerCase();
    const slugKey = String(row.slug || "").trim().toLowerCase();
    const nearTitleKey = normalizeTitleForSimilarity(row.title || "");

    if (titleKey) {
      const entries = duplicateTitles.get(titleKey) || [];
      entries.push(row.slug);
      duplicateTitles.set(titleKey, entries);
    }

    if (slugKey) {
      const entries = duplicateSlugs.get(slugKey) || [];
      entries.push(row.title);
      duplicateSlugs.set(slugKey, entries);
    }

    if (nearTitleKey) {
      const entries = nearDuplicateBuckets.get(nearTitleKey) || [];
      entries.push({ title: row.title, slug: row.slug });
      nearDuplicateBuckets.set(nearTitleKey, entries);
    }
  }

  const exactTitleDuplicates = [...duplicateTitles.entries()].filter(([, entries]) => entries.length > 1);
  const exactSlugDuplicates = [...duplicateSlugs.entries()].filter(([, entries]) => entries.length > 1);
  const nearDuplicates = [...nearDuplicateBuckets.entries()].filter(([, entries]) => {
    if (entries.length <= 1) return false;
    const uniqueTitles = new Set(entries.map((entry) => entry.title));
    return uniqueTitles.size > 1;
  });

  if (nearDuplicates.length) {
    for (const [, entries] of nearDuplicates) {
      const summary = entries.map((entry) => `"${entry.title}" (${entry.slug})`).join(", ");
      console.warn(`[blog:validation] Near-duplicate titles detected: ${summary}`);
    }
  }

  if (exactTitleDuplicates.length || exactSlugDuplicates.length) {
    for (const [titleKey, entries] of exactTitleDuplicates) {
      console.error(`[blog:validation] Duplicate title "${titleKey}" used by slugs: ${entries.join(", ")}`);
    }
    for (const [slugKey, entries] of exactSlugDuplicates) {
      console.error(`[blog:validation] Duplicate slug "${slugKey}" used by titles: ${entries.join(" | ")}`);
    }
    process.exit(1);
  }
}

/**
 * Resolve the post's creation date with this precedence:
 * 1) front-matter 'date'
 * 2) first Git commit author date (if repo)
 * 3) file system birthtime
 * 4) now
 */
function getCreatedDate(fp, fmDate) {
  const frontMatter = fmDate ? iso(fmDate) : null;
  if (frontMatter) return frontMatter;

  try {
    const cmd = `git log --follow --diff-filter=A --format=%aI -- "${fp}" | tail -n 1`;
    const out = execSync(cmd, { stdio: ["ignore", "pipe", "ignore"] }).toString().trim();
    const gitDate = out ? iso(out) : null;
    if (gitDate) return gitDate;
  } catch {}

  const fsDate = statISO(fp);
  if (fsDate) return fsDate;

  return iso(Date.now());
}

fs.mkdirSync(OUT, { recursive: true });
fs.rmSync(POSTS_OUT, { recursive: true, force: true });
fs.mkdirSync(POSTS_OUT, { recursive: true });

const files = fs.existsSync(BLOG_SRC)
  ? fs
      .readdirSync(BLOG_SRC)
      .filter((f) => f.endsWith(".md") || f.endsWith(".mdx"))
  : [];
const rows = [];
let consistencyBlocked = 0;

for (const file of files) {
  const rawSlug = file.replace(/\.(md|mdx)$/, "");
  const filePath = path.join(BLOG_SRC, file);
  const raw = fs.readFileSync(filePath, "utf-8");
  const { data, content } = matter(raw);
  const slug = String(data?.slug || rawSlug || "").replace(/^\/+|\/+$/g, "");
  const staleDir = path.resolve("public", "blog", slug);
  const staleLegacy = path.resolve("public", "blog", `${slug}.html`);
  const fileSlugDir = path.resolve("public", "blog", rawSlug);
  const fileSlugLegacy = path.resolve("public", "blog", `${rawSlug}.html`);
  if (data?.draft) {
    fs.rmSync(staleDir, { recursive: true, force: true });
    fs.rmSync(staleLegacy, { force: true });
    fs.rmSync(fileSlugDir, { recursive: true, force: true });
    fs.rmSync(fileSlugLegacy, { force: true });
    continue;
  }
  if (
    hasNotesConsistencyMismatch({
      title: data?.title || rawSlug,
      summary: data?.summary || data?.description || "",
      content,
    })
  ) {
    consistencyBlocked += 1;
    fs.rmSync(staleDir, { recursive: true, force: true });
    fs.rmSync(staleLegacy, { force: true });
    fs.rmSync(fileSlugDir, { recursive: true, force: true });
    fs.rmSync(fileSlugLegacy, { force: true });
    console.warn(`[blog:consistency] Skipping ${file}: title/summary/content herb mismatch.`);
    continue;
  }
  const sanitizedMarkdown = stripUnsafeMarkdownSyntax(content);
  const postHtml = marked.parse(sanitizedMarkdown);
  const contentWithoutTitle = sanitizedMarkdown.replace(/^\s*#\s+.+$/m, '').trim();
  const excerpt = toExcerpt(contentWithoutTitle || sanitizedMarkdown, 220);
  const words = sanitizedMarkdown.trim() ? sanitizedMarkdown.trim().split(/\s+/).length : 0;
  const readingTime = `${Math.max(1, Math.round(words / 225))} min read`;
  const created = getCreatedDate(filePath, data?.date);
  const tags = Array.isArray(data.tags) ? data.tags.map((tag) => String(tag)) : [];
  const author = data.author ? String(data.author) : DEFAULT_AUTHOR;
  const sources = Array.isArray(data.sources)
    ? data.sources
        .map((source) => {
          if (typeof source === 'string') {
            return { title: source, url: source };
          }
          if (source && typeof source === 'object') {
            const title = String(source.title || source.url || '').trim();
            const url = String(source.url || '').trim();
            const note = String(source.note || '').trim();
            if (!title && !url) return null;
            return { title: title || url, url: url || title, note: note || undefined };
          }
          return null;
        })
        .filter(Boolean)
    : [];
  const summary = excerpt;
  const cover = data.cover || data.featuredImage || data.image || data.hero || null;
  const title = data.title || rawSlug;
  const description = toExcerpt(data.description || contentWithoutTitle || sanitizedMarkdown, 200);
  const ogImage = data.ogImage || cover || null;
  const lastUpdated = iso(data.lastUpdated) || statISO(filePath);

  fs.writeFileSync(path.join(POSTS_OUT, `${slug}.html`), postHtml, "utf-8");

  const post = {
    slug,
    title,
    date: created,
    lastUpdated,
    author,
    sources,
    description,
    summary,
    tags,
    readingTime,
    cover: cover || undefined,
    featuredImage: cover || undefined,
    ogImage: ogImage || undefined,
  };

  let html = buildHtmlDocument({
    title: post.title,
    description: post.description,
    slug: post.slug,
    body: postHtml,
    ogImage,
  });

  html = ensureCanonical(html, slug);
  html = ensureSocialMeta(html, { slug, ogImage });
  html = ensureTitleAndDescription(html, { title: post.title, description: post.description });

  const outDir = path.resolve("public", "blog", slug);
  const outFile = path.join(outDir, "index.html");
  const legacyFile = path.resolve("public", "blog", `${slug}.html`);

  fs.rmSync(legacyFile, { force: true });
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(outFile, html, "utf-8");

  rows.push(post);
}

validateDuplicatePostMetadata(rows);

rows.sort((a, b) => (a.date < b.date ? 1 : -1));
fs.writeFileSync(path.join(OUT, "index.json"), JSON.stringify(rows, null, 2), "utf-8");

const metadata = rows.map((row) => ({
  slug: row.slug,
  title: row.title,
  date: row.date,
  lastUpdated: row.lastUpdated,
  author: row.author,
  sources: row.sources,
  excerpt: row.description,
  description: row.description,
  summary: row.summary,
  tags: row.tags,
  readingTime: row.readingTime,
  cover: row.cover,
  featuredImage: row.featuredImage,
  ogImage: row.ogImage,
}));

fs.mkdirSync(path.dirname(DATA_OUT), { recursive: true });
fs.writeFileSync(DATA_OUT, JSON.stringify(metadata, null, 2), "utf-8");

fs.mkdirSync(path.dirname(PUBLIC_POSTS), { recursive: true });
fs.writeFileSync(PUBLIC_POSTS, JSON.stringify(metadata, null, 2), "utf-8");

console.log(
  `Built ${rows.length} posts → /public/blogdata & /public/blog/{slug}/index.html (duplicates validated)`
);
if (consistencyBlocked > 0) {
  console.log(`[blog:consistency] Blocked ${consistencyBlocked} mismatched notes posts from publishing.`);
}
