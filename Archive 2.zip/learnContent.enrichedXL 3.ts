export const learnSections = [
{
  id: "mechanisms",
  title: "Mechanisms of Action",
  content: `Every psychoactive herb works through one or more **biochemical pathways** in the body. These mechanisms — often involving neurotransmitters, hormones, or receptors — shape the herb’s effects on the brain and nervous system.

Understanding these pathways can help you:
- Predict how an herb might feel
- Choose herbs that complement (not conflict)
- Avoid harmful interactions (e.g. with medications)

---

### 🧘 GABAergic Pathway
- **Neurotransmitter:** GABA (Gamma-Aminobutyric Acid)
- **Function:** Inhibitory — slows down neural activity
- **Effects:** Calming, sedative, anti-anxiety, muscle relaxant
- **Herbs:** Valerian, Kava, Skullcap, Chamomile, Lemon Balm

**How it works:** These herbs either increase GABA production, inhibit its breakdown, or bind directly to GABA-A receptors — similar to how benzodiazepines work, but generally milder.

---

### 😌 Serotonergic Pathway
- **Neurotransmitter:** Serotonin (5-HT)
- **Function:** Regulates mood, sleep, appetite, and perception
- **Effects:** Mood elevation, dream vividness, relaxation, hallucinations (at high levels)
- **Herbs:** Passionflower, Blue Lotus, Ayahuasca (contains DMT), Syrian Rue (MAOI)

**Note:** Serotonin agonists (like DMT) and reuptake inhibitors (like St. John's Wort) can be powerful. Never mix multiple serotonergic herbs or combine with SSRIs.

---

### ⚡ Dopaminergic Pathway
- **Neurotransmitter:** Dopamine
- **Function:** Motivation, pleasure, focus, movement
- **Effects:** Increased mental energy, drive, reward sensation
- **Herbs:** Mucuna pruriens (L-Dopa), Rhodiola rosea, Maca, Celastrus paniculatus

**Risks:** Too much stimulation may lead to irritability or anxiety. Support dopamine with grounding herbs if needed.

---

### 🧠 Cholinergic Pathway
- **Neurotransmitter:** Acetylcholine
- **Function:** Memory formation, learning, dream lucidity
- **Effects:** Enhanced recall, focus, dream vividness, neuroprotection
- **Herbs:** Calea ternifolia, Huperzia serrata, Bacopa monnieri, Gotu Kola

**Best for:** Dreamers, students, neuro-hackers.

---

### 🌀 NMDA Antagonists (Glutamate Modulation)
- **Receptor System:** NMDA (glutamate receptor)
- **Function:** Memory, consciousness, sensory integration
- **Effects:** Dissociation, visual distortions, dreamlike states, neuroplasticity
- **Herbs:** Salvia divinorum, Heimia salicifolia, Ketamine (pharma analog)

**Caution:** These are potent and should only be used with deep respect and awareness of set/setting.

---

### 🛡️ Anti-inflammatory & Endocrine-Modulating Effects
Some herbs don’t act directly on the brain, but influence mood and cognition by:
- Reducing neuroinflammation (Turmeric, Boswellia)
- Regulating cortisol or adrenal hormones (Ashwagandha, Licorice)
- Modulating immune/neuroimmune interactions

---

### 🔬 Synergistic Actions
Many herbs affect **multiple pathways** at once:
- **Passionflower:** GABA + Serotonin
- **Celastrus:** Dopamine + Acetylcholine
- **Blue Lotus:** GABA + Serotonin + Dopamine

This synergy can be helpful — or overwhelming — depending on dosage and combination.

---

### 🧪 Summary Table

| Pathway | Primary Effect | Herb Examples |
|--------|----------------|----------------|
| GABAergic | Calm, sedation | Valerian, Skullcap |
| Serotonergic | Mood, dreams | Blue Lotus, Passionflower |
| Dopaminergic | Energy, drive | Mucuna, Rhodiola |
| Cholinergic | Memory, dreams | Calea, Gotu Kola |
| NMDA Antagonist | Visionary, dissociative | Salvia, Heimia |
| Endocrine/Anti-inflammatory | Hormonal balance | Ashwagandha, Turmeric |

---

Understanding the mechanism is just one part of the picture — tradition, dosage, and intention also matter deeply.`
},
];