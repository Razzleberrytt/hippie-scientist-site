export const learnSections = [
{
  id: "tag-glossary",
  title: "Herb Tag Glossary",
  content: `Tags are a core part of The Hippie Scientist herb index — they help you quickly understand what an herb is known for, how it might feel, and what kind of context it might be used in. Here's a full glossary of all current tags with definitions, use cases, and example herbs.

---

### 🌙 Dream-enhancing
**What it means:** Promotes vivid dreams, better recall, or lucid dreaming.

- **Typical compounds:** Oneirogens, acetylcholine enhancers
- **Best used:** Before bed, with intention setting or dream journaling
- **Examples:** Calea ternifolia, Silene capensis, Mugwort, Blue Lotus

---

### 🧠 Nootropic
**What it means:** Enhances cognitive function — including memory, learning, clarity, or creativity.

- **Mechanisms:** Dopamine, acetylcholine, neuroprotective effects
- **Great for:** Students, creatives, neurodivergent users
- **Examples:** Celastrus paniculatus, Bacopa monnieri, Gotu Kola, Rhodiola rosea

---

### ⚖️ Adaptogen
**What it means:** Regulates stress response and restores balance over time.

- **Use cases:** Burnout recovery, adrenal fatigue, immune support
- **Timing:** Often taken daily, not for acute effects
- **Examples:** Ashwagandha, Eleuthero, Schisandra, Tulsi (Holy Basil)

---

### 😌 Sedative
**What it means:** Calms the nervous system, promotes sleep or physical relaxation.

- **Common effects:** Sleepiness, muscle relaxation, anti-anxiety
- **Good for:** Insomnia, overthinking, tension
- **Examples:** Valerian root, Skullcap, Passionflower, California Poppy

---

### 🔋 Stimulant
**What it means:** Increases energy, alertness, or stamina — often via dopamine or adrenaline pathways.

- **Risks:** May increase anxiety or jitteriness if overused
- **Cautions:** Avoid late-night use; can be habit-forming
- **Examples:** Guarana, Yerba Mate, Ephedra (Ma Huang), Kola Nut

---

### 💘 Aphrodisiac
**What it means:** Traditionally used to enhance libido, sensuality, or sexual vitality.

- **Mechanisms:** Increased circulation, dopamine, or relaxation
- **Cultural uses:** Tantra, love potions, libido blends
- **Examples:** Damiana, Maca, Tribulus terrestris, Yohimbe

---

### 🔮 Psychedelic
**What it means:** Can induce altered states of perception, introspection, or spiritual insight.

- **Range:** From subtle shifts to full visionary states
- **Usage:** Often ceremonial or introspective
- **Examples:** Salvia divinorum, Ayahuasca (DMT+MAOI), Iboga, Fly Agaric

---

### 🛡️ Immune-supportive
**What it means:** Strengthens or balances immune system responses.

- **Common uses:** Colds, chronic fatigue, seasonal transitions
- **Examples:** Astragalus, Echinacea, Reishi, Elderberry

---

### 🪷 Mood-boosting
**What it means:** Supports emotional regulation or lifts low mood.

- **Related systems:** Dopaminergic, serotonergic
- **Examples:** Mucuna pruriens, Lemon Balm, Kanna, St. John’s Wort

---

### 🌬️ Respiratory
**What it means:** Traditionally used to ease breathing or support lung function.

- **Use cases:** Cough blends, smoke cleansing, seasonal illness
- **Examples:** Mullein, Coltsfoot, Horehound

---

### ⚡ Energy-supporting
**What it means:** Increases stamina and reduces fatigue (not always stimulating).

- **Different from:** Nervous system stimulants — often adaptogenic
- **Examples:** Cordyceps, Schisandra, Maca

---

### 🌿 Detoxifying
**What it means:** Supports liver, lymphatic, or kidney function to aid natural detoxification.

- **Cultural examples:** Spring cleanses, liver tonics
- **Examples:** Dandelion, Burdock, Milk Thistle, Cleavers

---

### 🔥 Anti-inflammatory
**What it means:** Reduces systemic or localized inflammation.

- **Conditions supported:** Arthritis, gut health, chronic fatigue
- **Examples:** Turmeric, Ginger, Boswellia, Holy Basil

---

> Many herbs have multiple tags depending on dose, preparation, and tradition. These tags are starting points — always read full profiles before use.`
},
];