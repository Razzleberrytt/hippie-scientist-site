export const learnSections = [
{
  id: "safety",
  title: "Safety Guidelines & Responsible Use",
  content: `Psychoactive herbs are powerful allies — and like all potent tools, they carry risks as well as rewards. Respecting these plants means understanding both their gifts and their boundaries. Safe use begins with informed, intentional practice.

---

### 🧭 Core Principles of Safe Use

#### 1. **Start Low, Go Slow**
- Always begin with the smallest effective dose.
- Herbs may affect you more strongly than expected, especially when smoked or taken with other herbs.
- Everyone metabolizes differently — your “small” may be another’s “strong.”

#### 2. **Know the Herb**
- Learn its traditional use, known compounds, preparation method, and interactions.
- Read multiple sources before trying a new herb.
- Avoid TikTok/herb trend misinformation — trust botanical science + ancestral knowledge.

#### 3. **Don’t Stack Carelessly**
- Combining herbs with similar effects can overwhelm your system.
- Example: Mixing Kava (GABA) with Valerian (also GABA) can cause dizziness or sedation.
- Avoid mixing multiple stimulants, sedatives, or serotonergics without deep knowledge.

---

### 💊 Medication Interactions

| Drug Class | Risk with Herbs | Herbs to Watch |
|------------|------------------|----------------|
| SSRIs | Serotonin syndrome | Passionflower, Syrian Rue, St. John’s Wort |
| Benzodiazepines | Over-sedation | Kava, Valerian, Skullcap |
| Antipsychotics | Dopamine disruption | Mucuna, Celastrus |
| MAOIs | Dangerous hypertensive episodes | Syrian Rue + tryptamines |
| Stimulants | Hypertension, anxiety | Guarana, Ephedra, Yohimbe |

- Consult a medical professional if you're taking **any pharmaceuticals**.
- Even supplements like 5-HTP can dangerously combine with herbal MAOIs.

---

### ⚖️ Legal Awareness
- Some herbs are legal to possess but not legal to sell, import, or advertise.
- Herbs like **Kratom**, **Salvia**, or **Blue Lotus** may be restricted by region or country.
- Always check:
  - Federal/national laws
  - State/provincial laws
  - Customs/import restrictions

---

### 🧠 Psychological Readiness

Herbs that affect perception or mood may surface:
- Suppressed emotions
- Traumatic memories
- Internal conflict

Create a **safe mental and physical space** before use:
- Journal or meditate beforehand
- Set a clear intention (healing, insight, relaxation)
- Avoid use during emotional crisis without guidance

---

### 🏠 Setting, Space & Ritual

- Use herbs in a **clean, calm environment**
- Dim lighting, music, nature, or intentional design helps create safety
- Have **integration tools** ready: journal, grounding foods, a friend to talk to
- Respect cultural context and sacred traditions

---

### ❌ Avoid During Pregnancy/Nursing
- Many psychoactive herbs are contraindicated during pregnancy, even in low doses.
- This includes Blue Lotus, Kava, Passionflower, and most adaptogens.
- Use only with explicit professional guidance.

---

### 📚 Keep a Log

Create a dedicated **Herb Journal**:
- Name, date, dose, preparation method
- Mood before/after
- Dreams or insights
- Reactions (positive or adverse)

Helps refine future sessions and detect patterns.

---

### 🧬 Your Body is the Guide

Respect doesn’t mean fear — it means relationship. Listen to your body, trust your intuition, and let each herb introduce itself in its own time.`
},
];