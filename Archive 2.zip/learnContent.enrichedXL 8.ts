export const learnSections = [
{
  id: "getting-started",
  title: "How to Choose a Starting Herb",
  content: `If you're new to psychoactive herbs, it can be hard to know where to begin. Some plants offer gentle relaxation, others spark vivid dreams, and a few can radically shift your perception. This guide will help you choose a first herb that aligns with your goals, needs, and level of experience.

---

### 🎯 Step 1: Define Your Intention

Before touching a leaf or brewing a tea, ask yourself:
- Do I want to **relax**, **focus**, or **dream**?
- Am I curious about **altered states**, or simply looking for natural mood support?
- Am I drawn to a **specific tradition** or healing system?

Your **why** determines your **what.**

---

### 🧭 Step 2: Align Goals with Categories

| Goal | Herb Type | Beginner-Friendly Herbs |
|------|-----------|--------------------------|
| Stress relief | Sedative / Adaptogen | Lemon Balm, Skullcap, Ashwagandha |
| Better sleep | Sedative | Passionflower, California Poppy |
| Dreaming / Lucid states | Oneirogen | Blue Lotus, Mugwort |
| Mood boost | Euphoric / Dopaminergic | Mucuna, Damiana |
| Mental clarity | Nootropic / Cholinergic | Gotu Kola, Celastrus |
| Energy | Adaptogen / Stimulant | Rhodiola, Guarana (low dose) |

---

### ⚠️ Step 3: Avoid Intense Herbs (at first)

Steer clear of the following as a beginner:

| Herb | Reason |
|------|--------|
| Salvia divinorum | Intense dissociative, very short but powerful |
| Syrian Rue (MAOI) | Dangerous if combined incorrectly |
| Iboga | Visionary + potentially toxic in high doses |
| Kratom | Risk of dependence; stimulating at low doses, sedative at high |
| Fly Agaric | Unique pharmacology, often misunderstood |

These are better explored **later**, with education and intention.

---

### 🧪 Step 4: Choose a Gentle Entry Point

Here are 5 starter herbs to match common beginner goals:

#### 1. **Lemon Balm (Melissa officinalis)**
- 🌿 Category: Sedative, Nervine
- 😊 Feels like: Calm focus, anxiety relief
- ☕ Prep: Tea, tincture

#### 2. **Blue Lotus (Nymphaea caerulea)**
- 🌙 Category: Dream, Mood
- ✨ Feels like: Gentle euphoria, enhanced dreams
- 💧 Prep: Smoke, tea, or tincture

#### 3. **Gotu Kola (Centella asiatica)**
- 🧠 Category: Nootropic, Adaptogen
- 💡 Feels like: Quiet mental clarity, grounded cognition
- 🥗 Prep: Powder in smoothies or tea

#### 4. **Damiana (Turnera diffusa)**
- 💘 Category: Euphoric, Aphrodisiac
- 😊 Feels like: Uplifted mood, gentle sociability
- 💨 Prep: Tea, smoke, or tincture

#### 5. **Ashwagandha (Withania somnifera)**
- ⚖️ Category: Adaptogen
- 😌 Feels like: Long-term anxiety reduction, better sleep
- 💊 Prep: Capsules or powder with fat (like milk or ghee)

---

### 📝 Step 5: Track Your Experience

Use a **herb log** to build your own intuitive herbal language:

- Date, dose, method (tea, tincture, etc.)
- Setting (time of day, mood, environment)
- Perceived effects (mental, emotional, physical)
- Dream recall (if relevant)

Over time, this will become your **personal herbal map**.

---

### 🌿 Bonus: Beginner Combinations (Safe Blends)

| Blend | Components | Goal |
|-------|------------|------|
| Lucid Tea | Blue Lotus + Mugwort + Chamomile | Dream enhancement |
| Nerve Ease | Skullcap + Passionflower + Lemon Balm | Calming without sedation |
| Focus Flow | Gotu Kola + Celastrus + Rhodiola | Mental clarity & stamina |

---

Everyone's body is different. What relaxes one person may energize another. Start small, build a relationship with each herb, and let curiosity — not urgency — lead you.`
},
];