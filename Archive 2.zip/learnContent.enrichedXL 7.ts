export const learnSections = [
{
  id: "legality",
  title: "Legal Overview of Psychoactive Herbs",
  content: `The legality of psychoactive herbs is a moving target — shaped by evolving drug laws, cultural stigma, traditional exemptions, and scientific research. Some herbs are freely available worldwide, while others are banned, regulated, or reside in legal gray areas.

Understanding these differences is essential for safe, responsible, and legal use.

---

### 🌍 Global Legal Landscape

| Herb | United States | Canada | UK/EU | Notes |
|------|----------------|--------|-------|-------|
| **Kava** | ⚠️ Legal (some states restrict) | ❌ Banned | ❌ Restricted | Liver toxicity concerns in EU/CA |
| **Salvia divinorum** | ⚠️ State bans apply | ❌ Controlled | ❌ Banned | Legal federally in US |
| **Kratom** | ⚠️ Legal (some state bans) | ❌ Controlled | ❌ Banned in several EU states | Ongoing regulation debate |
| **Blue Lotus** | ✅ Legal | ✅ Legal | ✅ Legal | Often labeled “not for human consumption” |
| **Ayahuasca** | ❌ Illegal (DMT) | ❌ Illegal | ❌ Illegal | Religious exceptions in Brazil, Peru |
| **Cannabis** | ⚠️ State-dependent legality | ✅ Legal | ⚠️ Varies | Psychoactivity varies by chemotype |

> Always check **local, state/province, and national law** before purchase or use.

---

### 📜 Controlled Substance Scheduling

Most countries use a **drug schedule system**:

- **Schedule I (USA):** No accepted medical use, high abuse potential (e.g. DMT, psilocybin)
- **Schedule III–V:** Accepted use with restrictions (e.g. ketamine, anabolic steroids)
- **Unscheduled:** Legal, unregulated, or herbal (unless banned by name)

> Note: Many herbs are **unscheduled but still restricted under analog laws or import bans**.

---

### ✈️ Importing and Shipping

#### ⚠️ Common Issues:
- Seizure at customs due to lack of labeling or import paperwork
- Herbs labeled “incense,” “aromatic use only,” or “not for consumption” to bypass regulation
- Laws may criminalize **intent to consume**, not possession

#### ✅ Safer Practices:
- Buy from vendors based in your country
- Check local restrictions (e.g., Louisiana bans kratom, Salvia, blue lotus)
- Save all invoices and COAs (Certificates of Analysis)

---

### 🏛️ Religious & Cultural Exemptions

Some psychoactive herbs are legally protected **within religious or indigenous contexts**:

- **Ayahuasca:** Legal in Brazil, Peru, and under some U.S. religious groups (UDV, Santo Daime)
- **Peyote:** Legal for Native American Church use in the US
- **Iboga:** Sometimes protected under Bwiti religious rights (varies by country)

Always respect the **cultural sovereignty** of sacred plants and avoid extractive or exploitative practices.

---

### 📚 Keeping Up with Law Changes

Regulations shift constantly. To stay informed:
- Follow botanical legal forums (e.g. r/kratom, Shroomery, MAPS)
- Monitor WHO, UNODC, and local herbal advocacy orgs
- Use legal databases like:
  - **Erowid.org** (user reports + legal data)
  - **PsychedelicAlpha.com** (regulatory updates)
  - **Psychedelic Legal Compass** (legal tools)

---

### 🔒 Summary: Know Before You Grow (or Buy)

| Check | Why it matters |
|-------|----------------|
| National schedule | May ban import, use, or possession |
| State/provincial law | Overrides federal legality in some places |
| Vendor source | International shipping risks seizure |
| Cultural/traditional protection | Respect is legal as well as ethical |

Stay aware, stay respectful, and support legal reform where it serves education, sovereignty, and access.`
},
];