export const learnSections = [
{
  id: "dosing",
  title: "Microdosing vs. Macrodosing: A Guide to Herbal Dosage",
  content: `The amount of herb you take can completely change how it affects your body and mind. With psychoactive plants, **dose defines experience**. Many herbs are bimodal — meaning low doses may be uplifting or nootropic, while high doses can sedate, overwhelm, or induce visions.

---

### ⚖️ Dosing Spectrum

| Term | Description | Common Use |
|------|-------------|-------------|
| **Microdose** | Sub-perceptual or subtle dose | Daily clarity, mood support, creativity |
| **Threshold dose** | First point of noticeable change | Light dreamwork, nootropic boost |
| **Macrodose** | Strong perceptual shift | Deep introspection, ceremonial work |
| **Heroic dose** | Overwhelming, ego-dissolving experience | Advanced spiritual exploration (not recommended for beginners) |

---

### 💧 What Is Microdosing?

Microdosing is the practice of taking **very small, sub-perceptual amounts** of a psychoactive substance to subtly improve mood, focus, or creative flow without intoxication.

- **Goal:** Subtle uplift, consistency, no altered state
- **Schedule:** 1 day on, 2 days off (or 4-on / 3-off) to avoid tolerance
- **Popular microdosed herbs:**
  - **Celastrus paniculatus:** 2–3 seeds for mental clarity
  - **Blue Lotus:** 5–10 drops of tincture
  - **Kanna:** 5–15 mg of extract for mood balance
  - **Rhodiola:** 50–100 mg for mental stamina

---

### 🌊 What Is Macrodosing?

Macrodosing involves taking a **standard or high dose** — enough to fully activate the herb’s psychoactive potential.

- **Goal:** Introspection, transformation, deep rest, vivid dreams
- **Onset:** May take 30 min to 2 hours depending on method
- **Popular macrodose herbs:**
  - **Calea ternifolia:** 1–2g smoked or tea (dream intensity)
  - **Salvia divinorum:** 10x extract (1 strong hit) for short, visionary episodes
  - **Passionflower:** 2–4g in tea for sedation and mood
  - **Blue Lotus:** 200mg resin or 5g dried petals in tea

---

### 📊 Micro vs. Macro: Comparison Chart

| Herb | Microdose | Macrodose | Notes |
|------|-----------|-----------|-------|
| Celastrus | 2–3 seeds | 10–15 seeds | Nootropic at low, mild euphoria at high |
| Calea | 300–500mg | 1–2g | Dreams scale with dose |
| Blue Lotus | 5–10 drops | 200mg+ resin or 5g tea | Euphoric vs. sedative states |
| Mucuna | 100mg | 500–1000mg | L-Dopa effects increase with dose |
| Kanna | 5–15mg | 50–100mg | Low = mood lift, High = stimulation or sedation |

---

### 🧪 Dosing Factors to Consider

- **Preparation method:** Tinctures absorb faster than teas
- **Body weight and sensitivity:** Start at lower end of range
- **Food intake:** Some herbs absorb better with fat (e.g. Ashwagandha)
- **Experience level:** New users should start with a half dose

---

### ❌ Dosing Mistakes to Avoid

- Re-dosing too early (“I don’t feel anything yet” → double dose = trouble)
- Mixing multiple high-dose herbs
- Forgetting to track dose, time, and response
- Assuming plant = safe (e.g. MAOI risk from Syrian Rue)

---

### 📝 Best Practice: Keep a Dose Log

| Field | Why it helps |
|-------|--------------|
| Herb & prep | To repeat what worked |
| Dose (mg, g, drops) | To dial in sweet spot |
| Time of day | Circadian effects vary |
| Physical/emotional state | Context is everything |
| Outcome / notes | Mood, dreams, physical symptoms |

---

Your optimal dose isn’t on a chart — it’s discovered through slow experimentation, reflection, and respect.`
},
];