export const learnSections = [
{
  id: "history",
  title: "A Global History of Psychoactive Plants",
  content: `Psychoactive plants are among the oldest tools in human culture. They’ve been used for thousands of years — in medicine, divination, ceremony, warfare, birth, and death. Their stories stretch across every continent and civilization, reminding us that consciousness itself has always been a landscape we’ve explored.

---

### 🏺 Ancient Egypt
- **Blue Lotus (Nymphaea caerulea):** Considered a sacred flower of rebirth and divine ecstasy.
- Used in wine infusions during temple ceremonies.
- Depicted in tombs, papyri, and statues associated with the gods Nefertem and Ra.

---

### 🌀 Mesoamerica
- **Teonanácatl (“Flesh of the Gods”):** Refers to Psilocybin mushrooms used in Aztec and Mazatec rituals.
- **Ololiuqui:** A morning glory seed with LSA, used for divination.
- **Salvia divinorum:** Used by Mazatec curanderas (healers) for spiritual diagnosis.

> Plants here weren’t just pharmacological — they were spirit allies, teachers, and portals to divine knowledge.

---

### 🌳 Amazon Basin
- **Ayahuasca (Banisteriopsis caapi + admixtures):** Used for centuries (if not millennia) by Shipibo, Asháninka, and many others.
- Considered “La Medicina” — the medicine for healing body and spirit.
- Continues today in shamanic training, community diagnosis, and visionary art.

---

### 🦅 Sub-Saharan Africa
- **Iboga (Tabernanthe iboga):** Sacred to the Bwiti tradition in Gabon and Cameroon.
- Used in rites of passage, ancestor contact, and addiction recovery.
- Western clinics now explore its anti-addictive effects, especially with opioids.

- **Silene capensis (Dream Root):** Used by the Xhosa for dream incubation and receiving guidance.

---

### 🔥 European Folk Magic
- **Mandrake, Henbane, Belladonna:** Hallucinogenic “witch’s herbs” used in flying ointments, midwifery, and folk healing.
- Carried powerful archetypal and symbolic weight.
- Often feared and demonized during witch trials and church expansions.

- **Wormwood:** Used in absinthe, rituals, and to stimulate visions or drive away spirits.

---

### 🧘 South & East Asia
- **Cannabis:** Used in Ayurvedic, Taoist, and Tantric traditions.
- Sacred to Shiva, smoked by sadhus, or infused in bhang during Holi.
- Described in the Atharva Veda as one of the five sacred plants.

- **Tulsi (Holy Basil):** Used for focus, meditation, and harmonizing prana.

---

### ⛩ Shamanic Siberia & Arctic
- **Amanita muscaria (Fly Agaric):** Bright red mushroom with white spots.
- Used in indigenous Siberian traditions for altered states, weather magic, or hunting insight.
- Often consumed in ritual sequences (including recycling of active compounds through urine).

---

### ⏳ Colonial Suppression & Rediscovery
- 16th–20th centuries saw intense efforts to **ban**, **demonize**, and **erase** indigenous plant knowledge.
- Colonial powers outlawed ceremonial plants under "witchcraft" or "narcotics" frameworks.
- Yet even under pressure, plant wisdom persisted — encoded in songs, dreams, and resistance.

---

### 🔄 20th Century to Present
- 1960s–70s: Western psychonauts and ethnobotanists reintroduced plants like peyote, ayahuasca, and psilocybin to public discourse.
- 1990s–2000s: “Legal highs” wave — Salvia, Kratom, Blue Lotus sold online.
- 2020s: Scientific and clinical rebirth — psychedelic therapy, herbal nootropics, and global plant reawakening.

---

### 🌿 Summary Timeline

| Era | Key Herbs | Cultures |
|-----|-----------|----------|
| Ancient (3000 BCE+) | Blue Lotus, Cannabis, Ayahuasca | Egypt, Vedic India, Amazonia |
| Classical (~0–1000 CE) | Mandrake, Fly Agaric, Betel | Europe, Arctic, SE Asia |
| Colonial Suppression | Peyote, Salvia, Tobacco | Americas, Africa |
| Renaissance (~1960s–present) | Psilocybin, Ayahuasca, Kava | Global rediscovery |
| Future | ??? | You help write it |

---

To study these plants is to study humanity — our fears, dreams, and longing to know more. We don’t just use them — we walk with them.`
},
];