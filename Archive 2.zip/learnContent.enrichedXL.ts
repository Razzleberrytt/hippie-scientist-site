export const learnSections = [
{
  id: "intro",
  title: "What Are Psychoactive Herbs?",
  content: `**Psychoactive herbs** are plants that affect the brain, nervous system, and consciousness. They can change how we feel, think, perceive reality, sleep, and dream. Some are calming, others energizing, and a few can even spark visionary or altered states.

---

### 🌿 What Makes a Herb “Psychoactive”?

To be considered psychoactive, an herb must **interact with the central nervous system** and **alter brain function**. This includes changes in:

- Mood (e.g., relaxation, euphoria, clarity)
- Cognition (e.g., focus, memory, mental energy)
- Perception (e.g., vivid dreams, sensory shifts)
- Consciousness (e.g., introspection, trance states)
- Sleep and dream cycles (e.g., REM enhancement, lucidity)

These effects are caused by **natural plant compounds** such as alkaloids, flavonoids, terpenes, and glycosides, which bind to **neurotransmitter receptors** in the brain.

---

### 🧪 Common Neurochemical Targets

| Neurotransmitter | Associated Effects | Example Herbs |
|------------------|--------------------|----------------|
| GABA | Calm, sedation, anti-anxiety | Valerian, Skullcap |
| Serotonin | Mood elevation, sleep, dreams | Passionflower, Blue Lotus |
| Dopamine | Focus, motivation, pleasure | Mucuna pruriens |
| Acetylcholine | Memory, dreams, clarity | Calea ternifolia, Huperzia |
| Glutamate (NMDA) | Visionary states, dissociation | Salvia divinorum, Heimia salicifolia |

---

### 🧭 Why Do People Use Psychoactive Herbs?

These herbs have been used for millennia — for both practical and spiritual reasons:

#### 🛏 Sleep & Relaxation
Support for insomnia, anxiety, nervous tension  
→ Chamomile, Passionflower, Kava

#### 🌙 Dreamwork
Enhancing recall, vividness, and lucidity  
→ Calea, Silene, Blue Lotus

#### 🧠 Mental Clarity & Focus
Boosting memory, learning, or productivity  
→ Celastrus, Rhodiola, Gotu Kola

#### 🌀 Spiritual or Visionary States
Used in ceremonial or introspective contexts  
→ Salvia, Ayahuasca, Iboga

#### ❤️ Mood & Emotional Support
To balance low mood, apathy, or stress  
→ Lemon Balm, Mucuna, Ashwagandha

---

### 🏺 Cultural & Historical Significance

Psychoactive plants appear in ancient texts, oral traditions, and sacred rituals across nearly every indigenous culture:

- **Blue Lotus (Egypt):** Symbol of the soul’s journey and awakening  
- **Ayahuasca (Amazon):** Vine of the soul, used in healing and spiritual rites  
- **Iboga (Africa):** Rite-of-passage plant of the Bwiti  
- **Cannabis (India):** Sacred to Shiva and used in yogic practices  
- **Psilocybin mushrooms (Mesoamerica):** Tools of communion with the divine

---

### ⚖️ Are They Legal? Are They Safe?

Many psychoactive herbs are **legal**, non-addictive, and sold in herbal shops. Others are **regulated or banned** depending on jurisdiction (e.g., Kratom, Salvia, DMT admixtures). Safety depends on:

- **Proper identification and dosage**
- **Understanding interactions (esp. with MAOIs or SSRIs)**
- **Individual health conditions**
- **Preparation method (e.g., smoked vs tinctured)**

---

### 🧘 Responsible Exploration

Like any mind-altering tool, psychoactive herbs are best approached with:
- **Intention** (why are you taking it?)
- **Education** (what does it do and how?)
- **Respect** (especially with sacred/traditional plants)

These herbs are not just chemicals — they’re **living teachers**. Used wisely, they can help reconnect us to dreams, emotions, and ancestral plant wisdom.`
},
];