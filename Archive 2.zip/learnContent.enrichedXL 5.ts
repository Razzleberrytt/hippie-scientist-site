export const learnSections = [
{
  id: "preparation",
  title: "Herb Preparation Methods",
  content: `The way you prepare an herb deeply affects its potency, onset, and even the type of effect it produces. Some herbs shine in teas, others require alcohol extraction or must be smoked or chewed. Preparation is not just about chemistry — it’s also about ritual, relationship, and respect.

---

### 🍵 Infusions & Teas
**Best for:** Leaves, flowers, some soft stems

- **How:** Steep herb in hot (not boiling) water, covered, 5–15 minutes.
- **Examples:** Chamomile, Blue Lotus, Mugwort
- **Benefits:** Gentle, soothing, great for sleep or dream herbs
- **Tips:** Always cover to trap volatile oils; drink slowly with intention

---

### 🔥 Decoctions
**Best for:** Hard roots, barks, dense herbs

- **How:** Simmer in water for 15–30 minutes to break down tough plant material.
- **Examples:** Ashwagandha, Valerian, Rhodiola
- **Benefits:** Deep extraction of alkaloids and starches
- **Tools:** Use stainless steel or clay — avoid aluminum

---

### 💧 Tinctures
**Best for:** Preserving and concentrating active compounds (especially alkaloids)

- **How:** Alcohol (40–70%) used to extract plant material over weeks
- **Examples:** Passionflower, Kava, Damiana
- **Dosage:** Usually 1–3 mL (20–60 drops), sublingual or in water
- **Benefits:** Long shelf life, fast onset, easy storage

---

### 💊 Capsules & Powders
**Best for:** Daily routines, standard dosing

- **How:** Dried, powdered herb placed in capsules or taken as loose powder
- **Examples:** Ashwagandha, Mucuna, Celastrus, Maca
- **Tips:** Combine with warm liquids or smoothies for better absorption

---

### 🌬️ Smoking & Vaping
**Best for:** Dream herbs, resins, aromatic plants

- **How:** Dried herbs or resin are smoked alone or in blends
- **Examples:** Mugwort, Blue Lotus, Damiana, Wild Dagga
- **Effects:** Rapid onset, often more uplifting or visionary than sedative
- **Cautions:** Not for frequent use; harsh on lungs over time

---

### 👅 Sublingual Use
**Best for:** Fast absorption without digestion

- **How:** Place tincture or extract under tongue for 30–60 seconds
- **Examples:** Kanna, Kava tinctures, Blue Lotus
- **Tips:** Don’t eat immediately after; keep dose low for new users

---

### 🧪 Cold Water Infusion
**Best for:** Enzymatic herbs that degrade with heat

- **How:** Soak in cold or room temperature water for 6–12 hours
- **Examples:** Silene capensis (dream root), Celastrus seeds
- **Used for:** Dream preparation, gentle awakening of roots
- **Ritual Tip:** Use spring or filtered water for best effect

---

### 🧴 Oil Infusion & Topicals
**Best for:** External use, spiritual anointing, muscle pain

- **How:** Infuse dried herbs in oil for 2–6 weeks in sun or low heat
- **Examples:** Cannabis salves, Damiana massage oil, Arnica
- **Benefits:** Non-psychoactive route; great for somatic work or energy body support

---

### 🦷 Chewing or Eating Whole
**Best for:** Traditional uses of roots, seeds, or fermented herbs

- **How:** Chew or swallow herb slowly to activate salivary enzymes
- **Examples:** Kava root, Celastrus seeds, Betel nut (arecoline), Guarana paste
- **Traditions:** Often ceremonial — chewing herbs brings slower, deeper onset

---

### 🔄 Choosing the Right Method

| Herb | Best Prep | Why |
|------|-----------|-----|
| Calea ternifolia | Tea or smoke | Water-soluble dream alkaloids + quick onset |
| Mucuna | Powder/capsule | L-Dopa preserved in raw powder |
| Passionflower | Tincture or tea | Flavonoids extracted in both forms |
| Valerian | Decoction or tincture | Needs heat/alcohol to extract valerenic acids |
| Damiana | Smoke or tincture | Aroma-rich; euphoric oils respond to heat & alcohol |

---

The herb’s power lives in its preparation. Choose with care, experiment with awareness, and consider the ritual as part of the medicine.`
},
];