export const learnSections = [
{
  id: "effects",
  title: "Understanding Herbal Effects",
  content: `Herbs are not “one-size-fits-all.” Each psychoactive plant carries its own personality — a distinct fingerprint of physiological and emotional effects based on its chemistry, tradition, and preparation method.

Understanding these common effect categories helps you:
- Choose the right herb for your intention
- Understand what to expect
- Respect the potential power behind the plant

---

### 🌿 Sedative / Relaxant
- **Effect:** Calms the nervous system, reduces mental chatter, promotes sleep
- **Use for:** Anxiety, insomnia, restlessness, tension
- **Examples:** Skullcap, Valerian root, California poppy, Passionflower

**Preparation Tips:**
- Most effective as teas or tinctures taken 30–60 minutes before bed
- Synergizes well with adaptogens or dream herbs

---

### ⚡ Stimulant
- **Effect:** Enhances energy, alertness, motivation
- **Use for:** Fatigue, low mood, mental fog
- **Examples:** Guarana, Yerba Mate, Kola Nut, Ephedra (Ma Huang)

**Caution:**
- May increase anxiety or interfere with sleep
- Do not mix with other stimulants or pre-existing heart conditions

---

### 🛡️ Adaptogen
- **Effect:** Balances stress response over time, supports stamina, reduces burnout
- **Use for:** Chronic fatigue, stress recovery, immune resilience
- **Examples:** Ashwagandha, Rhodiola, Eleuthero, Schisandra

**Note:** Best used daily for 2–4 weeks, effects accumulate gradually

---

### 🧠 Nootropic
- **Effect:** Improves memory, learning, focus, verbal fluency, and/or creativity
- **Use for:** Mental performance, ADHD support, exam prep, long-term neuroprotection
- **Examples:** Celastrus, Gotu Kola, Bacopa, Lion’s Mane, Ginkgo

**Best combined with:** Cholinergics, adaptogens, and journaling to track effects

---

### 🌙 Dream-enhancing
- **Effect:** Increases dream recall, vividness, and lucidity
- **Use for:** Dream journaling, lucid training, subconscious exploration
- **Examples:** Calea ternifolia, Silene capensis, Mugwort, Blue Lotus

**Tips:**
- Set intention before sleep
- Avoid screen time for 30 min before bed
- Combine with sleep herbs for deeper integration

---

### 🔮 Psychedelic / Oneirogenic
- **Effect:** Alters sensory perception, deepens insight, induces visions or ego dissolution
- **Use for:** Introspection, ceremonial work, trauma integration
- **Examples:** Salvia divinorum, Ayahuasca (DMT+MAOI), Iboga, Fly Agaric

**Strong caution:** Dose, setting, and integration are vital. These are sacred medicines in many cultures and must be approached with reverence.

---

### 🪷 Euphoric / Mood-lifting
- **Effect:** Elevates mood, reduces emotional numbness, enhances pleasure
- **Use for:** Low motivation, stress, winter blues
- **Examples:** Mucuna pruriens, Kanna, Damiana, Blue Lotus

**May interact with:** Dopamine or serotonin-based medications

---

### 📊 Effect Type Matrix

| Effect Type | Energy Impact | Examples | Best Used For |
|-------------|----------------|----------|----------------|
| Sedative | ↓ Calms | Valerian, Skullcap | Sleep, anxiety |
| Stimulant | ↑ Energizes | Guarana, Yerba Mate | Focus, fatigue |
| Adaptogen | ⚖️ Balances | Ashwagandha, Rhodiola | Chronic stress |
| Nootropic | ↑ Mental focus | Celastrus, Gotu Kola | Study, work |
| Dream-enhancing | Alters sleep | Calea, Silene | Lucid dreams |
| Psychedelic | Alters perception | Salvia, Ayahuasca | Visionary states |
| Euphoric | Lifts mood | Kanna, Blue Lotus | Emotional release |

---

Some effects are dose-dependent — a low dose may be nootropic, while a high dose may be sedative or visionary. Always research, start low, and journal your experience.`
},
];