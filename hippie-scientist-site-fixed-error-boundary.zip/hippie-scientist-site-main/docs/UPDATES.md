[Hero Section Layout Fix - Mobile]
	•	Raised site title position for visual balance
	•	Limited hero to 1 featured herb preview card
	•	Removed excessive bottom spacing for first-screen fit
