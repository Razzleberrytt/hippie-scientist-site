export const UNKNOWN = 'Unknown';
export const NOT_WELL_DOCUMENTED = 'Not well documented';
