export function cardBg(dark: boolean) {
  return dark ? 'bg-gray-800/70 text-gray-100' : 'bg-white/70 text-gray-800'
}
