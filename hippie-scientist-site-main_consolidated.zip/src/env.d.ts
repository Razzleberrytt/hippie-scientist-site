declare const __BUILD_TIME__: string
