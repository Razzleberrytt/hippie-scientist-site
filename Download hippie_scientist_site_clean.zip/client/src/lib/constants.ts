export const PRODUCT_CATEGORIES = {
  ENHANCED_GUMMIES: "enhanced-gummies",
  CANNADELICS: "cannadelics",
  SILLY_DOTS: "silly-dots",
} as const;

export const CATEGORY_NAMES = {
  [PRODUCT_CATEGORIES.ENHANCED_GUMMIES]: "Enhanced Gummies",
  [PRODUCT_CATEGORIES.CANNADELICS]: "Cannadelics",
  [PRODUCT_CATEGORIES.SILLY_DOTS]: "Silly Dots",
} as const;

export const PRODUCT_FEATURES = [
  "No Artificial Colors",
  "Organic", 
  "Gluten Free",
  "Low Sugar",
  "Non-GMO",
  "Vegan",
] as const;

export const CONTACT_INFO = {
  EMAIL: "customerservice@purple-co.com",
  WHOLESALE_EMAIL: "wholesale@purple-co.com",
  BUSINESS_HOURS: "Monday - Friday: 10am - 5pm EST",
  SHIPPING: "All 50 US States",
} as const;
