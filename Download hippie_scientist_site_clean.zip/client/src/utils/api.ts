import axios from 'axios'

/**
 * API Configuration and utilities
 * Connects to the backend API hosted on Render
 */

// Base API URL from environment variable
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://hippie-sciences.onrender.com/api'

// Configure axios instance with base URL and default headers
export const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor for logging and authentication
api.interceptors.request.use(
  (config) => {
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`)
    return config
  },
  (error) => {
    console.error('API Request Error:', error)
    return Promise.reject(error)
  }
)

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    console.log(`API Response: ${response.status} ${response.config.url}`)
    return response
  },
  (error) => {
    console.error('API Response Error:', error)
    
    // Handle common error scenarios
    if (error.response?.status === 404) {
      console.error('API endpoint not found')
    } else if (error.response?.status === 500) {
      console.error('Server error')
    } else if (error.code === 'ECONNABORTED') {
      console.error('Request timeout')
    } else if (!error.response) {
      console.error('Network error - API server may be down')
    }
    
    return Promise.reject(error)
  }
)

/**
 * Blog API endpoints
 */
export const blogAPI = {
  // Get all blog posts
  getPosts: async () => {
    try {
      const response = await api.get('/blog/posts')
      return response.data
    } catch (error) {
      console.error('Failed to fetch blog posts:', error)
      throw error
    }
  },

  // Get single blog post by ID
  getPost: async (id: string) => {
    try {
      const response = await api.get(`/blog/posts/${id}`)
      return response.data
    } catch (error) {
      console.error(`Failed to fetch blog post ${id}:`, error)
      throw error
    }
  },

  // Get featured blog posts
  getFeaturedPosts: async () => {
    try {
      const response = await api.get('/blog/featured')
      return response.data
    } catch (error) {
      console.error('Failed to fetch featured blog posts:', error)
      throw error
    }
  }
}

/**
 * Herb Index API endpoints
 */
export const herbAPI = {
  // Get all herbs
  getHerbs: async () => {
    try {
      const response = await api.get('/herbs')
      return response.data
    } catch (error) {
      console.error('Failed to fetch herbs:', error)
      throw error
    }
  },

  // Get single herb by ID
  getHerb: async (id: string) => {
    try {
      const response = await api.get(`/herbs/${id}`)
      return response.data
    } catch (error) {
      console.error(`Failed to fetch herb ${id}:`, error)
      throw error
    }
  },

  // Get herbs by category
  getHerbsByCategory: async (category: string) => {
    try {
      const response = await api.get(`/herbs/category/${category}`)
      return response.data
    } catch (error) {
      console.error(`Failed to fetch herbs in category ${category}:`, error)
      throw error
    }
  },

  // Get herb categories
  getCategories: async () => {
    try {
      const response = await api.get('/herbs/categories')
      return response.data
    } catch (error) {
      console.error('Failed to fetch herb categories:', error)
      throw error
    }
  }
}

/**
 * Store API endpoints
 */
export const storeAPI = {
  // Get all products
  getProducts: async () => {
    try {
      const response = await api.get('/store/products')
      return response.data
    } catch (error) {
      console.error('Failed to fetch products:', error)
      throw error
    }
  },

  // Get single product by ID
  getProduct: async (id: string) => {
    try {
      const response = await api.get(`/store/products/${id}`)
      return response.data
    } catch (error) {
      console.error(`Failed to fetch product ${id}:`, error)
      throw error
    }
  },

  // Get products by category
  getProductsByCategory: async (category: string) => {
    try {
      const response = await api.get(`/store/products/category/${category}`)
      return response.data
    } catch (error) {
      console.error(`Failed to fetch products in category ${category}:`, error)
      throw error
    }
  },

  // Get product categories
  getCategories: async () => {
    try {
      const response = await api.get('/store/categories')
      return response.data
    } catch (error) {
      console.error('Failed to fetch product categories:', error)
      throw error
    }
  }
}

/**
 * Type definitions for API responses
 */
export interface BlogPost {
  id: string
  title: string
  content: string
  excerpt: string
  author: string
  publishDate: string
  category: string
  tags: string[]
  featured: boolean
  imageUrl?: string
}

export interface Herb {
  id: string
  name: string
  scientificName: string
  category: string
  description: string
  effects: string[]
  preparations: string[]
  dosage: string
  warnings: string[]
  legality: string
  imageUrl?: string
}

export interface Product {
  id: string
  name: string
  category: string
  description: string
  price: number
  currency: string
  inStock: boolean
  imageUrl?: string
  variants?: ProductVariant[]
}

export interface ProductVariant {
  id: string
  name: string
  price: number
  description?: string
}

/**
 * Error handling utility
 */
export const handleApiError = (error: any) => {
  if (error.response) {
    // Server responded with error status
    return {
      message: error.response.data?.message || 'Server error',
      status: error.response.status,
      data: error.response.data
    }
  } else if (error.request) {
    // Request was made but no response
    return {
      message: 'Network error - Unable to connect to server',
      status: 0,
      data: null
    }
  } else {
    // Something else happened
    return {
      message: error.message || 'Unknown error',
      status: 0,
      data: null
    }
  }
}

/**
 * Loading state utilities
 */
export const createLoadingState = () => ({
  isLoading: false,
  error: null as string | null,
  data: null as any
})

export const updateLoadingState = (state: any, loading: boolean, error: string | null = null, data: any = null) => ({
  isLoading: loading,
  error,
  data: data || state.data
})

export default api