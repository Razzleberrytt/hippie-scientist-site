import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

/**
 * Home page component with hero section and interactive visuals
 * Features psychedelic animations and call-to-action sections
 */
const Home: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="text-center z-10 max-w-4xl mx-auto px-4">
          <motion.h1
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-6xl md:text-8xl font-bold mb-6 text-glow-purple"
          >
            Welcome to the
            <br />
            <span className="text-glow-pink">Psychedelic</span>
            <br />
            <span className="text-glow-cyan">Experience</span>
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="text-xl md:text-2xl mb-8 text-gray-200"
          >
            Explore consciousness, discover wisdom, and journey into the unknown
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link
              to="/herbs"
              className="btn-psychedelic ripple px-8 py-4 text-lg font-semibold"
            >
              Explore Herbs
            </Link>
            <Link
              to="/store"
              className="btn-psychedelic ripple px-8 py-4 text-lg font-semibold"
            >
              Shop Products
            </Link>
          </motion.div>
        </div>
        
        {/* Animated geometric shapes */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-20 w-32 h-32 bg-gradient-to-br from-purple-400 to-pink-400 rounded-full opacity-20 animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-48 h-48 bg-gradient-to-br from-cyan-400 to-blue-400 rounded-full opacity-20 animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/4 w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full opacity-20 animate-pulse delay-2000"></div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl font-bold text-center mb-16 text-glow"
          >
            Discover Your Path
          </motion.h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Blog Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="glass-card hover:scale-105 transition-transform"
            >
              <div className="h-48 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg mb-6 flex items-center justify-center">
                <span className="text-6xl">📚</span>
              </div>
              <h3 className="text-2xl font-bold mb-4 text-glow-purple">Educational Blog</h3>
              <p className="text-gray-300 mb-6">
                Deep dive into the science, history, and cultural significance of psychoactive substances.
              </p>
              <Link
                to="/blog"
                className="btn-psychedelic ripple block text-center"
              >
                Read Articles
              </Link>
            </motion.div>

            {/* Herb Index Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="glass-card hover:scale-105 transition-transform"
            >
              <div className="h-48 bg-gradient-to-br from-green-500 to-cyan-500 rounded-lg mb-6 flex items-center justify-center">
                <span className="text-6xl">🌿</span>
              </div>
              <h3 className="text-2xl font-bold mb-4 text-glow-cyan">Herb Index</h3>
              <p className="text-gray-300 mb-6">
                Comprehensive database of psychoactive plants with detailed information and safety guidelines.
              </p>
              <Link
                to="/herbs"
                className="btn-psychedelic ripple block text-center"
              >
                Explore Database
              </Link>
            </motion.div>

            {/* Store Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="glass-card hover:scale-105 transition-transform"
            >
              <div className="h-48 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg mb-6 flex items-center justify-center">
                <span className="text-6xl">🛒</span>
              </div>
              <h3 className="text-2xl font-bold mb-4 text-glow-orange">Psychedelic Store</h3>
              <p className="text-gray-300 mb-6">
                Premium products including gummies, tinctures, and teas for your journey.
              </p>
              <Link
                to="/store"
                className="btn-psychedelic ripple block text-center"
              >
                Shop Now
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-purple-900/20 to-pink-900/20">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl font-bold mb-8 text-glow"
          >
            About Our Mission
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-gray-300 mb-8 leading-relaxed"
          >
            We believe in the power of consciousness exploration and the wisdom of ancient plant medicines. 
            Our platform provides educational resources, safety information, and carefully curated products 
            to support your journey of self-discovery and healing.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="glass-card text-left max-w-2xl mx-auto"
          >
            <h3 className="text-2xl font-bold mb-4 text-glow-purple">Our Values</h3>
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-center">
                <span className="text-green-400 mr-3">✓</span>
                Education and harm reduction
              </li>
              <li className="flex items-center">
                <span className="text-green-400 mr-3">✓</span>
                Scientific accuracy and research-based information
              </li>
              <li className="flex items-center">
                <span className="text-green-400 mr-3">✓</span>
                Respect for traditional and indigenous knowledge
              </li>
              <li className="flex items-center">
                <span className="text-green-400 mr-3">✓</span>
                Safe and responsible use practices
              </li>
            </ul>
          </motion.div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl font-bold mb-8 text-glow"
          >
            Ready to Begin Your Journey?
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-gray-300 mb-8"
          >
            Start with education, proceed with caution, and always prioritize safety.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link
              to="/blog"
              className="btn-psychedelic ripple px-8 py-4 text-lg font-semibold"
            >
              Start Learning
            </Link>
            <Link
              to="/herbs"
              className="btn-psychedelic ripple px-8 py-4 text-lg font-semibold"
            >
              Browse Herbs
            </Link>
          </motion.div>
        </div>
      </section>
    </div>
  )
}

export default Home