import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiSearch, FiFilter, FiInfo, FiAlertTriangle, FiClock, FiActivity } from 'react-icons/fi';
import { ParticleSystem } from '../components/effects/ParticleSystem';
import { useRippleEffect } from '../hooks/useRippleEffect';

// Substance interface
interface Substance {
  id: string;
  name: string;
  category: string;
  description: string;
  effects: string[];
  duration: {
    onset: string;
    peak: string;
    total: string;
  };
  dosage: {
    threshold: string;
    light: string;
    common: string;
    strong: string;
    heavy: string;
  };
  risks: string[];
  interactions: string[];
  legality: string;
  chemistry: string;
  image: string;
  riskLevel: 'low' | 'medium' | 'high';
}

// Mock psychoactive substance data - educational purposes only
const SUBSTANCES: Substance[] = [
  {
    id: '1',
    name: 'Psilocybin',
    category: 'Psychedelic',
    description: 'A naturally occurring psychedelic compound found in various mushroom species. Known for producing visual and auditory hallucinations, altered perception of time, and profound introspective experiences.',
    effects: ['Visual hallucinations', 'Euphoria', 'Introspection', 'Time distortion', 'Spiritual experiences'],
    duration: {
      onset: '20-40 minutes',
      peak: '1-2 hours',
      total: '4-6 hours'
    },
    dosage: {
      threshold: '0.25g',
      light: '0.25-1g',
      common: '1-2.5g',
      strong: '2.5-5g',
      heavy: '5g+'
    },
    risks: ['Anxiety', 'Panic attacks', 'Bad trips', 'HPPD (rare)'],
    interactions: ['MAOIs', 'SSRIs (reduced effects)', 'Lithium (dangerous)'],
    legality: 'Illegal in most countries, decriminalized in some regions',
    chemistry: 'C12H17N2O4P',
    image: 'https://images.unsplash.com/photo-1586375300773-8384e3e4916f?w=600&h=400&fit=crop',
    riskLevel: 'medium'
  },
  {
    id: '2',
    name: 'LSD',
    category: 'Psychedelic',
    description: 'Lysergic acid diethylamide is a powerful synthetic psychedelic known for producing intense visual hallucinations, synesthesia, and profound alterations in consciousness.',
    effects: ['Intense visuals', 'Synesthesia', 'Ego dissolution', 'Enhanced creativity', 'Emotional intensity'],
    duration: {
      onset: '30-90 minutes',
      peak: '3-5 hours',
      total: '8-12 hours'
    },
    dosage: {
      threshold: '15-25μg',
      light: '25-75μg',
      common: '75-150μg',
      strong: '150-300μg',
      heavy: '300μg+'
    },
    risks: ['Psychological dependence', 'HPPD', 'Anxiety', 'Flashbacks'],
    interactions: ['MAOIs', 'SSRIs (reduced effects)', 'Lithium (seizures)'],
    legality: 'Schedule I controlled substance worldwide',
    chemistry: 'C20H25N3O',
    image: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=600&h=400&fit=crop',
    riskLevel: 'medium'
  },
  {
    id: '3',
    name: 'MDMA',
    category: 'Empathogen',
    description: '3,4-Methylenedioxymethamphetamine is a synthetic drug known for producing empathy, emotional openness, and enhanced sensory perception.',
    effects: ['Empathy', 'Euphoria', 'Enhanced touch', 'Emotional openness', 'Increased energy'],
    duration: {
      onset: '30-60 minutes',
      peak: '1-2 hours',
      total: '3-6 hours'
    },
    dosage: {
      threshold: '30-50mg',
      light: '50-100mg',
      common: '100-150mg',
      strong: '150-200mg',
      heavy: '200mg+'
    },
    risks: ['Overheating', 'Dehydration', 'Serotonin syndrome', 'Neurotoxicity'],
    interactions: ['MAOIs (dangerous)', 'SSRIs', 'Stimulants'],
    legality: 'Schedule I, approved for therapeutic research',
    chemistry: 'C11H15NO2',
    image: 'https://images.unsplash.com/photo-1559656914-a30970c1affd?w=600&h=400&fit=crop',
    riskLevel: 'medium'
  },
  {
    id: '4',
    name: 'DMT',
    category: 'Psychedelic',
    description: 'N,N-Dimethyltryptamine is a powerful, short-acting psychedelic that produces intense visual hallucinations and breakthrough experiences.',
    effects: ['Breakthrough experiences', 'Entity encounters', 'Intense visuals', 'Time distortion', 'Spiritual insights'],
    duration: {
      onset: '0-2 minutes',
      peak: '2-15 minutes',
      total: '15-60 minutes'
    },
    dosage: {
      threshold: '10-20mg',
      light: '20-40mg',
      common: '40-60mg',
      strong: '60-100mg',
      heavy: '100mg+'
    },
    risks: ['Psychological trauma', 'Panic attacks', 'Reality dissociation'],
    interactions: ['MAOIs (Ayahuasca)', 'SSRIs (reduced effects)'],
    legality: 'Schedule I controlled substance',
    chemistry: 'C12H16N2',
    image: 'https://images.unsplash.com/photo-1571115764595-644a1f56a55c?w=600&h=400&fit=crop',
    riskLevel: 'high'
  },
  {
    id: '5',
    name: 'Cannabis',
    category: 'Cannabinoid',
    description: 'A psychoactive plant containing THC and CBD, known for producing relaxation, altered perception, and various therapeutic effects.',
    effects: ['Relaxation', 'Euphoria', 'Altered perception', 'Increased appetite', 'Pain relief'],
    duration: {
      onset: '5-30 minutes',
      peak: '30 minutes-2 hours',
      total: '2-4 hours'
    },
    dosage: {
      threshold: '2.5-5mg THC',
      light: '5-15mg THC',
      common: '15-30mg THC',
      strong: '30-50mg THC',
      heavy: '50mg+ THC'
    },
    risks: ['Anxiety', 'Paranoia', 'Respiratory issues (smoking)', 'Memory impairment'],
    interactions: ['Alcohol (enhanced effects)', 'Blood thinners'],
    legality: 'Legal in many regions, varying restrictions',
    chemistry: 'C21H30O2 (THC)',
    image: 'https://images.unsplash.com/photo-1544027993-37dbfe43562a?w=600&h=400&fit=crop',
    riskLevel: 'low'
  }
];

const CATEGORIES = ['All', 'Psychedelic', 'Empathogen', 'Cannabinoid', 'Stimulant', 'Depressant'];

// Substance card component
const SubstanceCard: React.FC<{
  substance: Substance;
  onViewDetails: (substance: Substance) => void;
}> = ({ substance, onViewDetails }) => {
  const { createRipple } = useRippleEffect();

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-400 border-green-400';
      case 'medium': return 'text-yellow-400 border-yellow-400';
      case 'high': return 'text-red-400 border-red-400';
      default: return 'text-gray-400 border-gray-400';
    }
  };

  const handleViewDetails = (event: React.MouseEvent<HTMLDivElement>): void => {
    createRipple(event, { color: 'var(--neon-purple)' });
    onViewDetails(substance);
  };

  return (
    <motion.div
      className="glass rounded-2xl overflow-hidden border border-purple-500/20 hover:border-purple-400/50 transition-all duration-500 cursor-pointer group"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -8, scale: 1.02 }}
      onClick={handleViewDetails}
    >
      {/* Image header */}
      <div className="relative h-48 overflow-hidden">
        <motion.img
          src={substance.image}
          alt={substance.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        
        {/* Risk level indicator */}
        <div className={`absolute top-4 right-4 px-2 py-1 rounded-full border text-xs font-semibold ${getRiskColor(substance.riskLevel)}`}>
          {substance.riskLevel.toUpperCase()} RISK
        </div>

        {/* Category badge */}
        <div className="absolute bottom-4 left-4 px-3 py-1 rounded-full bg-black/50 text-white text-sm">
          {substance.category}
        </div>
      </div>

      {/* Content */}
      <div className="p-6 space-y-4">
        <h3 className="text-2xl font-bold gradient-text group-hover:filter group-hover:brightness-110 transition-all">
          {substance.name}
        </h3>

        <p className="text-sm opacity-80 line-clamp-3">
          {substance.description}
        </p>

        {/* Key info */}
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center space-x-2">
            <FiClock className="text-cyan-400" />
            <span>Duration: {substance.duration.total}</span>
          </div>
          <div className="flex items-center space-x-2">
            <FiActivity className="text-purple-400" />
            <span>Onset: {substance.duration.onset}</span>
          </div>
        </div>

        {/* Effects preview */}
        <div className="flex flex-wrap gap-2">
          {substance.effects.slice(0, 3).map((effect, index) => (
            <span
              key={effect}
              className="px-2 py-1 text-xs rounded-full glass border border-opacity-30"
              style={{ borderColor: 'var(--neon-green)' }}
            >
              {effect}
            </span>
          ))}
          {substance.effects.length > 3 && (
            <span className="px-2 py-1 text-xs rounded-full opacity-60">
              +{substance.effects.length - 3} more
            </span>
          )}
        </div>

        <motion.button
          className="w-full py-2 px-4 bg-purple-500/20 hover:bg-purple-500/30 border border-purple-500/50 rounded-xl transition-colors text-sm"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          View Detailed Information
        </motion.button>
      </div>
    </motion.div>
  );
};

// Detailed substance modal
const SubstanceModal: React.FC<{
  substance: Substance | null;
  isOpen: boolean;
  onClose: () => void;
}> = ({ substance, isOpen, onClose }) => {
  if (!substance) return null;

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={(e) => e.target === e.currentTarget && onClose()}
          style={{
            backgroundColor: 'rgba(10, 10, 15, 0.9)',
            backdropFilter: 'blur(10px)'
          }}
        >
          <motion.div
            className="relative max-w-4xl w-full max-h-[90vh] overflow-hidden rounded-3xl glass border-2 border-purple-500/30"
            initial={{ scale: 0.8, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.8, y: 50 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="relative p-8 border-b border-purple-500/20">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 p-2 rounded-full glass hover:scale-110 transition-transform"
              >
                ✕
              </button>
              
              <div className="flex items-start space-x-6">
                <img
                  src={substance.image}
                  alt={substance.name}
                  className="w-24 h-24 rounded-2xl object-cover"
                />
                <div className="flex-1">
                  <h2 className="text-4xl font-bold gradient-text mb-2">
                    {substance.name}
                  </h2>
                  <div className="flex items-center space-x-4 text-sm">
                    <span className="px-3 py-1 rounded-full bg-purple-500/20 border border-purple-500/50">
                      {substance.category}
                    </span>
                    <span className={`px-3 py-1 rounded-full border ${getRiskColor(substance.riskLevel)}`}>
                      {substance.riskLevel.toUpperCase()} RISK
                    </span>
                  </div>
                  <p className="text-lg opacity-80 mt-4">
                    {substance.description}
                  </p>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="overflow-y-auto max-h-[60vh] p-8 space-y-8">
              
              {/* Duration & Dosage */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="glass p-6 rounded-2xl border border-cyan-500/20">
                  <h3 className="text-xl font-semibold mb-4 flex items-center space-x-2">
                    <FiClock className="text-cyan-400" />
                    <span>Duration</span>
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Onset:</span>
                      <span>{substance.duration.onset}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Peak:</span>
                      <span>{substance.duration.peak}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total:</span>
                      <span>{substance.duration.total}</span>
                    </div>
                  </div>
                </div>

                <div className="glass p-6 rounded-2xl border border-purple-500/20">
                  <h3 className="text-xl font-semibold mb-4 flex items-center space-x-2">
                    <FiActivity className="text-purple-400" />
                    <span>Dosage Guide</span>
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Threshold:</span>
                      <span>{substance.dosage.threshold}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Light:</span>
                      <span>{substance.dosage.light}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Common:</span>
                      <span>{substance.dosage.common}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Strong:</span>
                      <span>{substance.dosage.strong}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Heavy:</span>
                      <span>{substance.dosage.heavy}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Effects */}
              <div className="glass p-6 rounded-2xl border border-green-500/20">
                <h3 className="text-xl font-semibold mb-4 flex items-center space-x-2">
                  <FiInfo className="text-green-400" />
                  <span>Effects</span>
                </h3>
                <div className="flex flex-wrap gap-2">
                  {substance.effects.map((effect) => (
                    <span
                      key={effect}
                      className="px-3 py-1 text-sm rounded-full glass border border-green-500/30"
                    >
                      {effect}
                    </span>
                  ))}
                </div>
              </div>

              {/* Risks & Safety */}
              <div className="glass p-6 rounded-2xl border border-red-500/20">
                <h3 className="text-xl font-semibold mb-4 flex items-center space-x-2">
                  <FiAlertTriangle className="text-red-400" />
                  <span>Risks & Safety</span>
                </h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold mb-2">Potential Risks:</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm opacity-80">
                      {substance.risks.map((risk) => (
                        <li key={risk}>{risk}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">Drug Interactions:</h4>
                    <ul className="list-disc list-inside space-y-1 text-sm opacity-80">
                      {substance.interactions.map((interaction) => (
                        <li key={interaction}>{interaction}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Legal & Chemistry */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="glass p-6 rounded-2xl border border-yellow-500/20">
                  <h3 className="text-xl font-semibold mb-4">Legal Status</h3>
                  <p className="text-sm opacity-80">{substance.legality}</p>
                </div>
                <div className="glass p-6 rounded-2xl border border-blue-500/20">
                  <h3 className="text-xl font-semibold mb-4">Chemistry</h3>
                  <p className="text-sm opacity-80 font-mono">{substance.chemistry}</p>
                </div>
              </div>

              {/* Disclaimer */}
              <div className="bg-red-500/10 border border-red-500/30 rounded-2xl p-6">
                <h3 className="text-lg font-semibold text-red-400 mb-2">
                  Educational Purpose Only
                </h3>
                <p className="text-sm opacity-80">
                  This information is provided for educational and harm reduction purposes only. 
                  It is not intended to encourage illegal drug use. Always follow local laws and 
                  consult healthcare professionals before using any psychoactive substances.
                </p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

// Main page component
export const PsychoactiveIndexPage: React.FC = () => {
  const [selectedSubstance, setSelectedSubstance] = useState<Substance | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  // Filter substances
  const filteredSubstances = useMemo(() => {
    return SUBSTANCES.filter(substance => {
      const matchesSearch = !searchQuery ||
        substance.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        substance.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        substance.effects.some(effect => effect.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = selectedCategory === 'All' || substance.category === selectedCategory;
      
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, selectedCategory]);

  const handleViewDetails = (substance: Substance): void => {
    setSelectedSubstance(substance);
    setIsModalOpen(true);
  };

  const handleCloseModal = (): void => {
    setIsModalOpen(false);
    setSelectedSubstance(null);
  };

  return (
    <div className="relative min-h-screen pt-20">
      {/* Particle background */}
      <ParticleSystem particleCount={25} followMouse={false} />

      {/* Header */}
      <motion.div
        className="relative z-10 bg-gradient-to-r from-blue-900/50 to-purple-900/50 backdrop-blur-sm border-b border-blue-500/20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="max-w-7xl mx-auto px-4 py-12">
          <h1 className="text-5xl md:text-6xl font-bold gradient-text text-center mb-4">
            Psychoactive Index
          </h1>
          <p className="text-xl opacity-80 text-center max-w-3xl mx-auto">
            Comprehensive database of psychoactive substances with dosage, duration, 
            effects, and safety information for harm reduction and education.
          </p>
        </div>
      </motion.div>

      {/* Search and filters */}
      <motion.div
        className="relative z-10 max-w-7xl mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <div className="glass rounded-2xl p-6 border border-blue-500/20">
          <div className="flex flex-col lg:flex-row gap-6 items-center">
            
            {/* Search bar */}
            <div className="relative flex-1 max-w-md">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-400" />
              <input
                type="text"
                placeholder="Search substances..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white/10 border border-blue-500/30 rounded-xl focus:outline-none focus:border-blue-400 transition-colors"
              />
            </div>

            {/* Category filters */}
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((category) => (
                <motion.button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-xl transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-blue-500 text-white'
                      : 'bg-white/10 text-blue-300 hover:bg-white/20'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {category}
                </motion.button>
              ))}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Substances grid */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 pb-20">
        {filteredSubstances.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <AnimatePresence>
              {filteredSubstances.map((substance, index) => (
                <motion.div
                  key={substance.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                >
                  <SubstanceCard
                    substance={substance}
                    onViewDetails={handleViewDetails}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <motion.div
            className="text-center py-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <h3 className="text-2xl font-semibold mb-4">No substances found</h3>
            <p className="text-lg opacity-70 mb-8">
              Try adjusting your search terms or selecting a different category
            </p>
            <motion.button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="px-6 py-3 bg-blue-500 hover:bg-blue-600 rounded-xl transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Clear Filters
            </motion.button>
          </motion.div>
        )}
      </div>

      {/* Substance details modal */}
      <SubstanceModal
        substance={selectedSubstance}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
      />
    </div>
  );
};