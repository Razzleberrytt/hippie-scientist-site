import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { herbAPI, handleApiError, type Herb } from '../utils/api'

/**
 * HerbIndex page component displaying psychoactive herb database
 * Features detailed herb cards with safety information and effects
 */
const HerbIndex: React.FC = () => {
  const [herbs, setHerbs] = useState<Herb[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [selectedHerb, setSelectedHerb] = useState<Herb | null>(null)
  const [searchTerm, setSearchTerm] = useState('')

  // Load herbs from API
  useEffect(() => {
    const loadHerbs = async () => {
      try {
        setLoading(true)
        setError(null)
        const data = await herbAPI.getHerbs()
        setHerbs(data)
      } catch (err) {
        const apiError = handleApiError(err)
        setError(apiError.message)
        
        // Fallback to sample data when API is unavailable
        console.warn('Using fallback herb data due to API error:', apiError.message)
        setHerbs(sampleHerbs)
      } finally {
        setLoading(false)
      }
    }

    loadHerbs()
  }, [])

  // Filter herbs by category and search term
  const filteredHerbs = herbs.filter(herb => {
    const matchesCategory = selectedCategory === 'all' || herb.category === selectedCategory
    const matchesSearch = herb.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         herb.scientificName.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesCategory && matchesSearch
  })

  // Get unique categories
  const categories = ['all', ...Array.from(new Set(herbs.map(herb => herb.category)))]

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-spinner"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold mb-6 text-glow-green">
            🌿 Psychoactive Herb Index
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Comprehensive database of consciousness-expanding plants with detailed safety information,
            traditional uses, and modern research findings.
          </p>
        </motion.div>

        {/* Error Message */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card mb-8 bg-yellow-500/20 border-yellow-500/30"
          >
            <p className="text-yellow-300">
              ⚠️ Unable to connect to server: {error}. Showing sample content.
            </p>
          </motion.div>
        )}

        {/* Search and Filter Controls */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-12 space-y-6"
        >
          {/* Search Bar */}
          <div className="max-w-md mx-auto">
            <input
              type="text"
              placeholder="Search herbs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-3 bg-white/10 backdrop-blur-md border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-3 justify-center">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-full transition-all duration-300 ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-green-500 to-cyan-500 text-white'
                    : 'glass hover:bg-glass border border-white/20'
                }`}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Herbs Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredHerbs.map((herb, index) => (
            <motion.div
              key={herb.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="glass-card hover:scale-105 transition-transform group cursor-pointer"
              onClick={() => setSelectedHerb(herb)}
            >
              {/* Herb Image */}
              <div className="h-40 bg-gradient-to-br from-green-500 to-cyan-500 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
                {herb.imageUrl ? (
                  <img 
                    src={herb.imageUrl} 
                    alt={herb.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                ) : (
                  <span className="text-5xl opacity-80">🌿</span>
                )}
              </div>

              {/* Herb Info */}
              <div className="space-y-3">
                {/* Category Badge */}
                <span className="inline-block px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full text-xs font-semibold">
                  {herb.category}
                </span>

                {/* Name */}
                <h3 className="text-lg font-bold text-glow group-hover:text-glow-green transition-colors">
                  {herb.name}
                </h3>

                {/* Scientific Name */}
                <p className="text-sm text-gray-400 italic">
                  {herb.scientificName}
                </p>

                {/* Description */}
                <p className="text-sm text-gray-300 line-clamp-2">
                  {herb.description}
                </p>

                {/* Effects Preview */}
                <div className="flex flex-wrap gap-1">
                  {herb.effects.slice(0, 3).map((effect) => (
                    <span 
                      key={effect}
                      className="px-2 py-1 bg-white/10 rounded text-xs"
                    >
                      {effect}
                    </span>
                  ))}
                  {herb.effects.length > 3 && (
                    <span className="px-2 py-1 bg-white/10 rounded text-xs">
                      +{herb.effects.length - 3} more
                    </span>
                  )}
                </div>

                {/* Legality Indicator */}
                <div className="flex items-center justify-between text-xs">
                  <span className={`px-2 py-1 rounded ${
                    herb.legality.toLowerCase().includes('legal') 
                      ? 'bg-green-500/20 text-green-300' 
                      : herb.legality.toLowerCase().includes('regulated')
                      ? 'bg-yellow-500/20 text-yellow-300'
                      : 'bg-red-500/20 text-red-300'
                  }`}>
                    {herb.legality}
                  </span>
                  <span className="text-gray-400">Click for details</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* No Results Message */}
        {filteredHerbs.length === 0 && !loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <p className="text-xl text-gray-400">
              No herbs found matching your criteria.
            </p>
          </motion.div>
        )}

        {/* Herb Detail Modal */}
        {selectedHerb && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedHerb(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass-card max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-glow-green mb-2">
                    {selectedHerb.name}
                  </h2>
                  <p className="text-gray-400 italic">{selectedHerb.scientificName}</p>
                </div>
                <button
                  onClick={() => setSelectedHerb(null)}
                  className="text-gray-400 hover:text-white text-2xl"
                >
                  ×
                </button>
              </div>

              <div className="space-y-6">
                {/* Description */}
                <div>
                  <h3 className="text-xl font-bold mb-3 text-glow">Description</h3>
                  <p className="text-gray-300">{selectedHerb.description}</p>
                </div>

                {/* Effects */}
                <div>
                  <h3 className="text-xl font-bold mb-3 text-glow">Effects</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedHerb.effects.map((effect) => (
                      <span 
                        key={effect}
                        className="px-3 py-2 bg-purple-500/20 rounded-lg text-sm"
                      >
                        {effect}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Preparations */}
                <div>
                  <h3 className="text-xl font-bold mb-3 text-glow">Preparations</h3>
                  <ul className="list-disc list-inside text-gray-300 space-y-1">
                    {selectedHerb.preparations.map((prep, idx) => (
                      <li key={idx}>{prep}</li>
                    ))}
                  </ul>
                </div>

                {/* Dosage */}
                <div>
                  <h3 className="text-xl font-bold mb-3 text-glow">Dosage</h3>
                  <p className="text-gray-300">{selectedHerb.dosage}</p>
                </div>

                {/* Warnings */}
                {selectedHerb.warnings.length > 0 && (
                  <div>
                    <h3 className="text-xl font-bold mb-3 text-red-400">⚠️ Warnings</h3>
                    <ul className="list-disc list-inside text-red-300 space-y-1">
                      {selectedHerb.warnings.map((warning, idx) => (
                        <li key={idx}>{warning}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Legality */}
                <div>
                  <h3 className="text-xl font-bold mb-3 text-glow">Legal Status</h3>
                  <p className={`font-semibold ${
                    selectedHerb.legality.toLowerCase().includes('legal') 
                      ? 'text-green-300' 
                      : selectedHerb.legality.toLowerCase().includes('regulated')
                      ? 'text-yellow-300'
                      : 'text-red-300'
                  }`}>
                    {selectedHerb.legality}
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  )
}

// Sample herbs for fallback when API is unavailable
const sampleHerbs: Herb[] = [
  {
    id: '1',
    name: 'Psilocybe Cubensis',
    scientificName: 'Psilocybe cubensis',
    category: 'psychedelic',
    description: 'A species of psychedelic mushroom containing psilocybin and psilocin, known for producing visual hallucinations and altered states of consciousness.',
    effects: ['Visual hallucinations', 'Euphoria', 'Introspection', 'Time distortion', 'Synesthesia'],
    preparations: ['Dried mushrooms', 'Tea', 'Capsules', 'Honey extraction'],
    dosage: 'Threshold: 0.25g, Light: 0.5-1g, Common: 1-2.5g, Strong: 2.5-5g, Heavy: 5g+',
    warnings: ['May cause anxiety or panic', 'Not recommended for people with mental health conditions', 'Can interact with certain medications'],
    legality: 'Controlled substance in most countries',
    imageUrl: 'https://images.unsplash.com/photo-1586375300773-8384e3e4916f?w=400'
  },
  {
    id: '2',
    name: 'Cannabis',
    scientificName: 'Cannabis sativa',
    category: 'cannabinoid',
    description: 'A psychoactive plant used for recreational and medicinal purposes, containing THC and CBD among other cannabinoids.',
    effects: ['Relaxation', 'Euphoria', 'Increased appetite', 'Pain relief', 'Altered perception'],
    preparations: ['Smoking', 'Vaporizing', 'Edibles', 'Tinctures', 'Topicals'],
    dosage: 'Varies greatly by preparation and tolerance. Start low and go slow.',
    warnings: ['May impair driving ability', 'Can cause anxiety in some users', 'Potential for dependency'],
    legality: 'Legal in some regions, controlled in others',
    imageUrl: 'https://images.unsplash.com/photo-1516775080-1a19ce35154b?w=400'
  },
  {
    id: '3',
    name: 'Salvia Divinorum',
    scientificName: 'Salvia divinorum',
    category: 'dissociative',
    description: 'A plant with intense but short-lasting psychoactive effects, traditionally used by Mazatec shamans.',
    effects: ['Reality distortion', 'Out-of-body experiences', 'Intense visions', 'Time distortion'],
    preparations: ['Smoking', 'Quid chewing', 'Tincture'],
    dosage: 'Threshold: 0.25g, Light: 0.5g, Common: 1g, Strong: 1.5g+',
    warnings: ['Extremely intense effects', 'Risk of physical harm due to disorientation', 'Not for beginners'],
    legality: 'Legal in most places, some restrictions apply',
    imageUrl: 'https://images.unsplash.com/photo-1574263867128-a3d5c1b1deae?w=400'
  },
  {
    id: '4',
    name: 'Kratom',
    scientificName: 'Mitragyna speciosa',
    category: 'stimulant',
    description: 'A tropical tree with leaves that have psychoactive properties, traditionally used in Southeast Asia.',
    effects: ['Pain relief', 'Stimulation', 'Mood enhancement', 'Relaxation'],
    preparations: ['Powder', 'Capsules', 'Tea', 'Extract'],
    dosage: 'Light: 1-2g, Moderate: 2-4g, Strong: 4-8g',
    warnings: ['Potential for dependency', 'May interact with medications', 'Quality control issues'],
    legality: 'Legal in most US states, banned in some countries',
    imageUrl: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=400'
  }
]

export default HerbIndex