import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiFilter, FiSearch, FiGrid, FiList } from 'react-icons/fi';
import { ProductCard, Product } from '../components/ui/ProductCard';
import { ProductModal } from '../components/ui/ProductModal';
import { ParticleSystem } from '../components/effects/ParticleSystem';
import { useRippleEffect } from '../hooks/useRippleEffect';

// Mock product data - replace with API call
const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Psilocybe Cubensis Extract',
    description: 'Premium psilocybin extract for enhanced consciousness exploration. Carefully processed for optimal potency and purity.',
    price: 89.99,
    image: 'https://images.unsplash.com/photo-1586375300773-8384e3e4916f?w=800&h=800&fit=crop',
    category: 'Psilocybin',
    potency: '2.5g equivalent per dose',
    effects: ['Euphoria', 'Visual Enhancement', 'Introspection'],
    inStock: true,
    featured: true
  },
  {
    id: '2',
    name: 'Golden Teacher Microdose',
    description: 'Precision-dosed Golden Teacher mushrooms for microdosing protocols. Perfect for beginners and experienced users.',
    price: 45.99,
    image: 'https://images.unsplash.com/photo-1459411621453-7b03977f4bfc?w=800&h=800&fit=crop',
    category: 'Psilocybin',
    potency: '0.1g per capsule',
    effects: ['Focus', 'Creativity', 'Mood Enhancement'],
    inStock: true
  },
  {
    id: '3',
    name: 'LSD Blotter Art Collection',
    description: 'Authentic vintage blotter art for collectors and enthusiasts. Historical significance with artistic value.',
    price: 120.00,
    image: 'https://images.unsplash.com/photo-1541961017774-22349e4a1262?w=800&h=800&fit=crop',
    category: 'LSD',
    potency: 'Art piece only',
    effects: ['Collectible'],
    inStock: false
  },
  {
    id: '4',
    name: 'DMT Vaporizer Kit',
    description: 'Complete vaporization setup designed specifically for DMT experiences. Includes temperature control and safety guide.',
    price: 299.99,
    image: 'https://images.unsplash.com/photo-1571115764595-644a1f56a55c?w=800&h=800&fit=crop',
    category: 'DMT',
    potency: 'Device only',
    effects: ['Vaporization Tool'],
    inStock: true,
    featured: true
  },
  {
    id: '5',
    name: 'Ayahuasca Preparation Kit',
    description: 'Traditional ayahuasca brewing kit with authentic ingredients and comprehensive preparation guide.',
    price: 199.99,
    image: 'https://images.unsplash.com/photo-1544127568-1d6e7d28e2e8?w=800&h=800&fit=crop',
    category: 'Ayahuasca',
    potency: 'Traditional strength',
    effects: ['Spiritual Journey', 'Healing', 'Purging'],
    inStock: true
  },
  {
    id: '6',
    name: 'MDMA Test Kit',
    description: 'Professional reagent testing kit for MDMA purity verification. Essential for harm reduction and safety.',
    price: 35.99,
    image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=800&h=800&fit=crop',
    category: 'Testing',
    potency: 'Testing reagents',
    effects: ['Harm Reduction'],
    inStock: true
  }
];

// Filter and sort options
const CATEGORIES = ['All', 'Psilocybin', 'LSD', 'DMT', 'Ayahuasca', 'Testing'];
const SORT_OPTIONS = [
  { label: 'Featured', value: 'featured' },
  { label: 'Price: Low to High', value: 'price-asc' },
  { label: 'Price: High to Low', value: 'price-desc' },
  { label: 'Name A-Z', value: 'name-asc' },
  { label: 'Name Z-A', value: 'name-desc' }
];

export const StorePage: React.FC = () => {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('featured');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  
  const { createRipple } = useRippleEffect();

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    let filtered = MOCK_PRODUCTS;

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(product =>
        product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (selectedCategory !== 'All') {
      filtered = filtered.filter(product => product.category === selectedCategory);
    }

    // Sorting
    switch (sortBy) {
      case 'featured':
        filtered.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
        break;
      case 'price-asc':
        filtered.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        filtered.sort((a, b) => b.price - a.price);
        break;
      case 'name-asc':
        filtered.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'name-desc':
        filtered.sort((a, b) => b.name.localeCompare(a.name));
        break;
    }

    return filtered;
  }, [searchQuery, selectedCategory, sortBy]);

  // Handle product actions
  const handleViewDetails = (product: Product): void => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const handleAddToCart = (productId: string): void => {
    // TODO: Implement cart functionality
    console.log('Added to cart:', productId);
  };

  const handleCloseModal = (): void => {
    setIsModalOpen(false);
    setSelectedProduct(null);
  };

  return (
    <div className="relative min-h-screen pt-20">
      {/* Particle background */}
      <ParticleSystem particleCount={20} followMouse={false} />

      {/* Header */}
      <motion.div
        className="relative z-10 bg-gradient-to-r from-purple-900/50 to-pink-900/50 backdrop-blur-sm border-b border-purple-500/20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="max-w-7xl mx-auto px-4 py-12">
          <h1 className="text-5xl md:text-6xl font-bold gradient-text text-center mb-4">
            Psychedelic Store
          </h1>
          <p className="text-xl opacity-80 text-center max-w-3xl mx-auto">
            Explore our carefully curated collection of consciousness-expanding products,
            tools, and educational resources.
          </p>
        </div>
      </motion.div>

      {/* Filters and Search */}
      <motion.div
        className="relative z-10 max-w-7xl mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <div className="glass rounded-2xl p-6 border border-purple-500/20">
          <div className="flex flex-col lg:flex-row gap-6 items-center">
            
            {/* Search bar */}
            <div className="relative flex-1 max-w-md">
              <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-purple-400" />
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-white/10 border border-purple-500/30 rounded-xl focus:outline-none focus:border-purple-400 transition-colors"
              />
            </div>

            {/* Category filters */}
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((category) => (
                <motion.button
                  key={category}
                  onClick={(e) => {
                    createRipple(e);
                    setSelectedCategory(category);
                  }}
                  className={`px-4 py-2 rounded-xl transition-all duration-300 ${
                    selectedCategory === category
                      ? 'bg-purple-500 text-white'
                      : 'bg-white/10 text-purple-300 hover:bg-white/20'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {category}
                </motion.button>
              ))}
            </div>

            {/* Sort and view controls */}
            <div className="flex items-center gap-4">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="px-4 py-2 bg-white/10 border border-purple-500/30 rounded-xl focus:outline-none focus:border-purple-400"
              >
                {SORT_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>

              <div className="flex border border-purple-500/30 rounded-xl overflow-hidden">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`p-2 transition-colors ${
                    viewMode === 'grid' ? 'bg-purple-500 text-white' : 'text-purple-400'
                  }`}
                >
                  <FiGrid size={20} />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 transition-colors ${
                    viewMode === 'list' ? 'bg-purple-500 text-white' : 'text-purple-400'
                  }`}
                >
                  <FiList size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Products grid */}
      <motion.div
        className="relative z-10 max-w-7xl mx-auto px-4 pb-20"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
      >
        {filteredProducts.length > 0 ? (
          <div className={`grid gap-8 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3' 
              : 'grid-cols-1'
          }`}>
            <AnimatePresence>
              {filteredProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ delay: index * 0.1, duration: 0.5 }}
                >
                  <ProductCard
                    product={product}
                    onViewDetails={handleViewDetails}
                    onAddToCart={handleAddToCart}
                    className={viewMode === 'list' ? 'flex-row' : ''}
                  />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <motion.div
            className="text-center py-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <h3 className="text-2xl font-semibold mb-4">No products found</h3>
            <p className="text-lg opacity-70 mb-8">
              Try adjusting your search terms or filters
            </p>
            <motion.button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="px-6 py-3 bg-purple-500 hover:bg-purple-600 rounded-xl transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Clear Filters
            </motion.button>
          </motion.div>
        )}
      </motion.div>

      {/* Product Modal */}
      <ProductModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        onAddToCart={handleAddToCart}
      />
    </div>
  );
};