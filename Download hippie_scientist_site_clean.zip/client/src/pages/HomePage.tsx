import React from 'react';
import { motion } from 'framer-motion';
import { FiArrowRight, FiZap, FiEye, FiHeart } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { ParticleSystem } from '../components/effects/ParticleSystem';
import { useRippleEffect } from '../hooks/useRippleEffect';

// Hero section component with psychedelic animations
const HeroSection: React.FC = () => {
  const { createPsychedelicRipple } = useRippleEffect();

  const handleCTAClick = (event: React.MouseEvent<HTMLAnchorElement>): void => {
    createPsychedelicRipple(event);
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      
      {/* Animated background */}
      <motion.div
        className="absolute inset-0 opacity-30"
        style={{ background: 'var(--gradient-psychedelic)' }}
        animate={{
          backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
        }}
        transition={{ duration: 10, repeat: Infinity }}
      />

      {/* Content container */}
      <div className="relative z-10 text-center max-w-6xl mx-auto px-4">
        
        {/* Main heading with staggered animation */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="mb-8"
        >
          <motion.h1
            className="text-6xl md:text-8xl lg:text-9xl font-bold mb-6"
            style={{
              background: 'var(--gradient-psychedelic)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
            animate={{
              backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            PSYCHE
          </motion.h1>
          
          <motion.p
            className="text-xl md:text-2xl opacity-80 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
          >
            Explore consciousness through premium psychedelic experiences.
            <br />
            <span className="gradient-text font-semibold">
              Scientifically curated. Responsibly sourced. Safely delivered.
            </span>
          </motion.p>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8, duration: 0.8 }}
        >
          <Link
            to="/store"
            onClick={handleCTAClick}
            className="group relative px-8 py-4 rounded-2xl font-semibold text-lg transition-all duration-300 overflow-hidden"
          >
            {/* Button background */}
            <motion.div
              className="absolute inset-0 rounded-2xl"
              style={{ background: 'var(--gradient-cosmic)' }}
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400 }}
            />
            
            {/* Button content */}
            <span className="relative z-10 flex items-center space-x-2 text-white">
              <span>Explore Store</span>
              <motion.div
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <FiArrowRight />
              </motion.div>
            </span>
          </Link>

          <Link
            to="/psychoactive-index"
            className="group px-8 py-4 rounded-2xl font-semibold text-lg glass border-2 border-opacity-50 hover:border-opacity-100 transition-all duration-300"
            style={{ borderColor: 'var(--neon-cyan)' }}
          >
            <span className="flex items-center space-x-2">
              <FiEye className="text-cyan-400" />
              <span>Psychoactive Index</span>
            </span>
          </Link>
        </motion.div>

        {/* Feature highlights */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2, duration: 0.8 }}
        >
          {[
            {
              icon: FiZap,
              title: "Lab Tested",
              description: "Every product undergoes rigorous testing for purity and potency"
            },
            {
              icon: FiHeart,
              title: "Safe & Legal",
              description: "Compliant with local regulations and safety standards"
            },
            {
              icon: FiEye,
              title: "Educational",
              description: "Comprehensive guides and dosage information included"
            }
          ].map((feature, index) => (
            <motion.div
              key={feature.title}
              className="glass p-6 rounded-2xl border border-opacity-20 hover:border-opacity-50 transition-all duration-300"
              style={{ borderColor: 'var(--neon-purple)' }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.4 + index * 0.2 }}
              whileHover={{ y: -5, scale: 1.02 }}
            >
              <feature.icon 
                size={32} 
                className="mx-auto mb-4 text-purple-400 pulse-glow" 
              />
              <h3 className="text-lg font-semibold mb-2 gradient-text">
                {feature.title}
              </h3>
              <p className="text-sm opacity-80">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Floating geometric shapes */}
      <motion.div
        className="absolute top-20 left-20 w-20 h-20 rounded-full opacity-20"
        style={{ background: 'var(--neon-pink)' }}
        animate={{
          y: [0, -20, 0],
          rotate: [0, 180, 360],
        }}
        transition={{ duration: 8, repeat: Infinity }}
      />
      
      <motion.div
        className="absolute bottom-20 right-20 w-16 h-16 opacity-20"
        style={{ 
          background: 'var(--neon-cyan)',
          clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)'
        }}
        animate={{
          y: [0, 15, 0],
          rotate: [0, -180, -360],
        }}
        transition={{ duration: 6, repeat: Infinity }}
      />

      <motion.div
        className="absolute top-1/2 right-10 w-12 h-12 opacity-20"
        style={{ 
          background: 'var(--neon-green)',
          clipPath: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)'
        }}
        animate={{
          x: [0, 10, 0],
          rotate: [0, 120, 240, 360],
        }}
        transition={{ duration: 10, repeat: Infinity }}
      />
    </section>
  );
};

// Features section component
const FeaturesSection: React.FC = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold gradient-text mb-6">
            Why Choose PsycheCo?
          </h2>
          <p className="text-xl opacity-80 max-w-3xl mx-auto">
            We're committed to providing safe, educational, and transformative experiences
            through carefully curated psychedelic products and comprehensive resources.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              title: "Premium Quality",
              description: "Sourced from trusted suppliers with rigorous quality control",
              gradient: "var(--gradient-psychedelic)"
            },
            {
              title: "Educational Resources",
              description: "Comprehensive guides, dosing charts, and safety information",
              gradient: "var(--gradient-cosmic)"
            },
            {
              title: "Discrete Shipping",
              description: "Professional packaging with complete privacy protection",
              gradient: "var(--gradient-aurora)"
            },
            {
              title: "Expert Support",
              description: "Knowledgeable team available for guidance and questions",
              gradient: "var(--gradient-psychedelic)"
            }
          ].map((feature, index) => (
            <motion.div
              key={feature.title}
              className="glass p-6 rounded-2xl border border-opacity-20 hover:border-opacity-50 transition-all duration-300 group"
              style={{ borderColor: 'var(--neon-purple)' }}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.6 }}
              whileHover={{ y: -8, scale: 1.02 }}
            >
              <motion.div
                className="w-full h-2 rounded-full mb-6 opacity-60 group-hover:opacity-100 transition-opacity"
                style={{ background: feature.gradient }}
                animate={{
                  backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              
              <h3 className="text-xl font-semibold mb-3 gradient-text">
                {feature.title}
              </h3>
              <p className="text-sm opacity-80">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// Main HomePage component
export const HomePage: React.FC = () => {
  return (
    <div className="relative">
      {/* Particle system background */}
      <ParticleSystem particleCount={30} followMouse={true} />
      
      {/* Page content */}
      <main className="relative z-10">
        <HeroSection />
        <FeaturesSection />
      </main>
    </div>
  );
};