import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { storeAPI, handleApiError, type Product } from '../utils/api'

/**
 * Store page component displaying psychedelic products
 * Features shopping cart functionality and product filtering
 */
const Store: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [cart, setCart] = useState<{[key: string]: number}>({})
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  // Load products from API
  useEffect(() => {
    const loadProducts = async () => {
      try {
        setLoading(true)
        setError(null)
        const data = await storeAPI.getProducts()
        setProducts(data)
      } catch (err) {
        const apiError = handleApiError(err)
        setError(apiError.message)
        
        // Fallback to sample data when API is unavailable
        console.warn('Using fallback product data due to API error:', apiError.message)
        setProducts(sampleProducts)
      } finally {
        setLoading(false)
      }
    }

    loadProducts()
  }, [])

  // Filter products by category
  const filteredProducts = selectedCategory === 'all' 
    ? products 
    : products.filter(product => product.category === selectedCategory)

  // Get unique categories
  const categories = ['all', ...Array.from(new Set(products.map(product => product.category)))]

  // Cart functions
  const addToCart = (productId: string) => {
    setCart(prev => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1
    }))
  }

  const removeFromCart = (productId: string) => {
    setCart(prev => {
      const newCart = { ...prev }
      if (newCart[productId] > 1) {
        newCart[productId]--
      } else {
        delete newCart[productId]
      }
      return newCart
    })
  }

  const getCartTotal = () => {
    return Object.entries(cart).reduce((total, [productId, quantity]) => {
      const product = products.find(p => p.id === productId)
      return total + (product ? product.price * quantity : 0)
    }, 0)
  }

  const getCartItemCount = () => {
    return Object.values(cart).reduce((total, quantity) => total + quantity, 0)
  }

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-spinner"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-20 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold mb-6 text-glow-orange">
            🛒 Psychedelic Store
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Premium psychedelic products including gummies, tinctures, and teas crafted with care
            for your consciousness exploration journey.
          </p>
        </motion.div>

        {/* Error Message */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card mb-8 bg-yellow-500/20 border-yellow-500/30"
          >
            <p className="text-yellow-300">
              ⚠️ Unable to connect to server: {error}. Showing sample products.
            </p>
          </motion.div>
        )}

        {/* Cart Summary */}
        {getCartItemCount() > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card mb-8 bg-green-500/20 border-green-500/30"
          >
            <div className="flex justify-between items-center">
              <span className="text-green-300">
                🛒 Cart: {getCartItemCount()} items
              </span>
              <span className="text-green-300 font-bold">
                Total: ${getCartTotal().toFixed(2)}
              </span>
            </div>
          </motion.div>
        )}

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-wrap gap-3 mb-12 justify-center"
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-full transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-orange-500 to-red-500 text-white'
                  : 'glass hover:bg-glass border border-white/20'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </motion.div>

        {/* Products Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="glass-card hover:scale-105 transition-transform group"
            >
              {/* Product Image */}
              <div className="h-48 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg mb-4 flex items-center justify-center overflow-hidden">
                {product.imageUrl ? (
                  <img 
                    src={product.imageUrl} 
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                ) : (
                  <span className="text-5xl opacity-80">
                    {product.category === 'gummies' ? '🍬' : 
                     product.category === 'tinctures' ? '💧' : 
                     product.category === 'teas' ? '🍵' : '🌟'}
                  </span>
                )}
              </div>

              {/* Product Info */}
              <div className="space-y-3">
                {/* Category Badge */}
                <span className="inline-block px-3 py-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full text-xs font-semibold">
                  {product.category}
                </span>

                {/* Name and Price */}
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-bold text-glow group-hover:text-glow-orange transition-colors">
                    {product.name}
                  </h3>
                  <span className="text-lg font-bold text-green-400">
                    ${product.price.toFixed(2)}
                  </span>
                </div>

                {/* Description */}
                <p className="text-sm text-gray-300 line-clamp-2">
                  {product.description}
                </p>

                {/* Stock Status */}
                <div className="flex items-center justify-between text-sm">
                  <span className={`px-2 py-1 rounded ${
                    product.inStock 
                      ? 'bg-green-500/20 text-green-300' 
                      : 'bg-red-500/20 text-red-300'
                  }`}>
                    {product.inStock ? 'In Stock' : 'Out of Stock'}
                  </span>
                  {cart[product.id] && (
                    <span className="text-purple-400">
                      In cart: {cart[product.id]}
                    </span>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedProduct(product)}
                    className="flex-1 btn-psychedelic ripple text-sm py-2"
                  >
                    View Details
                  </button>
                  {product.inStock && (
                    <button
                      onClick={() => addToCart(product.id)}
                      className="px-4 py-2 bg-green-500 hover:bg-green-600 rounded-lg transition-colors text-sm font-semibold"
                    >
                      Add to Cart
                    </button>
                  )}
                </div>

                {/* Cart Controls */}
                {cart[product.id] && (
                  <div className="flex items-center justify-center gap-3 mt-2">
                    <button
                      onClick={() => removeFromCart(product.id)}
                      className="px-3 py-1 bg-red-500 hover:bg-red-600 rounded transition-colors"
                    >
                      -
                    </button>
                    <span className="font-semibold">{cart[product.id]}</span>
                    <button
                      onClick={() => addToCart(product.id)}
                      className="px-3 py-1 bg-green-500 hover:bg-green-600 rounded transition-colors"
                    >
                      +
                    </button>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>

        {/* No Products Message */}
        {filteredProducts.length === 0 && !loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <p className="text-xl text-gray-400">
              No products found in this category.
            </p>
          </motion.div>
        )}

        {/* Product Detail Modal */}
        {selectedProduct && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedProduct(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="glass-card max-w-2xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-glow-orange mb-2">
                    {selectedProduct.name}
                  </h2>
                  <p className="text-2xl font-bold text-green-400">
                    ${selectedProduct.price.toFixed(2)} {selectedProduct.currency}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="text-gray-400 hover:text-white text-2xl"
                >
                  ×
                </button>
              </div>

              <div className="space-y-6">
                {/* Product Image */}
                <div className="h-64 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
                  {selectedProduct.imageUrl ? (
                    <img 
                      src={selectedProduct.imageUrl} 
                      alt={selectedProduct.name}
                      className="w-full h-full object-cover rounded-lg"
                    />
                  ) : (
                    <span className="text-8xl opacity-80">
                      {selectedProduct.category === 'gummies' ? '🍬' : 
                       selectedProduct.category === 'tinctures' ? '💧' : 
                       selectedProduct.category === 'teas' ? '🍵' : '🌟'}
                    </span>
                  )}
                </div>

                {/* Description */}
                <div>
                  <h3 className="text-xl font-bold mb-3 text-glow">Description</h3>
                  <p className="text-gray-300">{selectedProduct.description}</p>
                </div>

                {/* Stock and Category */}
                <div className="flex gap-4">
                  <span className={`px-4 py-2 rounded-lg font-semibold ${
                    selectedProduct.inStock 
                      ? 'bg-green-500/20 text-green-300' 
                      : 'bg-red-500/20 text-red-300'
                  }`}>
                    {selectedProduct.inStock ? 'In Stock' : 'Out of Stock'}
                  </span>
                  <span className="px-4 py-2 bg-purple-500/20 text-purple-300 rounded-lg">
                    {selectedProduct.category}
                  </span>
                </div>

                {/* Variants */}
                {selectedProduct.variants && selectedProduct.variants.length > 0 && (
                  <div>
                    <h3 className="text-xl font-bold mb-3 text-glow">Variants</h3>
                    <div className="space-y-2">
                      {selectedProduct.variants.map((variant) => (
                        <div key={variant.id} className="flex justify-between items-center p-3 bg-white/5 rounded-lg">
                          <div>
                            <span className="font-semibold">{variant.name}</span>
                            {variant.description && (
                              <p className="text-sm text-gray-400">{variant.description}</p>
                            )}
                          </div>
                          <span className="text-green-400 font-bold">
                            ${variant.price.toFixed(2)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Add to Cart */}
                {selectedProduct.inStock && (
                  <button
                    onClick={() => {
                      addToCart(selectedProduct.id)
                      setSelectedProduct(null)
                    }}
                    className="btn-psychedelic ripple w-full py-4 text-lg font-semibold"
                  >
                    Add to Cart - ${selectedProduct.price.toFixed(2)}
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  )
}

// Sample products for fallback when API is unavailable
const sampleProducts: Product[] = [
  {
    id: '1',
    name: 'Cosmic Gummies - Psilocybin',
    category: 'gummies',
    description: 'Premium psilocybin gummies made with organic ingredients. Each gummy contains 1g of dried psilocybin mushrooms. Perfect for microdosing or full experiences.',
    price: 45.99,
    currency: 'USD',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1587735243615-c03f25aaff15?w=400'
  },
  {
    id: '2',
    name: 'Mind Expansion Tincture',
    category: 'tinctures',
    description: 'Fast-acting liquid psilocybin tincture for precise dosing. Comes with measured dropper for accurate microdosing protocols.',
    price: 89.99,
    currency: 'USD',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1559181567-c3190ca9959b?w=400'
  },
  {
    id: '3',
    name: 'Consciousness Tea Blend',
    category: 'teas',
    description: 'Herbal tea blend with mild psychoactive herbs including blue lotus, damiana, and passion flower. Perfect for meditation.',
    price: 24.99,
    currency: 'USD',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1564890225370-1c3c2b43d315?w=400'
  },
  {
    id: '4',
    name: 'Vision Quest Chocolates',
    category: 'edibles',
    description: 'Artisan dark chocolate infused with psilocybin. Each piece contains 0.5g for easy dosing control.',
    price: 65.99,
    currency: 'USD',
    inStock: false,
    imageUrl: 'https://images.unsplash.com/photo-1549285667-c5bc96eb4592?w=400'
  },
  {
    id: '5',
    name: 'Lucid Dream Gummies',
    category: 'gummies',
    description: 'Special blend gummies designed for dream enhancement and lucid dreaming practices.',
    price: 39.99,
    currency: 'USD',
    inStock: true,
    variants: [
      { id: 'v1', name: 'Mild (0.5g)', price: 39.99 },
      { id: 'v2', name: 'Strong (1g)', price: 49.99 }
    ]
  },
  {
    id: '6',
    name: 'Sacred Ceremony Kit',
    category: 'kits',
    description: 'Complete ceremonial kit including sage, palo santo, crystals, and guided meditation tracks.',
    price: 129.99,
    currency: 'USD',
    inStock: true,
    imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400'
  }
]

export default Store