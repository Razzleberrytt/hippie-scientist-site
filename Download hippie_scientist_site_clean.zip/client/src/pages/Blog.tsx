import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { blogAPI, handleApiError, type BlogPost } from '../utils/api'

/**
 * Blog page component displaying educational articles
 * Features API integration and responsive card layout
 */
const Blog: React.FC = () => {
  const [posts, setPosts] = useState<BlogPost[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedCategory, setSelectedCategory] = useState<string>('all')

  // Load blog posts from API
  useEffect(() => {
    const loadPosts = async () => {
      try {
        setLoading(true)
        setError(null)
        const data = await blogAPI.getPosts()
        setPosts(data)
      } catch (err) {
        const apiError = handleApiError(err)
        setError(apiError.message)
        
        // Fallback to sample data when API is unavailable
        console.warn('Using fallback blog data due to API error:', apiError.message)
        setPosts(sampleBlogPosts)
      } finally {
        setLoading(false)
      }
    }

    loadPosts()
  }, [])

  // Filter posts by category
  const filteredPosts = selectedCategory === 'all' 
    ? posts 
    : posts.filter(post => post.category === selectedCategory)

  // Get unique categories
  const categories = ['all', ...Array.from(new Set(posts.map(post => post.category)))]

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="loading-spinner"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen py-20 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl font-bold mb-6 text-glow-purple">
            Educational Blog
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explore the science, history, and culture of consciousness-expanding substances
            through research-based articles and expert insights.
          </p>
        </motion.div>

        {/* Error Message */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="glass-card mb-8 bg-red-500/20 border-red-500/30"
          >
            <p className="text-red-300">
              ⚠️ Unable to connect to server: {error}. Showing sample content.
            </p>
          </motion.div>
        )}

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-wrap gap-3 mb-12 justify-center"
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-full transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                  : 'glass hover:bg-glass border border-white/20'
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </motion.div>

        {/* Blog Posts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post, index) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className="glass-card hover:scale-105 transition-transform group cursor-pointer"
            >
              {/* Post Image */}
              <div className="h-48 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg mb-6 flex items-center justify-center overflow-hidden">
                {post.imageUrl ? (
                  <img 
                    src={post.imageUrl} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                ) : (
                  <span className="text-6xl opacity-80">📚</span>
                )}
              </div>

              {/* Post Content */}
              <div className="space-y-4">
                {/* Category Badge */}
                <span className="inline-block px-3 py-1 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full text-sm font-semibold">
                  {post.category}
                </span>

                {/* Title */}
                <h2 className="text-xl font-bold text-glow group-hover:text-glow-pink transition-colors">
                  {post.title}
                </h2>

                {/* Excerpt */}
                <p className="text-gray-300 text-sm line-clamp-3">
                  {post.excerpt}
                </p>

                {/* Meta Information */}
                <div className="flex items-center justify-between text-sm text-gray-400">
                  <span>By {post.author}</span>
                  <span>{new Date(post.publishDate).toLocaleDateString()}</span>
                </div>

                {/* Tags */}
                {post.tags && post.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {post.tags.slice(0, 3).map((tag) => (
                      <span 
                        key={tag}
                        className="px-2 py-1 bg-white/10 rounded text-xs"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Read More Button */}
                <button className="btn-psychedelic ripple w-full mt-4">
                  Read Article
                </button>
              </div>
            </motion.article>
          ))}
        </div>

        {/* No Posts Message */}
        {filteredPosts.length === 0 && !loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-16"
          >
            <p className="text-xl text-gray-400">
              No articles found in this category.
            </p>
          </motion.div>
        )}
      </div>
    </div>
  )
}

// Sample blog posts for fallback when API is unavailable
const sampleBlogPosts: BlogPost[] = [
  {
    id: '1',
    title: 'The Science of Psilocybin: Understanding Neural Pathways',
    content: 'Full article content here...',
    excerpt: 'Explore how psilocybin interacts with serotonin receptors and creates profound changes in consciousness and perception.',
    author: 'Dr. Sarah Chen',
    publishDate: '2024-01-15',
    category: 'science',
    tags: ['psilocybin', 'neuroscience', 'research'],
    featured: true,
    imageUrl: 'https://images.unsplash.com/photo-1586375300773-8384e3e4916f?w=400'
  },
  {
    id: '2',
    title: 'Traditional Use of Ayahuasca in Amazonian Cultures',
    content: 'Full article content here...',
    excerpt: 'Learn about the centuries-old traditions and ceremonial practices surrounding this powerful plant medicine.',
    author: 'Carlos Mendoza',
    publishDate: '2024-01-10',
    category: 'culture',
    tags: ['ayahuasca', 'tradition', 'amazon'],
    featured: false
  },
  {
    id: '3',
    title: 'Harm Reduction: Essential Safety Guidelines',
    content: 'Full article content here...',
    excerpt: 'Comprehensive safety protocols and harm reduction strategies for responsible psychedelic use.',
    author: 'Dr. Michael Thompson',
    publishDate: '2024-01-05',
    category: 'safety',
    tags: ['safety', 'harm-reduction', 'guidelines'],
    featured: true
  },
  {
    id: '4',
    title: 'Microdosing: Benefits and Best Practices',
    content: 'Full article content here...',
    excerpt: 'Understanding the practice of taking sub-perceptual doses for enhanced creativity and well-being.',
    author: 'Dr. Emma Wilson',
    publishDate: '2024-01-01',
    category: 'research',
    tags: ['microdosing', 'benefits', 'practice'],
    featured: false
  },
  {
    id: '5',
    title: 'Legal Landscape: Psychedelic Policy Changes',
    content: 'Full article content here...',
    excerpt: 'Stay updated on the evolving legal status of psychedelics across different jurisdictions.',
    author: 'Legal Team',
    publishDate: '2023-12-28',
    category: 'legal',
    tags: ['legal', 'policy', 'regulations'],
    featured: false
  }
]

export default Blog