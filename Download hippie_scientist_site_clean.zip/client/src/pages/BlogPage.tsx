import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiCalendar, FiUser, FiClock, FiArrowRight, FiTag } from 'react-icons/fi';
import { ParticleSystem } from '../components/effects/ParticleSystem';
import { useRippleEffect } from '../hooks/useRippleEffect';

// Blog post interface
interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  publishDate: string;
  readTime: number;
  tags: string[];
  image: string;
  featured?: boolean;
}

// Mock blog data - replace with API call
const MOCK_BLOG_POSTS: BlogPost[] = [
  {
    id: '1',
    title: 'The Science Behind Psilocybin: Understanding Neuroplasticity',
    excerpt: 'Recent research reveals how psilocybin promotes neural growth and enhances brain connectivity, offering new insights into treating depression and PTSD.',
    content: 'Full article content would go here...',
    author: 'Dr. Sarah Chen',
    publishDate: '2025-01-02',
    readTime: 8,
    tags: ['Science', 'Psilocybin', 'Research'],
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=600&fit=crop',
    featured: true
  },
  {
    id: '2',
    title: 'Microdosing Protocols: A Comprehensive Guide',
    excerpt: 'Everything you need to know about microdosing schedules, dosages, and tracking your experiences for optimal results.',
    content: 'Full article content would go here...',
    author: 'James Fadiman',
    publishDate: '2024-12-28',
    readTime: 12,
    tags: ['Microdosing', 'Guide', 'Protocols'],
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=800&h=600&fit=crop'
  },
  {
    id: '3',
    title: 'Set and Setting: Creating Safe Psychedelic Experiences',
    excerpt: 'The importance of mindset and environment in psychedelic experiences, with practical tips for preparation and integration.',
    content: 'Full article content would go here...',
    author: 'Timothy Leary Institute',
    publishDate: '2024-12-25',
    readTime: 10,
    tags: ['Safety', 'Preparation', 'Integration'],
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop'
  },
  {
    id: '4',
    title: 'Legal Landscape: Psychedelic Laws Around the World',
    excerpt: 'A comprehensive overview of current psychedelic legislation, decriminalization efforts, and therapeutic access programs globally.',
    content: 'Full article content would go here...',
    author: 'Legal Reform Team',
    publishDate: '2024-12-20',
    readTime: 15,
    tags: ['Legal', 'Policy', 'Reform'],
    image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=800&h=600&fit=crop'
  },
  {
    id: '5',
    title: 'Integration Practices: Making Sense of Psychedelic Insights',
    excerpt: 'How to process and integrate psychedelic experiences into daily life through journaling, therapy, and community support.',
    content: 'Full article content would go here...',
    author: 'Dr. Robin Carhart-Harris',
    publishDate: '2024-12-15',
    readTime: 9,
    tags: ['Integration', 'Therapy', 'Community'],
    image: 'https://images.unsplash.com/photo-1544027993-37dbfe43562a?w=800&h=600&fit=crop',
    featured: true
  }
];

// Blog post card component
const BlogPostCard: React.FC<{
  post: BlogPost;
  onReadMore: (post: BlogPost) => void;
  featured?: boolean;
}> = ({ post, onReadMore, featured = false }) => {
  const { createRipple } = useRippleEffect();

  const handleReadMore = (event: React.MouseEvent<HTMLButtonElement>): void => {
    createRipple(event, { color: 'var(--neon-cyan)' });
    onReadMore(post);
  };

  return (
    <motion.article
      className={`glass rounded-2xl overflow-hidden border border-purple-500/20 hover:border-purple-400/50 transition-all duration-500 group ${
        featured ? 'lg:col-span-2' : ''
      }`}
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -8, scale: 1.02 }}
      transition={{ type: "spring", stiffness: 300, damping: 25 }}
    >
      {/* Featured badge */}
      {post.featured && (
        <motion.div
          className="absolute top-4 left-4 z-20 px-3 py-1 rounded-full text-sm font-semibold"
          style={{ 
            background: 'var(--gradient-aurora)',
            color: 'white'
          }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring" }}
        >
          Featured
        </motion.div>
      )}

      {/* Image */}
      <div className={`relative overflow-hidden ${featured ? 'h-64' : 'h-48'}`}>
        <motion.img
          src={post.image}
          alt={post.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
      </div>

      {/* Content */}
      <div className="p-6 space-y-4">
        {/* Meta information */}
        <div className="flex flex-wrap items-center gap-4 text-sm opacity-70">
          <div className="flex items-center space-x-2">
            <FiCalendar size={14} className="text-purple-400" />
            <span>{new Date(post.publishDate).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center space-x-2">
            <FiUser size={14} className="text-cyan-400" />
            <span>{post.author}</span>
          </div>
          <div className="flex items-center space-x-2">
            <FiClock size={14} className="text-green-400" />
            <span>{post.readTime} min read</span>
          </div>
        </div>

        {/* Title */}
        <h2 className={`font-bold gradient-text group-hover:filter group-hover:brightness-110 transition-all ${
          featured ? 'text-2xl' : 'text-xl'
        }`}>
          {post.title}
        </h2>

        {/* Excerpt */}
        <p className="opacity-80 leading-relaxed">
          {post.excerpt}
        </p>

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {post.tags.map((tag, index) => (
            <motion.span
              key={tag}
              className="px-2 py-1 text-xs rounded-full glass border border-opacity-30"
              style={{ borderColor: 'var(--neon-purple)' }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <FiTag size={10} className="inline mr-1" />
              {tag}
            </motion.span>
          ))}
        </div>

        {/* Read more button */}
        <motion.button
          onClick={handleReadMore}
          className="flex items-center space-x-2 text-purple-400 hover:text-purple-300 transition-colors group/btn"
          whileHover={{ x: 5 }}
        >
          <span>Read More</span>
          <motion.div
            animate={{ x: [0, 5, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <FiArrowRight size={16} />
          </motion.div>
        </motion.button>
      </div>
    </motion.article>
  );
};

// Blog page component
export const BlogPage: React.FC = () => {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTag, setSelectedTag] = useState<string | null>(null);

  // Get all unique tags
  const allTags = Array.from(new Set(MOCK_BLOG_POSTS.flatMap(post => post.tags)));

  // Filter posts based on search and tag
  const filteredPosts = MOCK_BLOG_POSTS.filter(post => {
    const matchesSearch = !searchQuery || 
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.author.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesTag = !selectedTag || post.tags.includes(selectedTag);
    
    return matchesSearch && matchesTag;
  });

  const featuredPosts = filteredPosts.filter(post => post.featured);
  const regularPosts = filteredPosts.filter(post => !post.featured);

  const handleReadMore = (post: BlogPost): void => {
    setSelectedPost(post);
    // In a real app, this would navigate to a detailed blog post page
    console.log('Reading post:', post.title);
  };

  return (
    <div className="relative min-h-screen pt-20">
      {/* Particle background */}
      <ParticleSystem particleCount={15} followMouse={false} />

      {/* Header */}
      <motion.div
        className="relative z-10 bg-gradient-to-r from-purple-900/50 to-cyan-900/50 backdrop-blur-sm border-b border-purple-500/20"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
      >
        <div className="max-w-7xl mx-auto px-4 py-12">
          <h1 className="text-5xl md:text-6xl font-bold gradient-text text-center mb-4">
            Psychedelic Research & Insights
          </h1>
          <p className="text-xl opacity-80 text-center max-w-3xl mx-auto">
            Stay informed with the latest research, guides, and perspectives 
            on consciousness exploration and psychedelic science.
          </p>
        </div>
      </motion.div>

      {/* Search and filters */}
      <motion.div
        className="relative z-10 max-w-7xl mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3, duration: 0.6 }}
      >
        <div className="glass rounded-2xl p-6 border border-purple-500/20">
          <div className="flex flex-col lg:flex-row gap-6 items-center">
            
            {/* Search bar */}
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-3 bg-white/10 border border-purple-500/30 rounded-xl focus:outline-none focus:border-purple-400 transition-colors"
              />
            </div>

            {/* Tag filters */}
            <div className="flex flex-wrap gap-2">
              <motion.button
                onClick={() => setSelectedTag(null)}
                className={`px-4 py-2 rounded-xl transition-all duration-300 ${
                  !selectedTag
                    ? 'bg-purple-500 text-white'
                    : 'bg-white/10 text-purple-300 hover:bg-white/20'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                All Topics
              </motion.button>
              
              {allTags.map((tag) => (
                <motion.button
                  key={tag}
                  onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                  className={`px-4 py-2 rounded-xl transition-all duration-300 ${
                    selectedTag === tag
                      ? 'bg-cyan-500 text-white'
                      : 'bg-white/10 text-cyan-300 hover:bg-white/20'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {tag}
                </motion.button>
              ))}
            </div>
          </div>
        </div>
      </motion.div>

      {/* Blog content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 pb-20">
        
        {/* Featured posts */}
        {featuredPosts.length > 0 && (
          <motion.section
            className="mb-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold gradient-text mb-8">Featured Articles</h2>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredPosts.map((post) => (
                <BlogPostCard
                  key={post.id}
                  post={post}
                  onReadMore={handleReadMore}
                  featured={true}
                />
              ))}
            </div>
          </motion.section>
        )}

        {/* Regular posts */}
        {regularPosts.length > 0 && (
          <motion.section
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7, duration: 0.8 }}
          >
            <h2 className="text-3xl font-bold gradient-text mb-8">Latest Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <AnimatePresence>
                {regularPosts.map((post, index) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                  >
                    <BlogPostCard
                      post={post}
                      onReadMore={handleReadMore}
                    />
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </motion.section>
        )}

        {/* No results */}
        {filteredPosts.length === 0 && (
          <motion.div
            className="text-center py-20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <h3 className="text-2xl font-semibold mb-4">No articles found</h3>
            <p className="text-lg opacity-70 mb-8">
              Try adjusting your search terms or selecting a different topic
            </p>
            <motion.button
              onClick={() => {
                setSearchQuery('');
                setSelectedTag(null);
              }}
              className="px-6 py-3 bg-purple-500 hover:bg-purple-600 rounded-xl transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Clear Filters
            </motion.button>
          </motion.div>
        )}
      </div>
    </div>
  );
};