import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { motion } from 'framer-motion'
import Header from './components/Header'
import ParticleBackground from './components/ParticleBackground'
import Home from './pages/Home'
import Blog from './pages/Blog'
import HerbIndex from './pages/HerbIndex'
import Store from './pages/Store'
import './App.css'

/**
 * Main App component - Contains routing and global layout
 * Features psychedelic theme with particle background and smooth transitions
 */
const App: React.FC = () => {
  return (
    <div className="App">
      {/* Global particle background for psychedelic ambiance */}
      <ParticleBackground />
      
      {/* Navigation header with responsive design */}
      <Header />
      
      {/* Main content area with smooth page transitions */}
      <motion.main
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="main-content"
      >
        <Routes>
          {/* Homepage with animated visuals */}
          <Route path="/" element={<Home />} />
          
          {/* Blog posts section */}
          <Route path="/blog" element={<Blog />} />
          
          {/* Psychoactive herb index */}
          <Route path="/herbs" element={<HerbIndex />} />
          
          {/* Product storefront */}
          <Route path="/store" element={<Store />} />
        </Routes>
      </motion.main>
      
      {/* Floating psychedelic elements */}
      <div className="floating-elements">
        <div className="float-element float-1"></div>
        <div className="float-element float-2"></div>
        <div className="float-element float-3"></div>
      </div>
    </div>
  )
}

export default App