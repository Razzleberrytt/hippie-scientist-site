import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

// Individual particle interface
interface Particle {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
}

// Particle system configuration
interface ParticleSystemProps {
  particleCount?: number;
  colors?: string[];
  isActive?: boolean;
  followMouse?: boolean;
}

// Interactive particle system component for psychedelic background effects
export const ParticleSystem: React.FC<ParticleSystemProps> = ({
  particleCount = 50,
  colors = ['#ff00ff', '#00ffff', '#8b5cf6', '#00ff88'],
  isActive = true,
  followMouse = true
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: 0, y: 0 });
  const animationRef = useRef<number>();

  // Initialize particles with random properties
  const initializeParticles = (): void => {
    const particles: Particle[] = [];
    
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        id: `particle_${i}`,
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        color: colors[Math.floor(Math.random() * colors.length)],
        life: Math.random() * 100,
        maxLife: 100
      });
    }
    
    particlesRef.current = particles;
  };

  // Update particle positions and properties
  const updateParticles = (ctx: CanvasRenderingContext2D): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Clear canvas with fade effect for trails
    ctx.fillStyle = 'rgba(10, 10, 15, 0.1)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    particlesRef.current.forEach(particle => {
      // Update position
      particle.x += particle.vx;
      particle.y += particle.vy;

      // Mouse interaction - particles are attracted to mouse
      if (followMouse) {
        const dx = mouseRef.current.x - particle.x;
        const dy = mouseRef.current.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 150) {
          const force = (150 - distance) / 150;
          particle.vx += (dx / distance) * force * 0.01;
          particle.vy += (dy / distance) * force * 0.01;
        }
      }

      // Boundary wrapping
      if (particle.x < 0) particle.x = canvas.width;
      if (particle.x > canvas.width) particle.x = 0;
      if (particle.y < 0) particle.y = canvas.height;
      if (particle.y > canvas.height) particle.y = 0;

      // Apply friction
      particle.vx *= 0.99;
      particle.vy *= 0.99;

      // Update life cycle
      particle.life += 1;
      if (particle.life > particle.maxLife) {
        particle.life = 0;
        particle.x = Math.random() * canvas.width;
        particle.y = Math.random() * canvas.height;
      }

      // Calculate opacity based on life cycle
      const alpha = 1 - (particle.life / particle.maxLife);
      
      // Draw particle with glow effect
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.shadowColor = particle.color;
      ctx.shadowBlur = 20;
      ctx.fillStyle = particle.color;
      
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  };

  // Animation loop
  const animate = (): void => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    
    if (!canvas || !ctx || !isActive) return;
    
    updateParticles(ctx);
    animationRef.current = requestAnimationFrame(animate);
  };

  // Handle mouse movement
  const handleMouseMove = (event: MouseEvent): void => {
    mouseRef.current = {
      x: event.clientX,
      y: event.clientY
    };
  };

  // Handle canvas resize
  const handleResize = (): void => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  };

  // Setup and cleanup effects
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Initialize canvas
    handleResize();
    initializeParticles();
    
    // Start animation
    if (isActive) {
      animate();
    }

    // Event listeners
    if (followMouse) {
      window.addEventListener('mousemove', handleMouseMove);
    }
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
    };
  }, [isActive, followMouse, particleCount]);

  if (!isActive) return null;

  return (
    <motion.div
      className="particles-container"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1 }}
    >
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ 
          background: 'transparent',
          mixBlendMode: 'screen' // Creates additive blending for psychedelic effect
        }}
      />
    </motion.div>
  );
};