import React from 'react';
import { motion } from 'framer-motion';
import { FiSun, FiMoon } from 'react-icons/fi';
import { useTheme } from '../../context/ThemeContext';
import { useRippleEffect } from '../../hooks/useRippleEffect';

// Theme toggle button component with psychedelic animations
export const ThemeToggle: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { createPsychedelicRipple } = useRippleEffect();

  // Handle theme toggle with ripple effect
  const handleToggle = (event: React.MouseEvent<HTMLButtonElement>): void => {
    createPsychedelicRipple(event);
    toggleTheme();
  };

  return (
    <motion.button
      onClick={handleToggle}
      className="relative p-3 rounded-full glass border-2 border-transparent hover:border-opacity-50 transition-all duration-300 overflow-hidden"
      style={{
        borderColor: theme === 'dark' ? 'var(--neon-cyan)' : 'var(--neon-purple)'
      }}
      whileHover={{ 
        scale: 1.1,
        boxShadow: theme === 'dark' 
          ? '0 0 20px var(--neon-cyan)' 
          : '0 0 20px var(--neon-purple)'
      }}
      whileTap={{ scale: 0.95 }}
      aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
    >
      {/* Background gradient animation */}
      <motion.div
        className="absolute inset-0 opacity-20"
        style={{
          background: theme === 'dark' 
            ? 'var(--gradient-aurora)' 
            : 'var(--gradient-cosmic)'
        }}
        animate={{
          rotate: [0, 360],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "linear"
        }}
      />

      {/* Icon container */}
      <div className="relative z-10 flex items-center justify-center">
        <motion.div
          key={theme}
          initial={{ rotate: -180, opacity: 0 }}
          animate={{ rotate: 0, opacity: 1 }}
          exit={{ rotate: 180, opacity: 0 }}
          transition={{ 
            type: "spring", 
            stiffness: 200, 
            damping: 15 
          }}
        >
          {theme === 'dark' ? (
            <FiSun 
              size={20} 
              className="text-yellow-400 pulse-glow"
            />
          ) : (
            <FiMoon 
              size={20} 
              className="text-purple-400 pulse-glow"
            />
          )}
        </motion.div>
      </div>

      {/* Glow effect overlay */}
      <motion.div
        className="absolute inset-0 rounded-full opacity-0 hover:opacity-30 transition-opacity duration-300"
        style={{
          background: `radial-gradient(circle, ${
            theme === 'dark' ? 'var(--neon-cyan)' : 'var(--neon-purple)'
          } 0%, transparent 70%)`
        }}
        animate={{
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
    </motion.button>
  );
};