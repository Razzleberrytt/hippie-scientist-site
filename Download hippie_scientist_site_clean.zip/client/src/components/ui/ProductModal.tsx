import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiX, FiShoppingCart, FiInfo, FiStar } from 'react-icons/fi';
import { Product } from './ProductCard';
import { useRippleEffect } from '../../hooks/useRippleEffect';

// Product modal props
interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (productId: string) => void;
}

// Detailed product modal with enhanced psychedelic styling
export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart
}) => {
  const { createPsychedelicRipple, createRipple } = useRippleEffect();

  if (!product) return null;

  // Handle add to cart
  const handleAddToCart = (event: React.MouseEvent<HTMLButtonElement>): void => {
    createPsychedelicRipple(event);
    onAddToCart(product.id);
  };

  // Handle close modal
  const handleClose = (event: React.MouseEvent): void => {
    if (event.target === event.currentTarget) {
      onClose();
    }
  };

  // Modal backdrop variants
  const backdropVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 }
  };

  // Modal content variants
  const modalVariants = {
    hidden: { 
      opacity: 0, 
      scale: 0.8, 
      y: 50,
      rotateX: -15
    },
    visible: { 
      opacity: 1, 
      scale: 1, 
      y: 0,
      rotateX: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 25
      }
    },
    exit: {
      opacity: 0,
      scale: 0.8,
      y: 50,
      rotateX: 15,
      transition: {
        duration: 0.3
      }
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          variants={backdropVariants}
          initial="hidden"
          animate="visible"
          exit="hidden"
          onClick={handleClose}
          style={{
            backgroundColor: 'rgba(10, 10, 15, 0.8)',
            backdropFilter: 'blur(10px)'
          }}
        >
          <motion.div
            className="relative max-w-4xl w-full max-h-[90vh] overflow-hidden rounded-3xl glass border-2 border-opacity-30"
            style={{ borderColor: 'var(--neon-purple)' }}
            variants={modalVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Animated background gradient */}
            <motion.div
              className="absolute inset-0 opacity-10"
              style={{ background: 'var(--gradient-psychedelic)' }}
              animate={{
                backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
              }}
              transition={{ duration: 8, repeat: Infinity }}
            />

            {/* Close button */}
            <motion.button
              className="absolute top-4 right-4 z-10 p-2 rounded-full glass hover:scale-110 transition-transform"
              onClick={onClose}
              whileHover={{ rotate: 90 }}
              whileTap={{ scale: 0.95 }}
            >
              <FiX size={24} className="text-red-400" />
            </motion.button>

            {/* Modal content */}
            <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 h-full">
              
              {/* Product image section */}
              <div className="relative p-8 flex items-center justify-center">
                <motion.div
                  className="relative w-full max-w-md aspect-square rounded-2xl overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                  transition={{ type: "spring", stiffness: 300 }}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Holographic overlay */}
                  <motion.div
                    className="absolute inset-0 holographic opacity-30"
                    animate={{
                      backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
                    }}
                    transition={{ duration: 3, repeat: Infinity }}
                  />
                </motion.div>
              </div>

              {/* Product details section */}
              <div className="p-8 space-y-6 overflow-y-auto">
                
                {/* Category badge */}
                <motion.span
                  className="inline-block px-3 py-1 rounded-full text-sm font-semibold uppercase tracking-wider"
                  style={{ 
                    background: 'var(--gradient-aurora)',
                    color: 'white'
                  }}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  {product.category}
                </motion.span>

                {/* Product name */}
                <motion.h2
                  className="text-3xl lg:text-4xl font-bold gradient-text"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  {product.name}
                </motion.h2>

                {/* Rating stars (placeholder) */}
                <motion.div
                  className="flex items-center space-x-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <FiStar key={i} size={20} className="fill-current" />
                    ))}
                  </div>
                  <span className="text-sm opacity-70">(4.8/5 - 127 reviews)</span>
                </motion.div>

                {/* Price */}
                <motion.div
                  className="text-4xl font-bold gradient-text"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5, type: "spring" }}
                >
                  ${product.price.toFixed(2)}
                </motion.div>

                {/* Description */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                >
                  <h3 className="text-lg font-semibold mb-3 flex items-center space-x-2">
                    <FiInfo className="text-blue-400" />
                    <span>Description</span>
                  </h3>
                  <p className="text-base opacity-80 leading-relaxed">
                    {product.description}
                  </p>
                </motion.div>

                {/* Potency info */}
                {product.potency && (
                  <motion.div
                    className="p-4 rounded-2xl glass border border-opacity-30"
                    style={{ borderColor: 'var(--neon-cyan)' }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.7 }}
                  >
                    <h4 className="font-semibold text-cyan-400 mb-2">Potency</h4>
                    <p className="opacity-80">{product.potency}</p>
                  </motion.div>
                )}

                {/* Effects */}
                {product.effects && product.effects.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 }}
                  >
                    <h4 className="font-semibold mb-3">Effects</h4>
                    <div className="flex flex-wrap gap-2">
                      {product.effects.map((effect, index) => (
                        <motion.span
                          key={effect}
                          className="px-3 py-1 rounded-full glass border border-opacity-30 text-sm"
                          style={{ borderColor: 'var(--neon-green)' }}
                          initial={{ opacity: 0, scale: 0 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.8 + index * 0.1 }}
                          whileHover={{ scale: 1.05 }}
                        >
                          {effect}
                        </motion.span>
                      ))}
                    </div>
                  </motion.div>
                )}

                {/* Action buttons */}
                <motion.div
                  className="flex space-x-4 pt-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 }}
                >
                  <motion.button
                    className={`flex-1 py-4 px-6 rounded-2xl font-semibold text-lg transition-all duration-300 ${
                      product.inStock
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white'
                        : 'bg-gray-500 text-gray-300 cursor-not-allowed'
                    }`}
                    onClick={handleAddToCart}
                    disabled={!product.inStock}
                    whileHover={product.inStock ? { scale: 1.02 } : {}}
                    whileTap={product.inStock ? { scale: 0.98 } : {}}
                  >
                    <div className="flex items-center justify-center space-x-2">
                      <FiShoppingCart size={20} />
                      <span>{product.inStock ? 'Add to Cart' : 'Out of Stock'}</span>
                    </div>
                  </motion.button>
                </motion.div>

                {/* Stock status */}
                <motion.div
                  className="text-center"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1 }}
                >
                  <span className={`text-sm ${product.inStock ? 'text-green-400' : 'text-red-400'}`}>
                    {product.inStock ? '✓ In Stock' : '✗ Out of Stock'}
                  </span>
                </motion.div>
              </div>
            </div>

            {/* Animated border effect */}
            <motion.div
              className="absolute inset-0 rounded-3xl pointer-events-none"
              style={{
                background: 'linear-gradient(45deg, transparent 30%, var(--neon-cyan) 50%, transparent 70%)',
                opacity: 0,
              }}
              animate={{
                opacity: [0, 0.2, 0],
                rotate: [0, 360],
              }}
              transition={{ duration: 4, repeat: Infinity }}
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};