import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';
import { FiMenu, FiX, FiShoppingCart } from 'react-icons/fi';
import { ThemeToggle } from './ThemeToggle';
import { useRippleEffect } from '../../hooks/useRippleEffect';

// Navigation item interface
interface NavItem {
  label: string;
  path: string;
  isExternal?: boolean;
}

// Main navigation component with responsive design and psychedelic animations
export const Navigation: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { createRipple } = useRippleEffect();

  // Navigation items configuration
  const navItems: NavItem[] = [
    { label: 'Home', path: '/' },
    { label: 'Store', path: '/store' },
    { label: 'Blog', path: '/blog' },
    { label: 'Psychoactive Index', path: '/psychoactive-index' },
  ];

  // Toggle mobile menu
  const toggleMobileMenu = (): void => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Handle navigation item click with ripple effect
  const handleNavClick = (event: React.MouseEvent<HTMLAnchorElement>): void => {
    createRipple(event, { color: 'var(--neon-purple)' });
    setIsMobileMenuOpen(false);
  };

  // Check if current path is active
  const isActivePath = (path: string): boolean => {
    return location.pathname === path;
  };

  return (
    <motion.nav
      className="fixed top-0 left-0 right-0 z-50 glass border-b border-opacity-20"
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 100, damping: 20 }}
      style={{
        borderBottomColor: 'var(--neon-purple)',
        backdropFilter: 'blur(20px)',
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo/Brand */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link 
              to="/" 
              className="text-2xl font-bold gradient-text hover:filter hover:brightness-110 transition-all duration-300"
              onClick={handleNavClick}
            >
              PsycheCo
            </Link>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <motion.div
                key={item.path}
                whileHover={{ y: -2 }}
                whileTap={{ y: 0 }}
              >
                <Link
                  to={item.path}
                  onClick={handleNavClick}
                  className={`relative px-3 py-2 text-sm font-medium transition-all duration-300 overflow-hidden ${
                    isActivePath(item.path)
                      ? 'text-white'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {/* Active indicator */}
                  {isActivePath(item.path) && (
                    <motion.div
                      className="absolute inset-0 rounded-lg opacity-20"
                      style={{ background: 'var(--gradient-psychedelic)' }}
                      layoutId="activeTab"
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    />
                  )}
                  
                  {/* Hover effect */}
                  <motion.div
                    className="absolute inset-0 rounded-lg opacity-0 hover:opacity-10 transition-opacity duration-300"
                    style={{ background: 'var(--gradient-aurora)' }}
                  />
                  
                  <span className="relative z-10">{item.label}</span>
                </Link>
              </motion.div>
            ))}
          </div>

          {/* Right side controls */}
          <div className="flex items-center space-x-4">
            
            {/* Shopping cart (placeholder for store functionality) */}
            <motion.button
              className="relative p-2 rounded-full glass hover:scale-110 transition-transform duration-300"
              whileHover={{ 
                boxShadow: '0 0 15px var(--neon-pink)' 
              }}
              whileTap={{ scale: 0.95 }}
              onClick={(e) => createRipple(e, { color: 'var(--neon-pink)' })}
            >
              <FiShoppingCart size={20} className="text-pink-400" />
              {/* Cart item count badge */}
              <motion.span
                className="absolute -top-1 -right-1 bg-pink-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 500 }}
              >
                0
              </motion.span>
            </motion.button>

            {/* Theme toggle */}
            <ThemeToggle />

            {/* Mobile menu toggle */}
            <motion.button
              className="md:hidden p-2 rounded-full glass"
              onClick={toggleMobileMenu}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
            >
              <AnimatePresence mode="wait">
                {isMobileMenuOpen ? (
                  <motion.div
                    key="close"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <FiX size={20} className="text-cyan-400" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="menu"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <FiMenu size={20} className="text-cyan-400" />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              className="md:hidden"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
            >
              <div className="px-2 pt-2 pb-6 space-y-2">
                {navItems.map((item, index) => (
                  <motion.div
                    key={item.path}
                    initial={{ x: -50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link
                      to={item.path}
                      onClick={handleNavClick}
                      className={`block px-4 py-3 rounded-lg text-base font-medium transition-all duration-300 ${
                        isActivePath(item.path)
                          ? 'text-white bg-opacity-20'
                          : 'text-gray-300 hover:text-white hover:bg-opacity-10'
                      }`}
                      style={{
                        backgroundColor: isActivePath(item.path) 
                          ? 'var(--neon-purple)' 
                          : 'transparent'
                      }}
                    >
                      {item.label}
                    </Link>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  );
};