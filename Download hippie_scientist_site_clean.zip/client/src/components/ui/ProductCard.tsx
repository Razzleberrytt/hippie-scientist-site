import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiShoppingCart, FiEye, FiHeart, FiInfo } from 'react-icons/fi';
import { useRippleEffect } from '../../hooks/useRippleEffect';

// Product interface
export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  potency?: string;
  effects?: string[];
  inStock: boolean;
  featured?: boolean;
}

// Product card component props
interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  onAddToCart: (productId: string) => void;
  className?: string;
}

// Enhanced product card with psychedelic animations and hover effects
export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onViewDetails,
  onAddToCart,
  className = ''
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const { createRipple, createPsychedelicRipple } = useRippleEffect();

  // Handle add to cart with feedback
  const handleAddToCart = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.stopPropagation();
    createPsychedelicRipple(event);
    onAddToCart(product.id);
  };

  // Handle view details
  const handleViewDetails = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.stopPropagation();
    createRipple(event, { color: 'var(--neon-cyan)' });
    onViewDetails(product);
  };

  // Toggle like status
  const handleToggleLike = (event: React.MouseEvent<HTMLButtonElement>): void => {
    event.stopPropagation();
    createRipple(event, { color: 'var(--neon-pink)' });
    setIsLiked(!isLiked);
  };

  return (
    <motion.div
      className={`relative group cursor-pointer ${className}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ 
        y: -8,
        transition: { type: "spring", stiffness: 300, damping: 25 }
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() => onViewDetails(product)}
    >
      {/* Card container with glass effect */}
      <div className="relative overflow-hidden rounded-2xl glass border-2 border-transparent hover:border-opacity-50 transition-all duration-500 h-full">
        
        {/* Animated background gradient */}
        <motion.div
          className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity duration-500"
          style={{ background: 'var(--gradient-psychedelic)' }}
          animate={isHovered ? {
            backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
          } : {}}
          transition={{ duration: 3, repeat: Infinity }}
        />

        {/* Featured badge */}
        {product.featured && (
          <motion.div
            className="absolute top-3 left-3 z-20 px-2 py-1 rounded-full text-xs font-semibold"
            style={{ 
              background: 'var(--gradient-aurora)',
              color: 'white'
            }}
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
          >
            Featured
          </motion.div>
        )}

        {/* Like button */}
        <motion.button
          className="absolute top-3 right-3 z-20 p-2 rounded-full glass hover:scale-110 transition-transform"
          onClick={handleToggleLike}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <FiHeart 
            size={16} 
            className={`transition-colors duration-300 ${
              isLiked ? 'text-pink-400 fill-current' : 'text-gray-400'
            }`}
          />
        </motion.button>

        {/* Product image */}
        <div className="relative aspect-square overflow-hidden">
          <motion.img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.5 }}
          />
          
          {/* Image overlay with quick actions */}
          <AnimatePresence>
            {isHovered && (
              <motion.div
                className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center space-x-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <motion.button
                  className="p-3 rounded-full glass hover:scale-110 transition-transform"
                  onClick={handleViewDetails}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.1 }}
                >
                  <FiEye size={20} className="text-cyan-400" />
                </motion.button>
                
                {product.inStock && (
                  <motion.button
                    className="p-3 rounded-full glass hover:scale-110 transition-transform"
                    onClick={handleAddToCart}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <FiShoppingCart size={20} className="text-green-400" />
                  </motion.button>
                )}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Out of stock overlay */}
          {!product.inStock && (
            <div className="absolute inset-0 bg-black bg-opacity-70 flex items-center justify-center">
              <span className="text-white font-semibold">Out of Stock</span>
            </div>
          )}
        </div>

        {/* Product details */}
        <div className="p-6 space-y-4">
          
          {/* Category and name */}
          <div>
            <p className="text-sm opacity-70 mb-1 uppercase tracking-wider">
              {product.category}
            </p>
            <h3 className="text-xl font-bold gradient-text group-hover:filter group-hover:brightness-110 transition-all duration-300">
              {product.name}
            </h3>
          </div>

          {/* Description */}
          <p className="text-sm opacity-80 line-clamp-2">
            {product.description}
          </p>

          {/* Effects tags */}
          {product.effects && product.effects.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {product.effects.slice(0, 3).map((effect, index) => (
                <motion.span
                  key={effect}
                  className="px-2 py-1 text-xs rounded-full glass border border-opacity-30"
                  style={{ borderColor: 'var(--neon-purple)' }}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {effect}
                </motion.span>
              ))}
            </div>
          )}

          {/* Potency info */}
          {product.potency && (
            <div className="flex items-center space-x-2 text-sm">
              <FiInfo size={14} className="text-blue-400" />
              <span className="opacity-80">{product.potency}</span>
            </div>
          )}

          {/* Price and action button */}
          <div className="flex items-center justify-between pt-2">
            <motion.div
              className="text-2xl font-bold gradient-text"
              whileHover={{ scale: 1.05 }}
            >
              ${product.price.toFixed(2)}
            </motion.div>
            
            <motion.button
              className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all duration-300 ${
                product.inStock
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white'
                  : 'bg-gray-500 text-gray-300 cursor-not-allowed'
              }`}
              onClick={handleAddToCart}
              disabled={!product.inStock}
              whileHover={product.inStock ? { scale: 1.05 } : {}}
              whileTap={product.inStock ? { scale: 0.95 } : {}}
            >
              {product.inStock ? 'Add to Cart' : 'Sold Out'}
            </motion.button>
          </div>
        </div>

        {/* Holographic border effect */}
        <motion.div
          className="absolute inset-0 rounded-2xl pointer-events-none"
          style={{
            background: 'linear-gradient(45deg, transparent 30%, var(--neon-cyan) 50%, transparent 70%)',
            opacity: 0,
          }}
          animate={isHovered ? {
            opacity: [0, 0.3, 0],
            rotate: [0, 360],
          } : {}}
          transition={{ duration: 2, repeat: Infinity }}
        />
      </div>
    </motion.div>
  );
};