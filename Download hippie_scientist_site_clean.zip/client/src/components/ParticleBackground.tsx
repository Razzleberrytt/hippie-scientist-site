import React, { useEffect, useRef } from 'react'

/**
 * ParticleBackground component creates animated floating particles
 * Features psychedelic colors and interactive mouse effects
 */
const ParticleBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()
  const mouseRef = useRef({ x: 0, y: 0 })

  // Particle class for individual particle behavior
  class Particle {
    x: number
    y: number
    vx: number
    vy: number
    size: number
    color: string
    opacity: number
    trail: { x: number; y: number }[]

    constructor(canvas: HTMLCanvasElement) {
      this.x = Math.random() * canvas.width
      this.y = Math.random() * canvas.height
      this.vx = (Math.random() - 0.5) * 0.5
      this.vy = (Math.random() - 0.5) * 0.5
      this.size = Math.random() * 3 + 1
      this.opacity = Math.random() * 0.8 + 0.2
      this.trail = []
      
      // Psychedelic colors
      const colors = [
        '#8B5CF6', '#EC4899', '#06B6D4', '#F59E0B', '#10B981',
        '#C4B5FD', '#F9A8D4', '#67E8F9', '#FCD34D', '#6EE7B7'
      ]
      this.color = colors[Math.floor(Math.random() * colors.length)]
    }

    update(canvas: HTMLCanvasElement, mouse: { x: number; y: number }) {
      // Mouse interaction - particles are attracted to mouse
      const dx = mouse.x - this.x
      const dy = mouse.y - this.y
      const distance = Math.sqrt(dx * dx + dy * dy)
      
      if (distance < 100) {
        const force = (100 - distance) / 100
        this.vx += (dx / distance) * force * 0.01
        this.vy += (dy / distance) * force * 0.01
      }

      // Update position
      this.x += this.vx
      this.y += this.vy

      // Add current position to trail
      this.trail.push({ x: this.x, y: this.y })
      if (this.trail.length > 10) {
        this.trail.shift()
      }

      // Boundary collision with gentle bounce
      if (this.x < 0 || this.x > canvas.width) {
        this.vx *= -0.8
        this.x = Math.max(0, Math.min(canvas.width, this.x))
      }
      if (this.y < 0 || this.y > canvas.height) {
        this.vy *= -0.8
        this.y = Math.max(0, Math.min(canvas.height, this.y))
      }

      // Damping to prevent infinite acceleration
      this.vx *= 0.99
      this.vy *= 0.99

      // Gentle floating motion
      this.vx += (Math.random() - 0.5) * 0.01
      this.vy += (Math.random() - 0.5) * 0.01
    }

    draw(ctx: CanvasRenderingContext2D) {
      // Draw particle trail
      ctx.beginPath()
      for (let i = 0; i < this.trail.length; i++) {
        const point = this.trail[i]
        const alpha = (i / this.trail.length) * this.opacity * 0.3
        ctx.globalAlpha = alpha
        ctx.fillStyle = this.color
        ctx.arc(point.x, point.y, this.size * 0.5, 0, Math.PI * 2)
        ctx.fill()
      }

      // Draw main particle with glow effect
      ctx.globalAlpha = this.opacity
      ctx.fillStyle = this.color
      ctx.shadowBlur = 20
      ctx.shadowColor = this.color
      ctx.beginPath()
      ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
      ctx.fill()

      // Inner glow
      ctx.globalAlpha = this.opacity * 0.8
      ctx.fillStyle = '#ffffff'
      ctx.shadowBlur = 5
      ctx.shadowColor = '#ffffff'
      ctx.beginPath()
      ctx.arc(this.x, this.y, this.size * 0.3, 0, Math.PI * 2)
      ctx.fill()

      // Reset shadow
      ctx.shadowBlur = 0
      ctx.globalAlpha = 1
    }
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext('2d')
    if (!ctx) return

    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }
    resizeCanvas()

    // Handle mouse movement
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY }
    }

    // Handle touch movement for mobile
    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        mouseRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }
      }
    }

    // Create particles
    const particles: Particle[] = []
    const particleCount = window.innerWidth < 768 ? 30 : 50
    
    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle(canvas))
    }

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update and draw particles
      particles.forEach(particle => {
        particle.update(canvas, mouseRef.current)
        particle.draw(ctx)
      })

      // Connect nearby particles with lines
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x
          const dy = particles[i].y - particles[j].y
          const distance = Math.sqrt(dx * dx + dy * dy)

          if (distance < 100) {
            ctx.globalAlpha = (100 - distance) / 100 * 0.2
            ctx.strokeStyle = particles[i].color
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(particles[i].x, particles[i].y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.stroke()
          }
        }
      }

      ctx.globalAlpha = 1
      animationRef.current = requestAnimationFrame(animate)
    }

    // Start animation
    animate()

    // Event listeners
    window.addEventListener('resize', resizeCanvas)
    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('touchmove', handleTouchMove)

    // Cleanup
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
      window.removeEventListener('resize', resizeCanvas)
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('touchmove', handleTouchMove)
    }
  }, [])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ mixBlendMode: 'screen' }}
    />
  )
}

export default ParticleBackground