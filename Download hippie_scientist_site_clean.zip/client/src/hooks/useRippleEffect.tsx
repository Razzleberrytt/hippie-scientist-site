import { useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';

// Interface for ripple effect configuration
interface RippleOptions {
  color?: string;
  duration?: number;
  size?: number;
}

// Custom hook for creating interactive ripple effects on click/touch
export const useRippleEffect = () => {
  
  // Function to create a ripple effect at specific coordinates
  const createRipple = useCallback((
    event: React.MouseEvent<HTMLElement> | React.TouchEvent<HTMLElement>,
    options: RippleOptions = {}
  ) => {
    const {
      color = 'var(--neon-cyan)',
      duration = 600,
      size = 100
    } = options;

    const element = event.currentTarget;
    const rect = element.getBoundingClientRect();
    
    // Calculate position relative to the element
    const x = ('touches' in event ? event.touches[0].clientX : event.clientX) - rect.left;
    const y = ('touches' in event ? event.touches[0].clientY : event.clientY) - rect.top;

    // Create ripple element
    const ripple = document.createElement('div');
    ripple.className = 'ripple';
    ripple.style.cssText = `
      position: absolute;
      border-radius: 50%;
      background: radial-gradient(circle, ${color} 0%, transparent 70%);
      transform: scale(0);
      animation: ripple ${duration}ms linear;
      pointer-events: none;
      left: ${x - size / 2}px;
      top: ${y - size / 2}px;
      width: ${size}px;
      height: ${size}px;
      z-index: 1000;
    `;

    // Ensure parent has relative positioning for ripple positioning
    if (getComputedStyle(element).position === 'static') {
      element.style.position = 'relative';
    }
    
    // Add overflow hidden to contain ripple
    element.style.overflow = 'hidden';

    // Append ripple to element
    element.appendChild(ripple);

    // Remove ripple after animation completes
    setTimeout(() => {
      if (ripple.parentNode) {
        ripple.parentNode.removeChild(ripple);
      }
    }, duration);
  }, []);

  // Enhanced ripple for psychedelic effects with multiple colors
  const createPsychedelicRipple = useCallback((
    event: React.MouseEvent<HTMLElement> | React.TouchEvent<HTMLElement>
  ) => {
    const colors = [
      'var(--neon-pink)',
      'var(--neon-cyan)', 
      'var(--neon-purple)',
      'var(--neon-green)'
    ];
    
    // Create multiple ripples with different colors and sizes
    colors.forEach((color, index) => {
      setTimeout(() => {
        createRipple(event, {
          color,
          duration: 800 + index * 100,
          size: 80 + index * 20
        });
      }, index * 50);
    });
  }, [createRipple]);

  return {
    createRipple,
    createPsychedelicRipple
  };
};