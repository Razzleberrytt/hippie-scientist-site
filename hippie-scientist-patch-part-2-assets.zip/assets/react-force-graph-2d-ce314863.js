/* eslint-disable */
import { r as at, R as lo, P as v } from './main-14da0b25.js'
function fo(e, n) {
  var r = e == null ? null : (typeof Symbol < 'u' && e[Symbol.iterator]) || e['@@iterator']
  if (r != null) {
    var i,
      o,
      a,
      s,
      u = [],
      l = !0,
      f = !1
    try {
      if (((a = (r = r.call(e)).next), n === 0)) {
        if (Object(r) !== r) return
        l = !1
      } else for (; !(l = (i = a.call(r)).done) && (u.push(i.value), u.length !== n); l = !0);
    } catch (h) {
      ;((f = !0), (o = h))
    } finally {
      try {
        if (!l && r.return != null && ((s = r.return()), Object(s) !== s)) return
      } finally {
        if (f) throw o
      }
    }
    return u
  }
}
function co(e, n, r) {
  return (
    (n = xo(n)),
    n in e
      ? Object.defineProperty(e, n, { value: r, enumerable: !0, configurable: !0, writable: !0 })
      : (e[n] = r),
    e
  )
}
function Bn(e, n) {
  return go(e) || fo(e, n) || Qr(e, n) || vo()
}
function ho(e) {
  return po(e) || yo(e) || Qr(e) || _o()
}
function po(e) {
  if (Array.isArray(e)) return ln(e)
}
function go(e) {
  if (Array.isArray(e)) return e
}
function yo(e) {
  if ((typeof Symbol < 'u' && e[Symbol.iterator] != null) || e['@@iterator'] != null)
    return Array.from(e)
}
function Qr(e, n) {
  if (e) {
    if (typeof e == 'string') return ln(e, n)
    var r = Object.prototype.toString.call(e).slice(8, -1)
    if ((r === 'Object' && e.constructor && (r = e.constructor.name), r === 'Map' || r === 'Set'))
      return Array.from(e)
    if (r === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return ln(e, n)
  }
}
function ln(e, n) {
  ;(n == null || n > e.length) && (n = e.length)
  for (var r = 0, i = new Array(n); r < n; r++) i[r] = e[r]
  return i
}
function _o() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function vo() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function mo(e, n) {
  if (typeof e != 'object' || e === null) return e
  var r = e[Symbol.toPrimitive]
  if (r !== void 0) {
    var i = r.call(e, n || 'default')
    if (typeof i != 'object') return i
    throw new TypeError('@@toPrimitive must return a primitive value.')
  }
  return (n === 'string' ? String : Number)(e)
}
function xo(e) {
  var n = mo(e, 'string')
  return typeof n == 'symbol' ? n : String(n)
}
var bo = function (n, r) {
  var i = new Set(r)
  return Object.assign.apply(
    Object,
    [{}].concat(
      ho(
        Object.entries(n)
          .filter(function (o) {
            var a = Bn(o, 1),
              s = a[0]
            return !i.has(s)
          })
          .map(function (o) {
            var a = Bn(o, 2),
              s = a[0],
              u = a[1]
            return co({}, s, u)
          })
      )
    )
  )
}
function fn(e, n) {
  ;(n == null || n > e.length) && (n = e.length)
  for (var r = 0, i = Array(n); r < n; r++) i[r] = e[r]
  return i
}
function wo(e) {
  if (Array.isArray(e)) return e
}
function ko(e) {
  if (Array.isArray(e)) return fn(e)
}
function Ao(e) {
  if ((typeof Symbol < 'u' && e[Symbol.iterator] != null) || e['@@iterator'] != null)
    return Array.from(e)
}
function Co(e, n) {
  var r = e == null ? null : (typeof Symbol < 'u' && e[Symbol.iterator]) || e['@@iterator']
  if (r != null) {
    var i,
      o,
      a,
      s,
      u = [],
      l = !0,
      f = !1
    try {
      if (((a = (r = r.call(e)).next), n !== 0))
        for (; !(l = (i = a.call(r)).done) && (u.push(i.value), u.length !== n); l = !0);
    } catch (h) {
      ;((f = !0), (o = h))
    } finally {
      try {
        if (!l && r.return != null && ((s = r.return()), Object(s) !== s)) return
      } finally {
        if (f) throw o
      }
    }
    return u
  }
}
function So() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Mo() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function To(e, n) {
  return wo(e) || Co(e, n) || Jr(e, n) || So()
}
function Wn(e) {
  return ko(e) || Ao(e) || Jr(e) || Mo()
}
function Jr(e, n) {
  if (e) {
    if (typeof e == 'string') return fn(e, n)
    var r = {}.toString.call(e).slice(8, -1)
    return (
      r === 'Object' && e.constructor && (r = e.constructor.name),
      r === 'Map' || r === 'Set'
        ? Array.from(e)
        : r === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
          ? fn(e, n)
          : void 0
    )
  }
}
function Po(e) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {},
    r = n.wrapperElementType,
    i = r === void 0 ? 'div' : r,
    o = n.nodeMapper,
    a =
      o === void 0
        ? function (h) {
            return h
          }
        : o,
    s = n.methodNames,
    u = s === void 0 ? [] : s,
    l = n.initPropNames,
    f = l === void 0 ? [] : l
  return at.forwardRef(function (h, c) {
    var d = at.useRef(),
      p = at.useMemo(function () {
        var _ = Object.fromEntries(
          f
            .filter(function (g) {
              return h.hasOwnProperty(g)
            })
            .map(function (g) {
              return [g, h[g]]
            })
        )
        return e(_)
      }, [])
    ;(Xn(function () {
      p(a(d.current))
    }, at.useLayoutEffect),
      Xn(function () {
        return p._destructor instanceof Function ? p._destructor : void 0
      }))
    var y = at.useCallback(
        function (_) {
          for (var g = arguments.length, w = new Array(g > 1 ? g - 1 : 0), C = 1; C < g; C++)
            w[C - 1] = arguments[C]
          return p[_] instanceof Function ? p[_].apply(p, w) : void 0
        },
        [p]
      ),
      m = at.useRef({})
    return (
      Object.keys(bo(h, [].concat(Wn(u), Wn(f))))
        .filter(function (_) {
          return m.current[_] !== h[_]
        })
        .forEach(function (_) {
          return y(_, h[_])
        }),
      (m.current = h),
      at.useImperativeHandle(
        c,
        function () {
          return Object.fromEntries(
            u.map(function (_) {
              return [
                _,
                function () {
                  for (var g = arguments.length, w = new Array(g), C = 0; C < g; C++)
                    w[C] = arguments[C]
                  return y.apply(void 0, [_].concat(w))
                },
              ]
            })
          )
        },
        [y]
      ),
      lo.createElement(i, { ref: d })
    )
  })
}
function Xn(e) {
  var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : at.useEffect,
    r = at.useRef(),
    i = at.useRef(!1),
    o = at.useRef(!1),
    a = at.useState(0),
    s = To(a, 2)
  s[0]
  var u = s[1]
  ;(i.current && (o.current = !0),
    n(function () {
      return (
        i.current || ((r.current = e()), (i.current = !0)),
        u(function (l) {
          return l + 1
        }),
        function () {
          o.current && r.current && r.current()
        }
      )
    }, []))
}
var cn = 'http://www.w3.org/1999/xhtml'
const Yn = {
  svg: 'http://www.w3.org/2000/svg',
  xhtml: cn,
  xlink: 'http://www.w3.org/1999/xlink',
  xml: 'http://www.w3.org/XML/1998/namespace',
  xmlns: 'http://www.w3.org/2000/xmlns/',
}
function Ve(e) {
  var n = (e += ''),
    r = n.indexOf(':')
  return (
    r >= 0 && (n = e.slice(0, r)) !== 'xmlns' && (e = e.slice(r + 1)),
    Yn.hasOwnProperty(n) ? { space: Yn[n], local: e } : e
  )
}
function Oo(e) {
  return function () {
    var n = this.ownerDocument,
      r = this.namespaceURI
    return r === cn && n.documentElement.namespaceURI === cn
      ? n.createElement(e)
      : n.createElementNS(r, e)
  }
}
function Eo(e) {
  return function () {
    return this.ownerDocument.createElementNS(e.space, e.local)
  }
}
function ti(e) {
  var n = Ve(e)
  return (n.local ? Eo : Oo)(n)
}
function zo() {}
function Pn(e) {
  return e == null
    ? zo
    : function () {
        return this.querySelector(e)
      }
}
function Ro(e) {
  typeof e != 'function' && (e = Pn(e))
  for (var n = this._groups, r = n.length, i = new Array(r), o = 0; o < r; ++o)
    for (var a = n[o], s = a.length, u = (i[o] = new Array(s)), l, f, h = 0; h < s; ++h)
      (l = a[h]) &&
        (f = e.call(l, l.__data__, h, a)) &&
        ('__data__' in l && (f.__data__ = l.__data__), (u[h] = f))
  return new rt(i, this._parents)
}
function No(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e)
}
function $o() {
  return []
}
function ei(e) {
  return e == null
    ? $o
    : function () {
        return this.querySelectorAll(e)
      }
}
function Io(e) {
  return function () {
    return No(e.apply(this, arguments))
  }
}
function Do(e) {
  typeof e == 'function' ? (e = Io(e)) : (e = ei(e))
  for (var n = this._groups, r = n.length, i = [], o = [], a = 0; a < r; ++a)
    for (var s = n[a], u = s.length, l, f = 0; f < u; ++f)
      (l = s[f]) && (i.push(e.call(l, l.__data__, f, s)), o.push(l))
  return new rt(i, o)
}
function ni(e) {
  return function () {
    return this.matches(e)
  }
}
function ri(e) {
  return function (n) {
    return n.matches(e)
  }
}
var jo = Array.prototype.find
function Fo(e) {
  return function () {
    return jo.call(this.children, e)
  }
}
function Uo() {
  return this.firstElementChild
}
function Lo(e) {
  return this.select(e == null ? Uo : Fo(typeof e == 'function' ? e : ri(e)))
}
var Ho = Array.prototype.filter
function qo() {
  return Array.from(this.children)
}
function Go(e) {
  return function () {
    return Ho.call(this.children, e)
  }
}
function Vo(e) {
  return this.selectAll(e == null ? qo : Go(typeof e == 'function' ? e : ri(e)))
}
function Bo(e) {
  typeof e != 'function' && (e = ni(e))
  for (var n = this._groups, r = n.length, i = new Array(r), o = 0; o < r; ++o)
    for (var a = n[o], s = a.length, u = (i[o] = []), l, f = 0; f < s; ++f)
      (l = a[f]) && e.call(l, l.__data__, f, a) && u.push(l)
  return new rt(i, this._parents)
}
function ii(e) {
  return new Array(e.length)
}
function Wo() {
  return new rt(this._enter || this._groups.map(ii), this._parents)
}
function Re(e, n) {
  ;((this.ownerDocument = e.ownerDocument),
    (this.namespaceURI = e.namespaceURI),
    (this._next = null),
    (this._parent = e),
    (this.__data__ = n))
}
Re.prototype = {
  constructor: Re,
  appendChild: function (e) {
    return this._parent.insertBefore(e, this._next)
  },
  insertBefore: function (e, n) {
    return this._parent.insertBefore(e, n)
  },
  querySelector: function (e) {
    return this._parent.querySelector(e)
  },
  querySelectorAll: function (e) {
    return this._parent.querySelectorAll(e)
  },
}
function Xo(e) {
  return function () {
    return e
  }
}
function Yo(e, n, r, i, o, a) {
  for (var s = 0, u, l = n.length, f = a.length; s < f; ++s)
    (u = n[s]) ? ((u.__data__ = a[s]), (i[s] = u)) : (r[s] = new Re(e, a[s]))
  for (; s < l; ++s) (u = n[s]) && (o[s] = u)
}
function Zo(e, n, r, i, o, a, s) {
  var u,
    l,
    f = new Map(),
    h = n.length,
    c = a.length,
    d = new Array(h),
    p
  for (u = 0; u < h; ++u)
    (l = n[u]) &&
      ((d[u] = p = s.call(l, l.__data__, u, n) + ''), f.has(p) ? (o[u] = l) : f.set(p, l))
  for (u = 0; u < c; ++u)
    ((p = s.call(e, a[u], u, a) + ''),
      (l = f.get(p)) ? ((i[u] = l), (l.__data__ = a[u]), f.delete(p)) : (r[u] = new Re(e, a[u])))
  for (u = 0; u < h; ++u) (l = n[u]) && f.get(d[u]) === l && (o[u] = l)
}
function Ko(e) {
  return e.__data__
}
function Qo(e, n) {
  if (!arguments.length) return Array.from(this, Ko)
  var r = n ? Zo : Yo,
    i = this._parents,
    o = this._groups
  typeof e != 'function' && (e = Xo(e))
  for (var a = o.length, s = new Array(a), u = new Array(a), l = new Array(a), f = 0; f < a; ++f) {
    var h = i[f],
      c = o[f],
      d = c.length,
      p = Jo(e.call(h, h && h.__data__, f, i)),
      y = p.length,
      m = (u[f] = new Array(y)),
      _ = (s[f] = new Array(y)),
      g = (l[f] = new Array(d))
    r(h, c, m, _, g, p, n)
    for (var w = 0, C = 0, x, b; w < y; ++w)
      if ((x = m[w])) {
        for (w >= C && (C = w + 1); !(b = _[C]) && ++C < y; );
        x._next = b || null
      }
  }
  return ((s = new rt(s, i)), (s._enter = u), (s._exit = l), s)
}
function Jo(e) {
  return typeof e == 'object' && 'length' in e ? e : Array.from(e)
}
function ta() {
  return new rt(this._exit || this._groups.map(ii), this._parents)
}
function ea(e, n, r) {
  var i = this.enter(),
    o = this,
    a = this.exit()
  return (
    typeof e == 'function' ? ((i = e(i)), i && (i = i.selection())) : (i = i.append(e + '')),
    n != null && ((o = n(o)), o && (o = o.selection())),
    r == null ? a.remove() : r(a),
    i && o ? i.merge(o).order() : o
  )
}
function na(e) {
  for (
    var n = e.selection ? e.selection() : e,
      r = this._groups,
      i = n._groups,
      o = r.length,
      a = i.length,
      s = Math.min(o, a),
      u = new Array(o),
      l = 0;
    l < s;
    ++l
  )
    for (var f = r[l], h = i[l], c = f.length, d = (u[l] = new Array(c)), p, y = 0; y < c; ++y)
      (p = f[y] || h[y]) && (d[y] = p)
  for (; l < o; ++l) u[l] = r[l]
  return new rt(u, this._parents)
}
function ra() {
  for (var e = this._groups, n = -1, r = e.length; ++n < r; )
    for (var i = e[n], o = i.length - 1, a = i[o], s; --o >= 0; )
      (s = i[o]) &&
        (a && s.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(s, a), (a = s))
  return this
}
function ia(e) {
  e || (e = oa)
  function n(c, d) {
    return c && d ? e(c.__data__, d.__data__) : !c - !d
  }
  for (var r = this._groups, i = r.length, o = new Array(i), a = 0; a < i; ++a) {
    for (var s = r[a], u = s.length, l = (o[a] = new Array(u)), f, h = 0; h < u; ++h)
      (f = s[h]) && (l[h] = f)
    l.sort(n)
  }
  return new rt(o, this._parents).order()
}
function oa(e, n) {
  return e < n ? -1 : e > n ? 1 : e >= n ? 0 : NaN
}
function aa() {
  var e = arguments[0]
  return ((arguments[0] = this), e.apply(null, arguments), this)
}
function sa() {
  return Array.from(this)
}
function ua() {
  for (var e = this._groups, n = 0, r = e.length; n < r; ++n)
    for (var i = e[n], o = 0, a = i.length; o < a; ++o) {
      var s = i[o]
      if (s) return s
    }
  return null
}
function la() {
  let e = 0
  for (const n of this) ++e
  return e
}
function fa() {
  return !this.node()
}
function ca(e) {
  for (var n = this._groups, r = 0, i = n.length; r < i; ++r)
    for (var o = n[r], a = 0, s = o.length, u; a < s; ++a) (u = o[a]) && e.call(u, u.__data__, a, o)
  return this
}
function ha(e) {
  return function () {
    this.removeAttribute(e)
  }
}
function da(e) {
  return function () {
    this.removeAttributeNS(e.space, e.local)
  }
}
function pa(e, n) {
  return function () {
    this.setAttribute(e, n)
  }
}
function ga(e, n) {
  return function () {
    this.setAttributeNS(e.space, e.local, n)
  }
}
function ya(e, n) {
  return function () {
    var r = n.apply(this, arguments)
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r)
  }
}
function _a(e, n) {
  return function () {
    var r = n.apply(this, arguments)
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r)
  }
}
function va(e, n) {
  var r = Ve(e)
  if (arguments.length < 2) {
    var i = this.node()
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r)
  }
  return this.each(
    (n == null
      ? r.local
        ? da
        : ha
      : typeof n == 'function'
        ? r.local
          ? _a
          : ya
        : r.local
          ? ga
          : pa)(r, n)
  )
}
function oi(e) {
  return (e.ownerDocument && e.ownerDocument.defaultView) || (e.document && e) || e.defaultView
}
function ma(e) {
  return function () {
    this.style.removeProperty(e)
  }
}
function xa(e, n, r) {
  return function () {
    this.style.setProperty(e, n, r)
  }
}
function ba(e, n, r) {
  return function () {
    var i = n.apply(this, arguments)
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r)
  }
}
function wa(e, n, r) {
  return arguments.length > 1
    ? this.each((n == null ? ma : typeof n == 'function' ? ba : xa)(e, n, r ?? ''))
    : Bt(this.node(), e)
}
function Bt(e, n) {
  return e.style.getPropertyValue(n) || oi(e).getComputedStyle(e, null).getPropertyValue(n)
}
function ka(e) {
  return function () {
    delete this[e]
  }
}
function Aa(e, n) {
  return function () {
    this[e] = n
  }
}
function Ca(e, n) {
  return function () {
    var r = n.apply(this, arguments)
    r == null ? delete this[e] : (this[e] = r)
  }
}
function Sa(e, n) {
  return arguments.length > 1
    ? this.each((n == null ? ka : typeof n == 'function' ? Ca : Aa)(e, n))
    : this.node()[e]
}
function ai(e) {
  return e.trim().split(/^|\s+/)
}
function On(e) {
  return e.classList || new si(e)
}
function si(e) {
  ;((this._node = e), (this._names = ai(e.getAttribute('class') || '')))
}
si.prototype = {
  add: function (e) {
    var n = this._names.indexOf(e)
    n < 0 && (this._names.push(e), this._node.setAttribute('class', this._names.join(' ')))
  },
  remove: function (e) {
    var n = this._names.indexOf(e)
    n >= 0 && (this._names.splice(n, 1), this._node.setAttribute('class', this._names.join(' ')))
  },
  contains: function (e) {
    return this._names.indexOf(e) >= 0
  },
}
function ui(e, n) {
  for (var r = On(e), i = -1, o = n.length; ++i < o; ) r.add(n[i])
}
function li(e, n) {
  for (var r = On(e), i = -1, o = n.length; ++i < o; ) r.remove(n[i])
}
function Ma(e) {
  return function () {
    ui(this, e)
  }
}
function Ta(e) {
  return function () {
    li(this, e)
  }
}
function Pa(e, n) {
  return function () {
    ;(n.apply(this, arguments) ? ui : li)(this, e)
  }
}
function Oa(e, n) {
  var r = ai(e + '')
  if (arguments.length < 2) {
    for (var i = On(this.node()), o = -1, a = r.length; ++o < a; ) if (!i.contains(r[o])) return !1
    return !0
  }
  return this.each((typeof n == 'function' ? Pa : n ? Ma : Ta)(r, n))
}
function Ea() {
  this.textContent = ''
}
function za(e) {
  return function () {
    this.textContent = e
  }
}
function Ra(e) {
  return function () {
    var n = e.apply(this, arguments)
    this.textContent = n ?? ''
  }
}
function Na(e) {
  return arguments.length
    ? this.each(e == null ? Ea : (typeof e == 'function' ? Ra : za)(e))
    : this.node().textContent
}
function $a() {
  this.innerHTML = ''
}
function Ia(e) {
  return function () {
    this.innerHTML = e
  }
}
function Da(e) {
  return function () {
    var n = e.apply(this, arguments)
    this.innerHTML = n ?? ''
  }
}
function ja(e) {
  return arguments.length
    ? this.each(e == null ? $a : (typeof e == 'function' ? Da : Ia)(e))
    : this.node().innerHTML
}
function Fa() {
  this.nextSibling && this.parentNode.appendChild(this)
}
function Ua() {
  return this.each(Fa)
}
function La() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild)
}
function Ha() {
  return this.each(La)
}
function qa(e) {
  var n = typeof e == 'function' ? e : ti(e)
  return this.select(function () {
    return this.appendChild(n.apply(this, arguments))
  })
}
function Ga() {
  return null
}
function Va(e, n) {
  var r = typeof e == 'function' ? e : ti(e),
    i = n == null ? Ga : typeof n == 'function' ? n : Pn(n)
  return this.select(function () {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null)
  })
}
function Ba() {
  var e = this.parentNode
  e && e.removeChild(this)
}
function Wa() {
  return this.each(Ba)
}
function Xa() {
  var e = this.cloneNode(!1),
    n = this.parentNode
  return n ? n.insertBefore(e, this.nextSibling) : e
}
function Ya() {
  var e = this.cloneNode(!0),
    n = this.parentNode
  return n ? n.insertBefore(e, this.nextSibling) : e
}
function Za(e) {
  return this.select(e ? Ya : Xa)
}
function Ka(e) {
  return arguments.length ? this.property('__data__', e) : this.node().__data__
}
function Qa(e) {
  return function (n) {
    e.call(this, n, this.__data__)
  }
}
function Ja(e) {
  return e
    .trim()
    .split(/^|\s+/)
    .map(function (n) {
      var r = '',
        i = n.indexOf('.')
      return (i >= 0 && ((r = n.slice(i + 1)), (n = n.slice(0, i))), { type: n, name: r })
    })
}
function ts(e) {
  return function () {
    var n = this.__on
    if (n) {
      for (var r = 0, i = -1, o = n.length, a; r < o; ++r)
        ((a = n[r]),
          (!e.type || a.type === e.type) && a.name === e.name
            ? this.removeEventListener(a.type, a.listener, a.options)
            : (n[++i] = a))
      ++i ? (n.length = i) : delete this.__on
    }
  }
}
function es(e, n, r) {
  return function () {
    var i = this.__on,
      o,
      a = Qa(n)
    if (i) {
      for (var s = 0, u = i.length; s < u; ++s)
        if ((o = i[s]).type === e.type && o.name === e.name) {
          ;(this.removeEventListener(o.type, o.listener, o.options),
            this.addEventListener(o.type, (o.listener = a), (o.options = r)),
            (o.value = n))
          return
        }
    }
    ;(this.addEventListener(e.type, a, r),
      (o = { type: e.type, name: e.name, value: n, listener: a, options: r }),
      i ? i.push(o) : (this.__on = [o]))
  }
}
function ns(e, n, r) {
  var i = Ja(e + ''),
    o,
    a = i.length,
    s
  if (arguments.length < 2) {
    var u = this.node().__on
    if (u) {
      for (var l = 0, f = u.length, h; l < f; ++l)
        for (o = 0, h = u[l]; o < a; ++o)
          if ((s = i[o]).type === h.type && s.name === h.name) return h.value
    }
    return
  }
  for (u = n ? es : ts, o = 0; o < a; ++o) this.each(u(i[o], n, r))
  return this
}
function fi(e, n, r) {
  var i = oi(e),
    o = i.CustomEvent
  ;(typeof o == 'function'
    ? (o = new o(n, r))
    : ((o = i.document.createEvent('Event')),
      r
        ? (o.initEvent(n, r.bubbles, r.cancelable), (o.detail = r.detail))
        : o.initEvent(n, !1, !1)),
    e.dispatchEvent(o))
}
function rs(e, n) {
  return function () {
    return fi(this, e, n)
  }
}
function is(e, n) {
  return function () {
    return fi(this, e, n.apply(this, arguments))
  }
}
function os(e, n) {
  return this.each((typeof n == 'function' ? is : rs)(e, n))
}
function* as() {
  for (var e = this._groups, n = 0, r = e.length; n < r; ++n)
    for (var i = e[n], o = 0, a = i.length, s; o < a; ++o) (s = i[o]) && (yield s)
}
var ci = [null]
function rt(e, n) {
  ;((this._groups = e), (this._parents = n))
}
function _e() {
  return new rt([[document.documentElement]], ci)
}
function ss() {
  return this
}
rt.prototype = _e.prototype = {
  constructor: rt,
  select: Ro,
  selectAll: Do,
  selectChild: Lo,
  selectChildren: Vo,
  filter: Bo,
  data: Qo,
  enter: Wo,
  exit: ta,
  join: ea,
  merge: na,
  selection: ss,
  order: ra,
  sort: ia,
  call: aa,
  nodes: sa,
  node: ua,
  size: la,
  empty: fa,
  each: ca,
  attr: va,
  style: wa,
  property: Sa,
  classed: Oa,
  text: Na,
  html: ja,
  raise: Ua,
  lower: Ha,
  append: qa,
  insert: Va,
  remove: Wa,
  clone: Za,
  datum: Ka,
  on: ns,
  dispatch: os,
  [Symbol.iterator]: as,
}
function st(e) {
  return typeof e == 'string'
    ? new rt([[document.querySelector(e)]], [document.documentElement])
    : new rt([[e]], ci)
}
function us(e) {
  let n
  for (; (n = e.sourceEvent); ) e = n
  return e
}
function yt(e, n) {
  if (((e = us(e)), n === void 0 && (n = e.currentTarget), n)) {
    var r = n.ownerSVGElement || n
    if (r.createSVGPoint) {
      var i = r.createSVGPoint()
      return (
        (i.x = e.clientX),
        (i.y = e.clientY),
        (i = i.matrixTransform(n.getScreenCTM().inverse())),
        [i.x, i.y]
      )
    }
    if (n.getBoundingClientRect) {
      var o = n.getBoundingClientRect()
      return [e.clientX - o.left - n.clientLeft, e.clientY - o.top - n.clientTop]
    }
  }
  return [e.pageX, e.pageY]
}
var ls = { value: () => {} }
function ve() {
  for (var e = 0, n = arguments.length, r = {}, i; e < n; ++e) {
    if (!(i = arguments[e] + '') || i in r || /[\s.]/.test(i)) throw new Error('illegal type: ' + i)
    r[i] = []
  }
  return new Te(r)
}
function Te(e) {
  this._ = e
}
function fs(e, n) {
  return e
    .trim()
    .split(/^|\s+/)
    .map(function (r) {
      var i = '',
        o = r.indexOf('.')
      if ((o >= 0 && ((i = r.slice(o + 1)), (r = r.slice(0, o))), r && !n.hasOwnProperty(r)))
        throw new Error('unknown type: ' + r)
      return { type: r, name: i }
    })
}
Te.prototype = ve.prototype = {
  constructor: Te,
  on: function (e, n) {
    var r = this._,
      i = fs(e + '', r),
      o,
      a = -1,
      s = i.length
    if (arguments.length < 2) {
      for (; ++a < s; ) if ((o = (e = i[a]).type) && (o = cs(r[o], e.name))) return o
      return
    }
    if (n != null && typeof n != 'function') throw new Error('invalid callback: ' + n)
    for (; ++a < s; )
      if ((o = (e = i[a]).type)) r[o] = Zn(r[o], e.name, n)
      else if (n == null) for (o in r) r[o] = Zn(r[o], e.name, null)
    return this
  },
  copy: function () {
    var e = {},
      n = this._
    for (var r in n) e[r] = n[r].slice()
    return new Te(e)
  },
  call: function (e, n) {
    if ((o = arguments.length - 2) > 0)
      for (var r = new Array(o), i = 0, o, a; i < o; ++i) r[i] = arguments[i + 2]
    if (!this._.hasOwnProperty(e)) throw new Error('unknown type: ' + e)
    for (a = this._[e], i = 0, o = a.length; i < o; ++i) a[i].value.apply(n, r)
  },
  apply: function (e, n, r) {
    if (!this._.hasOwnProperty(e)) throw new Error('unknown type: ' + e)
    for (var i = this._[e], o = 0, a = i.length; o < a; ++o) i[o].value.apply(n, r)
  },
}
function cs(e, n) {
  for (var r = 0, i = e.length, o; r < i; ++r) if ((o = e[r]).name === n) return o.value
}
function Zn(e, n, r) {
  for (var i = 0, o = e.length; i < o; ++i)
    if (e[i].name === n) {
      ;((e[i] = ls), (e = e.slice(0, i).concat(e.slice(i + 1))))
      break
    }
  return (r != null && e.push({ name: n, value: r }), e)
}
const hs = { passive: !1 },
  fe = { capture: !0, passive: !1 }
function Je(e) {
  e.stopImmediatePropagation()
}
function Gt(e) {
  ;(e.preventDefault(), e.stopImmediatePropagation())
}
function hi(e) {
  var n = e.document.documentElement,
    r = st(e).on('dragstart.drag', Gt, fe)
  'onselectstart' in n
    ? r.on('selectstart.drag', Gt, fe)
    : ((n.__noselect = n.style.MozUserSelect), (n.style.MozUserSelect = 'none'))
}
function di(e, n) {
  var r = e.document.documentElement,
    i = st(e).on('dragstart.drag', null)
  ;(n &&
    (i.on('click.drag', Gt, fe),
    setTimeout(function () {
      i.on('click.drag', null)
    }, 0)),
    'onselectstart' in r
      ? i.on('selectstart.drag', null)
      : ((r.style.MozUserSelect = r.__noselect), delete r.__noselect))
}
const be = e => () => e
function hn(
  e,
  {
    sourceEvent: n,
    subject: r,
    target: i,
    identifier: o,
    active: a,
    x: s,
    y: u,
    dx: l,
    dy: f,
    dispatch: h,
  }
) {
  Object.defineProperties(this, {
    type: { value: e, enumerable: !0, configurable: !0 },
    sourceEvent: { value: n, enumerable: !0, configurable: !0 },
    subject: { value: r, enumerable: !0, configurable: !0 },
    target: { value: i, enumerable: !0, configurable: !0 },
    identifier: { value: o, enumerable: !0, configurable: !0 },
    active: { value: a, enumerable: !0, configurable: !0 },
    x: { value: s, enumerable: !0, configurable: !0 },
    y: { value: u, enumerable: !0, configurable: !0 },
    dx: { value: l, enumerable: !0, configurable: !0 },
    dy: { value: f, enumerable: !0, configurable: !0 },
    _: { value: h },
  })
}
hn.prototype.on = function () {
  var e = this._.on.apply(this._, arguments)
  return e === this._ ? this : e
}
function ds(e) {
  return !e.ctrlKey && !e.button
}
function ps() {
  return this.parentNode
}
function gs(e, n) {
  return n ?? { x: e.x, y: e.y }
}
function ys() {
  return navigator.maxTouchPoints || 'ontouchstart' in this
}
function _s() {
  var e = ds,
    n = ps,
    r = gs,
    i = ys,
    o = {},
    a = ve('start', 'drag', 'end'),
    s = 0,
    u,
    l,
    f,
    h,
    c = 0
  function d(x) {
    x.on('mousedown.drag', p)
      .filter(i)
      .on('touchstart.drag', _)
      .on('touchmove.drag', g, hs)
      .on('touchend.drag touchcancel.drag', w)
      .style('touch-action', 'none')
      .style('-webkit-tap-highlight-color', 'rgba(0,0,0,0)')
  }
  function p(x, b) {
    if (!(h || !e.call(this, x, b))) {
      var A = C(this, n.call(this, x, b), x, b, 'mouse')
      A &&
        (st(x.view).on('mousemove.drag', y, fe).on('mouseup.drag', m, fe),
        hi(x.view),
        Je(x),
        (f = !1),
        (u = x.clientX),
        (l = x.clientY),
        A('start', x))
    }
  }
  function y(x) {
    if ((Gt(x), !f)) {
      var b = x.clientX - u,
        A = x.clientY - l
      f = b * b + A * A > c
    }
    o.mouse('drag', x)
  }
  function m(x) {
    ;(st(x.view).on('mousemove.drag mouseup.drag', null), di(x.view, f), Gt(x), o.mouse('end', x))
  }
  function _(x, b) {
    if (e.call(this, x, b)) {
      var A = x.changedTouches,
        S = n.call(this, x, b),
        M = A.length,
        R,
        O
      for (R = 0; R < M; ++R)
        (O = C(this, S, x, b, A[R].identifier, A[R])) && (Je(x), O('start', x, A[R]))
    }
  }
  function g(x) {
    var b = x.changedTouches,
      A = b.length,
      S,
      M
    for (S = 0; S < A; ++S) (M = o[b[S].identifier]) && (Gt(x), M('drag', x, b[S]))
  }
  function w(x) {
    var b = x.changedTouches,
      A = b.length,
      S,
      M
    for (
      h && clearTimeout(h),
        h = setTimeout(function () {
          h = null
        }, 500),
        S = 0;
      S < A;
      ++S
    )
      (M = o[b[S].identifier]) && (Je(x), M('end', x, b[S]))
  }
  function C(x, b, A, S, M, R) {
    var O = a.copy(),
      z = yt(R || A, b),
      N,
      j,
      k
    if (
      (k = r.call(
        x,
        new hn('beforestart', {
          sourceEvent: A,
          target: d,
          identifier: M,
          active: s,
          x: z[0],
          y: z[1],
          dx: 0,
          dy: 0,
          dispatch: O,
        }),
        S
      )) != null
    )
      return (
        (N = k.x - z[0] || 0),
        (j = k.y - z[1] || 0),
        function E(T, $, D) {
          var F = z,
            U
          switch (T) {
            case 'start':
              ;((o[M] = E), (U = s++))
              break
            case 'end':
              ;(delete o[M], --s)
            case 'drag':
              ;((z = yt(D || $, b)), (U = s))
              break
          }
          O.call(
            T,
            x,
            new hn(T, {
              sourceEvent: $,
              subject: k,
              target: d,
              identifier: M,
              active: U,
              x: z[0] + N,
              y: z[1] + j,
              dx: z[0] - F[0],
              dy: z[1] - F[1],
              dispatch: O,
            }),
            S
          )
        }
      )
  }
  return (
    (d.filter = function (x) {
      return arguments.length ? ((e = typeof x == 'function' ? x : be(!!x)), d) : e
    }),
    (d.container = function (x) {
      return arguments.length ? ((n = typeof x == 'function' ? x : be(x)), d) : n
    }),
    (d.subject = function (x) {
      return arguments.length ? ((r = typeof x == 'function' ? x : be(x)), d) : r
    }),
    (d.touchable = function (x) {
      return arguments.length ? ((i = typeof x == 'function' ? x : be(!!x)), d) : i
    }),
    (d.on = function () {
      var x = a.on.apply(a, arguments)
      return x === a ? d : x
    }),
    (d.clickDistance = function (x) {
      return arguments.length ? ((c = (x = +x) * x), d) : Math.sqrt(c)
    }),
    d
  )
}
function En(e, n, r) {
  ;((e.prototype = n.prototype = r), (r.constructor = e))
}
function pi(e, n) {
  var r = Object.create(e.prototype)
  for (var i in n) r[i] = n[i]
  return r
}
function me() {}
var ce = 0.7,
  Ne = 1 / ce,
  Vt = '\\s*([+-]?\\d+)\\s*',
  he = '\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*',
  vt = '\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*',
  vs = /^#([0-9a-f]{3,8})$/,
  ms = new RegExp(`^rgb\\(${Vt},${Vt},${Vt}\\)$`),
  xs = new RegExp(`^rgb\\(${vt},${vt},${vt}\\)$`),
  bs = new RegExp(`^rgba\\(${Vt},${Vt},${Vt},${he}\\)$`),
  ws = new RegExp(`^rgba\\(${vt},${vt},${vt},${he}\\)$`),
  ks = new RegExp(`^hsl\\(${he},${vt},${vt}\\)$`),
  As = new RegExp(`^hsla\\(${he},${vt},${vt},${he}\\)$`),
  Kn = {
    aliceblue: 15792383,
    antiquewhite: 16444375,
    aqua: 65535,
    aquamarine: 8388564,
    azure: 15794175,
    beige: 16119260,
    bisque: 16770244,
    black: 0,
    blanchedalmond: 16772045,
    blue: 255,
    blueviolet: 9055202,
    brown: 10824234,
    burlywood: 14596231,
    cadetblue: 6266528,
    chartreuse: 8388352,
    chocolate: 13789470,
    coral: 16744272,
    cornflowerblue: 6591981,
    cornsilk: 16775388,
    crimson: 14423100,
    cyan: 65535,
    darkblue: 139,
    darkcyan: 35723,
    darkgoldenrod: 12092939,
    darkgray: 11119017,
    darkgreen: 25600,
    darkgrey: 11119017,
    darkkhaki: 12433259,
    darkmagenta: 9109643,
    darkolivegreen: 5597999,
    darkorange: 16747520,
    darkorchid: 10040012,
    darkred: 9109504,
    darksalmon: 15308410,
    darkseagreen: 9419919,
    darkslateblue: 4734347,
    darkslategray: 3100495,
    darkslategrey: 3100495,
    darkturquoise: 52945,
    darkviolet: 9699539,
    deeppink: 16716947,
    deepskyblue: 49151,
    dimgray: 6908265,
    dimgrey: 6908265,
    dodgerblue: 2003199,
    firebrick: 11674146,
    floralwhite: 16775920,
    forestgreen: 2263842,
    fuchsia: 16711935,
    gainsboro: 14474460,
    ghostwhite: 16316671,
    gold: 16766720,
    goldenrod: 14329120,
    gray: 8421504,
    green: 32768,
    greenyellow: 11403055,
    grey: 8421504,
    honeydew: 15794160,
    hotpink: 16738740,
    indianred: 13458524,
    indigo: 4915330,
    ivory: 16777200,
    khaki: 15787660,
    lavender: 15132410,
    lavenderblush: 16773365,
    lawngreen: 8190976,
    lemonchiffon: 16775885,
    lightblue: 11393254,
    lightcoral: 15761536,
    lightcyan: 14745599,
    lightgoldenrodyellow: 16448210,
    lightgray: 13882323,
    lightgreen: 9498256,
    lightgrey: 13882323,
    lightpink: 16758465,
    lightsalmon: 16752762,
    lightseagreen: 2142890,
    lightskyblue: 8900346,
    lightslategray: 7833753,
    lightslategrey: 7833753,
    lightsteelblue: 11584734,
    lightyellow: 16777184,
    lime: 65280,
    limegreen: 3329330,
    linen: 16445670,
    magenta: 16711935,
    maroon: 8388608,
    mediumaquamarine: 6737322,
    mediumblue: 205,
    mediumorchid: 12211667,
    mediumpurple: 9662683,
    mediumseagreen: 3978097,
    mediumslateblue: 8087790,
    mediumspringgreen: 64154,
    mediumturquoise: 4772300,
    mediumvioletred: 13047173,
    midnightblue: 1644912,
    mintcream: 16121850,
    mistyrose: 16770273,
    moccasin: 16770229,
    navajowhite: 16768685,
    navy: 128,
    oldlace: 16643558,
    olive: 8421376,
    olivedrab: 7048739,
    orange: 16753920,
    orangered: 16729344,
    orchid: 14315734,
    palegoldenrod: 15657130,
    palegreen: 10025880,
    paleturquoise: 11529966,
    palevioletred: 14381203,
    papayawhip: 16773077,
    peachpuff: 16767673,
    peru: 13468991,
    pink: 16761035,
    plum: 14524637,
    powderblue: 11591910,
    purple: 8388736,
    rebeccapurple: 6697881,
    red: 16711680,
    rosybrown: 12357519,
    royalblue: 4286945,
    saddlebrown: 9127187,
    salmon: 16416882,
    sandybrown: 16032864,
    seagreen: 3050327,
    seashell: 16774638,
    sienna: 10506797,
    silver: 12632256,
    skyblue: 8900331,
    slateblue: 6970061,
    slategray: 7372944,
    slategrey: 7372944,
    snow: 16775930,
    springgreen: 65407,
    steelblue: 4620980,
    tan: 13808780,
    teal: 32896,
    thistle: 14204888,
    tomato: 16737095,
    turquoise: 4251856,
    violet: 15631086,
    wheat: 16113331,
    white: 16777215,
    whitesmoke: 16119285,
    yellow: 16776960,
    yellowgreen: 10145074,
  }
En(me, de, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e)
  },
  displayable() {
    return this.rgb().displayable()
  },
  hex: Qn,
  formatHex: Qn,
  formatHex8: Cs,
  formatHsl: Ss,
  formatRgb: Jn,
  toString: Jn,
})
function Qn() {
  return this.rgb().formatHex()
}
function Cs() {
  return this.rgb().formatHex8()
}
function Ss() {
  return gi(this).formatHsl()
}
function Jn() {
  return this.rgb().formatRgb()
}
function de(e) {
  var n, r
  return (
    (e = (e + '').trim().toLowerCase()),
    (n = vs.exec(e))
      ? ((r = n[1].length),
        (n = parseInt(n[1], 16)),
        r === 6
          ? tr(n)
          : r === 3
            ? new tt(
                ((n >> 8) & 15) | ((n >> 4) & 240),
                ((n >> 4) & 15) | (n & 240),
                ((n & 15) << 4) | (n & 15),
                1
              )
            : r === 8
              ? we((n >> 24) & 255, (n >> 16) & 255, (n >> 8) & 255, (n & 255) / 255)
              : r === 4
                ? we(
                    ((n >> 12) & 15) | ((n >> 8) & 240),
                    ((n >> 8) & 15) | ((n >> 4) & 240),
                    ((n >> 4) & 15) | (n & 240),
                    (((n & 15) << 4) | (n & 15)) / 255
                  )
                : null)
      : (n = ms.exec(e))
        ? new tt(n[1], n[2], n[3], 1)
        : (n = xs.exec(e))
          ? new tt((n[1] * 255) / 100, (n[2] * 255) / 100, (n[3] * 255) / 100, 1)
          : (n = bs.exec(e))
            ? we(n[1], n[2], n[3], n[4])
            : (n = ws.exec(e))
              ? we((n[1] * 255) / 100, (n[2] * 255) / 100, (n[3] * 255) / 100, n[4])
              : (n = ks.exec(e))
                ? rr(n[1], n[2] / 100, n[3] / 100, 1)
                : (n = As.exec(e))
                  ? rr(n[1], n[2] / 100, n[3] / 100, n[4])
                  : Kn.hasOwnProperty(e)
                    ? tr(Kn[e])
                    : e === 'transparent'
                      ? new tt(NaN, NaN, NaN, 0)
                      : null
  )
}
function tr(e) {
  return new tt((e >> 16) & 255, (e >> 8) & 255, e & 255, 1)
}
function we(e, n, r, i) {
  return (i <= 0 && (e = n = r = NaN), new tt(e, n, r, i))
}
function Ms(e) {
  return (
    e instanceof me || (e = de(e)),
    e ? ((e = e.rgb()), new tt(e.r, e.g, e.b, e.opacity)) : new tt()
  )
}
function dn(e, n, r, i) {
  return arguments.length === 1 ? Ms(e) : new tt(e, n, r, i ?? 1)
}
function tt(e, n, r, i) {
  ;((this.r = +e), (this.g = +n), (this.b = +r), (this.opacity = +i))
}
En(
  tt,
  dn,
  pi(me, {
    brighter(e) {
      return (
        (e = e == null ? Ne : Math.pow(Ne, e)),
        new tt(this.r * e, this.g * e, this.b * e, this.opacity)
      )
    },
    darker(e) {
      return (
        (e = e == null ? ce : Math.pow(ce, e)),
        new tt(this.r * e, this.g * e, this.b * e, this.opacity)
      )
    },
    rgb() {
      return this
    },
    clamp() {
      return new tt(jt(this.r), jt(this.g), jt(this.b), $e(this.opacity))
    },
    displayable() {
      return (
        -0.5 <= this.r &&
        this.r < 255.5 &&
        -0.5 <= this.g &&
        this.g < 255.5 &&
        -0.5 <= this.b &&
        this.b < 255.5 &&
        0 <= this.opacity &&
        this.opacity <= 1
      )
    },
    hex: er,
    formatHex: er,
    formatHex8: Ts,
    formatRgb: nr,
    toString: nr,
  })
)
function er() {
  return `#${Dt(this.r)}${Dt(this.g)}${Dt(this.b)}`
}
function Ts() {
  return `#${Dt(this.r)}${Dt(this.g)}${Dt(this.b)}${Dt((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`
}
function nr() {
  const e = $e(this.opacity)
  return `${e === 1 ? 'rgb(' : 'rgba('}${jt(this.r)}, ${jt(this.g)}, ${jt(this.b)}${e === 1 ? ')' : `, ${e})`}`
}
function $e(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e))
}
function jt(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0))
}
function Dt(e) {
  return ((e = jt(e)), (e < 16 ? '0' : '') + e.toString(16))
}
function rr(e, n, r, i) {
  return (
    i <= 0 ? (e = n = r = NaN) : r <= 0 || r >= 1 ? (e = n = NaN) : n <= 0 && (e = NaN),
    new ht(e, n, r, i)
  )
}
function gi(e) {
  if (e instanceof ht) return new ht(e.h, e.s, e.l, e.opacity)
  if ((e instanceof me || (e = de(e)), !e)) return new ht()
  if (e instanceof ht) return e
  e = e.rgb()
  var n = e.r / 255,
    r = e.g / 255,
    i = e.b / 255,
    o = Math.min(n, r, i),
    a = Math.max(n, r, i),
    s = NaN,
    u = a - o,
    l = (a + o) / 2
  return (
    u
      ? (n === a
          ? (s = (r - i) / u + (r < i) * 6)
          : r === a
            ? (s = (i - n) / u + 2)
            : (s = (n - r) / u + 4),
        (u /= l < 0.5 ? a + o : 2 - a - o),
        (s *= 60))
      : (u = l > 0 && l < 1 ? 0 : s),
    new ht(s, u, l, e.opacity)
  )
}
function Ps(e, n, r, i) {
  return arguments.length === 1 ? gi(e) : new ht(e, n, r, i ?? 1)
}
function ht(e, n, r, i) {
  ;((this.h = +e), (this.s = +n), (this.l = +r), (this.opacity = +i))
}
En(
  ht,
  Ps,
  pi(me, {
    brighter(e) {
      return (
        (e = e == null ? Ne : Math.pow(Ne, e)),
        new ht(this.h, this.s, this.l * e, this.opacity)
      )
    },
    darker(e) {
      return (
        (e = e == null ? ce : Math.pow(ce, e)),
        new ht(this.h, this.s, this.l * e, this.opacity)
      )
    },
    rgb() {
      var e = (this.h % 360) + (this.h < 0) * 360,
        n = isNaN(e) || isNaN(this.s) ? 0 : this.s,
        r = this.l,
        i = r + (r < 0.5 ? r : 1 - r) * n,
        o = 2 * r - i
      return new tt(
        tn(e >= 240 ? e - 240 : e + 120, o, i),
        tn(e, o, i),
        tn(e < 120 ? e + 240 : e - 120, o, i),
        this.opacity
      )
    },
    clamp() {
      return new ht(ir(this.h), ke(this.s), ke(this.l), $e(this.opacity))
    },
    displayable() {
      return (
        ((0 <= this.s && this.s <= 1) || isNaN(this.s)) &&
        0 <= this.l &&
        this.l <= 1 &&
        0 <= this.opacity &&
        this.opacity <= 1
      )
    },
    formatHsl() {
      const e = $e(this.opacity)
      return `${e === 1 ? 'hsl(' : 'hsla('}${ir(this.h)}, ${ke(this.s) * 100}%, ${ke(this.l) * 100}%${e === 1 ? ')' : `, ${e})`}`
    },
  })
)
function ir(e) {
  return ((e = (e || 0) % 360), e < 0 ? e + 360 : e)
}
function ke(e) {
  return Math.max(0, Math.min(1, e || 0))
}
function tn(e, n, r) {
  return (
    (e < 60 ? n + ((r - n) * e) / 60 : e < 180 ? r : e < 240 ? n + ((r - n) * (240 - e)) / 60 : n) *
    255
  )
}
const yi = e => () => e
function Os(e, n) {
  return function (r) {
    return e + r * n
  }
}
function Es(e, n, r) {
  return (
    (e = Math.pow(e, r)),
    (n = Math.pow(n, r) - e),
    (r = 1 / r),
    function (i) {
      return Math.pow(e + i * n, r)
    }
  )
}
function zs(e) {
  return (e = +e) == 1
    ? _i
    : function (n, r) {
        return r - n ? Es(n, r, e) : yi(isNaN(n) ? r : n)
      }
}
function _i(e, n) {
  var r = n - e
  return r ? Os(e, r) : yi(isNaN(e) ? n : e)
}
const or = (function e(n) {
  var r = zs(n)
  function i(o, a) {
    var s = r((o = dn(o)).r, (a = dn(a)).r),
      u = r(o.g, a.g),
      l = r(o.b, a.b),
      f = _i(o.opacity, a.opacity)
    return function (h) {
      return ((o.r = s(h)), (o.g = u(h)), (o.b = l(h)), (o.opacity = f(h)), o + '')
    }
  }
  return ((i.gamma = e), i)
})(1)
function Nt(e, n) {
  return (
    (e = +e),
    (n = +n),
    function (r) {
      return e * (1 - r) + n * r
    }
  )
}
var pn = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
  en = new RegExp(pn.source, 'g')
function Rs(e) {
  return function () {
    return e
  }
}
function Ns(e) {
  return function (n) {
    return e(n) + ''
  }
}
function $s(e, n) {
  var r = (pn.lastIndex = en.lastIndex = 0),
    i,
    o,
    a,
    s = -1,
    u = [],
    l = []
  for (e = e + '', n = n + ''; (i = pn.exec(e)) && (o = en.exec(n)); )
    ((a = o.index) > r && ((a = n.slice(r, a)), u[s] ? (u[s] += a) : (u[++s] = a)),
      (i = i[0]) === (o = o[0])
        ? u[s]
          ? (u[s] += o)
          : (u[++s] = o)
        : ((u[++s] = null), l.push({ i: s, x: Nt(i, o) })),
      (r = en.lastIndex))
  return (
    r < n.length && ((a = n.slice(r)), u[s] ? (u[s] += a) : (u[++s] = a)),
    u.length < 2
      ? l[0]
        ? Ns(l[0].x)
        : Rs(n)
      : ((n = l.length),
        function (f) {
          for (var h = 0, c; h < n; ++h) u[(c = l[h]).i] = c.x(f)
          return u.join('')
        })
  )
}
var ar = 180 / Math.PI,
  gn = { translateX: 0, translateY: 0, rotate: 0, skewX: 0, scaleX: 1, scaleY: 1 }
function vi(e, n, r, i, o, a) {
  var s, u, l
  return (
    (s = Math.sqrt(e * e + n * n)) && ((e /= s), (n /= s)),
    (l = e * r + n * i) && ((r -= e * l), (i -= n * l)),
    (u = Math.sqrt(r * r + i * i)) && ((r /= u), (i /= u), (l /= u)),
    e * i < n * r && ((e = -e), (n = -n), (l = -l), (s = -s)),
    {
      translateX: o,
      translateY: a,
      rotate: Math.atan2(n, e) * ar,
      skewX: Math.atan(l) * ar,
      scaleX: s,
      scaleY: u,
    }
  )
}
var Ae
function Is(e) {
  const n = new (typeof DOMMatrix == 'function' ? DOMMatrix : WebKitCSSMatrix)(e + '')
  return n.isIdentity ? gn : vi(n.a, n.b, n.c, n.d, n.e, n.f)
}
function Ds(e) {
  return e == null ||
    (Ae || (Ae = document.createElementNS('http://www.w3.org/2000/svg', 'g')),
    Ae.setAttribute('transform', e),
    !(e = Ae.transform.baseVal.consolidate()))
    ? gn
    : ((e = e.matrix), vi(e.a, e.b, e.c, e.d, e.e, e.f))
}
function mi(e, n, r, i) {
  function o(f) {
    return f.length ? f.pop() + ' ' : ''
  }
  function a(f, h, c, d, p, y) {
    if (f !== c || h !== d) {
      var m = p.push('translate(', null, n, null, r)
      y.push({ i: m - 4, x: Nt(f, c) }, { i: m - 2, x: Nt(h, d) })
    } else (c || d) && p.push('translate(' + c + n + d + r)
  }
  function s(f, h, c, d) {
    f !== h
      ? (f - h > 180 ? (h += 360) : h - f > 180 && (f += 360),
        d.push({ i: c.push(o(c) + 'rotate(', null, i) - 2, x: Nt(f, h) }))
      : h && c.push(o(c) + 'rotate(' + h + i)
  }
  function u(f, h, c, d) {
    f !== h
      ? d.push({ i: c.push(o(c) + 'skewX(', null, i) - 2, x: Nt(f, h) })
      : h && c.push(o(c) + 'skewX(' + h + i)
  }
  function l(f, h, c, d, p, y) {
    if (f !== c || h !== d) {
      var m = p.push(o(p) + 'scale(', null, ',', null, ')')
      y.push({ i: m - 4, x: Nt(f, c) }, { i: m - 2, x: Nt(h, d) })
    } else (c !== 1 || d !== 1) && p.push(o(p) + 'scale(' + c + ',' + d + ')')
  }
  return function (f, h) {
    var c = [],
      d = []
    return (
      (f = e(f)),
      (h = e(h)),
      a(f.translateX, f.translateY, h.translateX, h.translateY, c, d),
      s(f.rotate, h.rotate, c, d),
      u(f.skewX, h.skewX, c, d),
      l(f.scaleX, f.scaleY, h.scaleX, h.scaleY, c, d),
      (f = h = null),
      function (p) {
        for (var y = -1, m = d.length, _; ++y < m; ) c[(_ = d[y]).i] = _.x(p)
        return c.join('')
      }
    )
  }
}
var js = mi(Is, 'px, ', 'px)', 'deg)'),
  Fs = mi(Ds, ', ', ')', ')'),
  Us = 1e-12
function sr(e) {
  return ((e = Math.exp(e)) + 1 / e) / 2
}
function Ls(e) {
  return ((e = Math.exp(e)) - 1 / e) / 2
}
function Hs(e) {
  return ((e = Math.exp(2 * e)) - 1) / (e + 1)
}
const qs = (function e(n, r, i) {
  function o(a, s) {
    var u = a[0],
      l = a[1],
      f = a[2],
      h = s[0],
      c = s[1],
      d = s[2],
      p = h - u,
      y = c - l,
      m = p * p + y * y,
      _,
      g
    if (m < Us)
      ((g = Math.log(d / f) / n),
        (_ = function (S) {
          return [u + S * p, l + S * y, f * Math.exp(n * S * g)]
        }))
    else {
      var w = Math.sqrt(m),
        C = (d * d - f * f + i * m) / (2 * f * r * w),
        x = (d * d - f * f - i * m) / (2 * d * r * w),
        b = Math.log(Math.sqrt(C * C + 1) - C),
        A = Math.log(Math.sqrt(x * x + 1) - x)
      ;((g = (A - b) / n),
        (_ = function (S) {
          var M = S * g,
            R = sr(b),
            O = (f / (r * w)) * (R * Hs(n * M + b) - Ls(b))
          return [u + O * p, l + O * y, (f * R) / sr(n * M + b)]
        }))
    }
    return ((_.duration = (g * 1e3 * n) / Math.SQRT2), _)
  }
  return (
    (o.rho = function (a) {
      var s = Math.max(0.001, +a),
        u = s * s,
        l = u * u
      return e(s, u, l)
    }),
    o
  )
})(Math.SQRT2, 2, 4)
var Wt = 0,
  re = 0,
  Yt = 0,
  xi = 1e3,
  Ie,
  ie,
  De = 0,
  Ut = 0,
  Be = 0,
  pe = typeof performance == 'object' && performance.now ? performance : Date,
  bi =
    typeof window == 'object' && window.requestAnimationFrame
      ? window.requestAnimationFrame.bind(window)
      : function (e) {
          setTimeout(e, 17)
        }
function zn() {
  return Ut || (bi(Gs), (Ut = pe.now() + Be))
}
function Gs() {
  Ut = 0
}
function je() {
  this._call = this._time = this._next = null
}
je.prototype = Rn.prototype = {
  constructor: je,
  restart: function (e, n, r) {
    if (typeof e != 'function') throw new TypeError('callback is not a function')
    ;((r = (r == null ? zn() : +r) + (n == null ? 0 : +n)),
      !this._next && ie !== this && (ie ? (ie._next = this) : (Ie = this), (ie = this)),
      (this._call = e),
      (this._time = r),
      yn())
  },
  stop: function () {
    this._call && ((this._call = null), (this._time = 1 / 0), yn())
  },
}
function Rn(e, n, r) {
  var i = new je()
  return (i.restart(e, n, r), i)
}
function Vs() {
  ;(zn(), ++Wt)
  for (var e = Ie, n; e; ) ((n = Ut - e._time) >= 0 && e._call.call(void 0, n), (e = e._next))
  --Wt
}
function ur() {
  ;((Ut = (De = pe.now()) + Be), (Wt = re = 0))
  try {
    Vs()
  } finally {
    ;((Wt = 0), Ws(), (Ut = 0))
  }
}
function Bs() {
  var e = pe.now(),
    n = e - De
  n > xi && ((Be -= n), (De = e))
}
function Ws() {
  for (var e, n = Ie, r, i = 1 / 0; n; )
    n._call
      ? (i > n._time && (i = n._time), (e = n), (n = n._next))
      : ((r = n._next), (n._next = null), (n = e ? (e._next = r) : (Ie = r)))
  ;((ie = e), yn(i))
}
function yn(e) {
  if (!Wt) {
    re && (re = clearTimeout(re))
    var n = e - Ut
    n > 24
      ? (e < 1 / 0 && (re = setTimeout(ur, e - pe.now() - Be)), Yt && (Yt = clearInterval(Yt)))
      : (Yt || ((De = pe.now()), (Yt = setInterval(Bs, xi))), (Wt = 1), bi(ur))
  }
}
function lr(e, n, r) {
  var i = new je()
  return (
    (n = n == null ? 0 : +n),
    i.restart(
      o => {
        ;(i.stop(), e(o + n))
      },
      n,
      r
    ),
    i
  )
}
var Xs = ve('start', 'end', 'cancel', 'interrupt'),
  Ys = [],
  wi = 0,
  fr = 1,
  _n = 2,
  Pe = 3,
  cr = 4,
  vn = 5,
  Oe = 6
function We(e, n, r, i, o, a) {
  var s = e.__transition
  if (!s) e.__transition = {}
  else if (r in s) return
  Zs(e, r, {
    name: n,
    index: i,
    group: o,
    on: Xs,
    tween: Ys,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: wi,
  })
}
function Nn(e, n) {
  var r = pt(e, n)
  if (r.state > wi) throw new Error('too late; already scheduled')
  return r
}
function xt(e, n) {
  var r = pt(e, n)
  if (r.state > Pe) throw new Error('too late; already running')
  return r
}
function pt(e, n) {
  var r = e.__transition
  if (!r || !(r = r[n])) throw new Error('transition not found')
  return r
}
function Zs(e, n, r) {
  var i = e.__transition,
    o
  ;((i[n] = r), (r.timer = Rn(a, 0, r.time)))
  function a(f) {
    ;((r.state = fr), r.timer.restart(s, r.delay, r.time), r.delay <= f && s(f - r.delay))
  }
  function s(f) {
    var h, c, d, p
    if (r.state !== fr) return l()
    for (h in i)
      if (((p = i[h]), p.name === r.name)) {
        if (p.state === Pe) return lr(s)
        p.state === cr
          ? ((p.state = Oe),
            p.timer.stop(),
            p.on.call('interrupt', e, e.__data__, p.index, p.group),
            delete i[h])
          : +h < n &&
            ((p.state = Oe),
            p.timer.stop(),
            p.on.call('cancel', e, e.__data__, p.index, p.group),
            delete i[h])
      }
    if (
      (lr(function () {
        r.state === Pe && ((r.state = cr), r.timer.restart(u, r.delay, r.time), u(f))
      }),
      (r.state = _n),
      r.on.call('start', e, e.__data__, r.index, r.group),
      r.state === _n)
    ) {
      for (r.state = Pe, o = new Array((d = r.tween.length)), h = 0, c = -1; h < d; ++h)
        (p = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (o[++c] = p)
      o.length = c + 1
    }
  }
  function u(f) {
    for (
      var h =
          f < r.duration
            ? r.ease.call(null, f / r.duration)
            : (r.timer.restart(l), (r.state = vn), 1),
        c = -1,
        d = o.length;
      ++c < d;

    )
      o[c].call(e, h)
    r.state === vn && (r.on.call('end', e, e.__data__, r.index, r.group), l())
  }
  function l() {
    ;((r.state = Oe), r.timer.stop(), delete i[n])
    for (var f in i) return
    delete e.__transition
  }
}
function Ee(e, n) {
  var r = e.__transition,
    i,
    o,
    a = !0,
    s
  if (r) {
    n = n == null ? null : n + ''
    for (s in r) {
      if ((i = r[s]).name !== n) {
        a = !1
        continue
      }
      ;((o = i.state > _n && i.state < vn),
        (i.state = Oe),
        i.timer.stop(),
        i.on.call(o ? 'interrupt' : 'cancel', e, e.__data__, i.index, i.group),
        delete r[s])
    }
    a && delete e.__transition
  }
}
function Ks(e) {
  return this.each(function () {
    Ee(this, e)
  })
}
function Qs(e, n) {
  var r, i
  return function () {
    var o = xt(this, e),
      a = o.tween
    if (a !== r) {
      i = r = a
      for (var s = 0, u = i.length; s < u; ++s)
        if (i[s].name === n) {
          ;((i = i.slice()), i.splice(s, 1))
          break
        }
    }
    o.tween = i
  }
}
function Js(e, n, r) {
  var i, o
  if (typeof r != 'function') throw new Error()
  return function () {
    var a = xt(this, e),
      s = a.tween
    if (s !== i) {
      o = (i = s).slice()
      for (var u = { name: n, value: r }, l = 0, f = o.length; l < f; ++l)
        if (o[l].name === n) {
          o[l] = u
          break
        }
      l === f && o.push(u)
    }
    a.tween = o
  }
}
function tu(e, n) {
  var r = this._id
  if (((e += ''), arguments.length < 2)) {
    for (var i = pt(this.node(), r).tween, o = 0, a = i.length, s; o < a; ++o)
      if ((s = i[o]).name === e) return s.value
    return null
  }
  return this.each((n == null ? Qs : Js)(r, e, n))
}
function $n(e, n, r) {
  var i = e._id
  return (
    e.each(function () {
      var o = xt(this, i)
      ;(o.value || (o.value = {}))[n] = r.apply(this, arguments)
    }),
    function (o) {
      return pt(o, i).value[n]
    }
  )
}
function ki(e, n) {
  var r
  return (typeof n == 'number' ? Nt : n instanceof de ? or : (r = de(n)) ? ((n = r), or) : $s)(e, n)
}
function eu(e) {
  return function () {
    this.removeAttribute(e)
  }
}
function nu(e) {
  return function () {
    this.removeAttributeNS(e.space, e.local)
  }
}
function ru(e, n, r) {
  var i,
    o = r + '',
    a
  return function () {
    var s = this.getAttribute(e)
    return s === o ? null : s === i ? a : (a = n((i = s), r))
  }
}
function iu(e, n, r) {
  var i,
    o = r + '',
    a
  return function () {
    var s = this.getAttributeNS(e.space, e.local)
    return s === o ? null : s === i ? a : (a = n((i = s), r))
  }
}
function ou(e, n, r) {
  var i, o, a
  return function () {
    var s,
      u = r(this),
      l
    return u == null
      ? void this.removeAttribute(e)
      : ((s = this.getAttribute(e)),
        (l = u + ''),
        s === l ? null : s === i && l === o ? a : ((o = l), (a = n((i = s), u))))
  }
}
function au(e, n, r) {
  var i, o, a
  return function () {
    var s,
      u = r(this),
      l
    return u == null
      ? void this.removeAttributeNS(e.space, e.local)
      : ((s = this.getAttributeNS(e.space, e.local)),
        (l = u + ''),
        s === l ? null : s === i && l === o ? a : ((o = l), (a = n((i = s), u))))
  }
}
function su(e, n) {
  var r = Ve(e),
    i = r === 'transform' ? Fs : ki
  return this.attrTween(
    e,
    typeof n == 'function'
      ? (r.local ? au : ou)(r, i, $n(this, 'attr.' + e, n))
      : n == null
        ? (r.local ? nu : eu)(r)
        : (r.local ? iu : ru)(r, i, n)
  )
}
function uu(e, n) {
  return function (r) {
    this.setAttribute(e, n.call(this, r))
  }
}
function lu(e, n) {
  return function (r) {
    this.setAttributeNS(e.space, e.local, n.call(this, r))
  }
}
function fu(e, n) {
  var r, i
  function o() {
    var a = n.apply(this, arguments)
    return (a !== i && (r = (i = a) && lu(e, a)), r)
  }
  return ((o._value = n), o)
}
function cu(e, n) {
  var r, i
  function o() {
    var a = n.apply(this, arguments)
    return (a !== i && (r = (i = a) && uu(e, a)), r)
  }
  return ((o._value = n), o)
}
function hu(e, n) {
  var r = 'attr.' + e
  if (arguments.length < 2) return (r = this.tween(r)) && r._value
  if (n == null) return this.tween(r, null)
  if (typeof n != 'function') throw new Error()
  var i = Ve(e)
  return this.tween(r, (i.local ? fu : cu)(i, n))
}
function du(e, n) {
  return function () {
    Nn(this, e).delay = +n.apply(this, arguments)
  }
}
function pu(e, n) {
  return (
    (n = +n),
    function () {
      Nn(this, e).delay = n
    }
  )
}
function gu(e) {
  var n = this._id
  return arguments.length
    ? this.each((typeof e == 'function' ? du : pu)(n, e))
    : pt(this.node(), n).delay
}
function yu(e, n) {
  return function () {
    xt(this, e).duration = +n.apply(this, arguments)
  }
}
function _u(e, n) {
  return (
    (n = +n),
    function () {
      xt(this, e).duration = n
    }
  )
}
function vu(e) {
  var n = this._id
  return arguments.length
    ? this.each((typeof e == 'function' ? yu : _u)(n, e))
    : pt(this.node(), n).duration
}
function mu(e, n) {
  if (typeof n != 'function') throw new Error()
  return function () {
    xt(this, e).ease = n
  }
}
function xu(e) {
  var n = this._id
  return arguments.length ? this.each(mu(n, e)) : pt(this.node(), n).ease
}
function bu(e, n) {
  return function () {
    var r = n.apply(this, arguments)
    if (typeof r != 'function') throw new Error()
    xt(this, e).ease = r
  }
}
function wu(e) {
  if (typeof e != 'function') throw new Error()
  return this.each(bu(this._id, e))
}
function ku(e) {
  typeof e != 'function' && (e = ni(e))
  for (var n = this._groups, r = n.length, i = new Array(r), o = 0; o < r; ++o)
    for (var a = n[o], s = a.length, u = (i[o] = []), l, f = 0; f < s; ++f)
      (l = a[f]) && e.call(l, l.__data__, f, a) && u.push(l)
  return new Et(i, this._parents, this._name, this._id)
}
function Au(e) {
  if (e._id !== this._id) throw new Error()
  for (
    var n = this._groups,
      r = e._groups,
      i = n.length,
      o = r.length,
      a = Math.min(i, o),
      s = new Array(i),
      u = 0;
    u < a;
    ++u
  )
    for (var l = n[u], f = r[u], h = l.length, c = (s[u] = new Array(h)), d, p = 0; p < h; ++p)
      (d = l[p] || f[p]) && (c[p] = d)
  for (; u < i; ++u) s[u] = n[u]
  return new Et(s, this._parents, this._name, this._id)
}
function Cu(e) {
  return (e + '')
    .trim()
    .split(/^|\s+/)
    .every(function (n) {
      var r = n.indexOf('.')
      return (r >= 0 && (n = n.slice(0, r)), !n || n === 'start')
    })
}
function Su(e, n, r) {
  var i,
    o,
    a = Cu(n) ? Nn : xt
  return function () {
    var s = a(this, e),
      u = s.on
    ;(u !== i && (o = (i = u).copy()).on(n, r), (s.on = o))
  }
}
function Mu(e, n) {
  var r = this._id
  return arguments.length < 2 ? pt(this.node(), r).on.on(e) : this.each(Su(r, e, n))
}
function Tu(e) {
  return function () {
    var n = this.parentNode
    for (var r in this.__transition) if (+r !== e) return
    n && n.removeChild(this)
  }
}
function Pu() {
  return this.on('end.remove', Tu(this._id))
}
function Ou(e) {
  var n = this._name,
    r = this._id
  typeof e != 'function' && (e = Pn(e))
  for (var i = this._groups, o = i.length, a = new Array(o), s = 0; s < o; ++s)
    for (var u = i[s], l = u.length, f = (a[s] = new Array(l)), h, c, d = 0; d < l; ++d)
      (h = u[d]) &&
        (c = e.call(h, h.__data__, d, u)) &&
        ('__data__' in h && (c.__data__ = h.__data__), (f[d] = c), We(f[d], n, r, d, f, pt(h, r)))
  return new Et(a, this._parents, n, r)
}
function Eu(e) {
  var n = this._name,
    r = this._id
  typeof e != 'function' && (e = ei(e))
  for (var i = this._groups, o = i.length, a = [], s = [], u = 0; u < o; ++u)
    for (var l = i[u], f = l.length, h, c = 0; c < f; ++c)
      if ((h = l[c])) {
        for (var d = e.call(h, h.__data__, c, l), p, y = pt(h, r), m = 0, _ = d.length; m < _; ++m)
          (p = d[m]) && We(p, n, r, m, d, y)
        ;(a.push(d), s.push(h))
      }
  return new Et(a, s, n, r)
}
var zu = _e.prototype.constructor
function Ru() {
  return new zu(this._groups, this._parents)
}
function Nu(e, n) {
  var r, i, o
  return function () {
    var a = Bt(this, e),
      s = (this.style.removeProperty(e), Bt(this, e))
    return a === s ? null : a === r && s === i ? o : (o = n((r = a), (i = s)))
  }
}
function Ai(e) {
  return function () {
    this.style.removeProperty(e)
  }
}
function $u(e, n, r) {
  var i,
    o = r + '',
    a
  return function () {
    var s = Bt(this, e)
    return s === o ? null : s === i ? a : (a = n((i = s), r))
  }
}
function Iu(e, n, r) {
  var i, o, a
  return function () {
    var s = Bt(this, e),
      u = r(this),
      l = u + ''
    return (
      u == null && (l = u = (this.style.removeProperty(e), Bt(this, e))),
      s === l ? null : s === i && l === o ? a : ((o = l), (a = n((i = s), u)))
    )
  }
}
function Du(e, n) {
  var r,
    i,
    o,
    a = 'style.' + n,
    s = 'end.' + a,
    u
  return function () {
    var l = xt(this, e),
      f = l.on,
      h = l.value[a] == null ? u || (u = Ai(n)) : void 0
    ;((f !== r || o !== h) && (i = (r = f).copy()).on(s, (o = h)), (l.on = i))
  }
}
function ju(e, n, r) {
  var i = (e += '') == 'transform' ? js : ki
  return n == null
    ? this.styleTween(e, Nu(e, i)).on('end.style.' + e, Ai(e))
    : typeof n == 'function'
      ? this.styleTween(e, Iu(e, i, $n(this, 'style.' + e, n))).each(Du(this._id, e))
      : this.styleTween(e, $u(e, i, n), r).on('end.style.' + e, null)
}
function Fu(e, n, r) {
  return function (i) {
    this.style.setProperty(e, n.call(this, i), r)
  }
}
function Uu(e, n, r) {
  var i, o
  function a() {
    var s = n.apply(this, arguments)
    return (s !== o && (i = (o = s) && Fu(e, s, r)), i)
  }
  return ((a._value = n), a)
}
function Lu(e, n, r) {
  var i = 'style.' + (e += '')
  if (arguments.length < 2) return (i = this.tween(i)) && i._value
  if (n == null) return this.tween(i, null)
  if (typeof n != 'function') throw new Error()
  return this.tween(i, Uu(e, n, r ?? ''))
}
function Hu(e) {
  return function () {
    this.textContent = e
  }
}
function qu(e) {
  return function () {
    var n = e(this)
    this.textContent = n ?? ''
  }
}
function Gu(e) {
  return this.tween(
    'text',
    typeof e == 'function' ? qu($n(this, 'text', e)) : Hu(e == null ? '' : e + '')
  )
}
function Vu(e) {
  return function (n) {
    this.textContent = e.call(this, n)
  }
}
function Bu(e) {
  var n, r
  function i() {
    var o = e.apply(this, arguments)
    return (o !== r && (n = (r = o) && Vu(o)), n)
  }
  return ((i._value = e), i)
}
function Wu(e) {
  var n = 'text'
  if (arguments.length < 1) return (n = this.tween(n)) && n._value
  if (e == null) return this.tween(n, null)
  if (typeof e != 'function') throw new Error()
  return this.tween(n, Bu(e))
}
function Xu() {
  for (
    var e = this._name, n = this._id, r = Ci(), i = this._groups, o = i.length, a = 0;
    a < o;
    ++a
  )
    for (var s = i[a], u = s.length, l, f = 0; f < u; ++f)
      if ((l = s[f])) {
        var h = pt(l, n)
        We(l, e, r, f, s, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease,
        })
      }
  return new Et(i, this._parents, e, r)
}
function Yu() {
  var e,
    n,
    r = this,
    i = r._id,
    o = r.size()
  return new Promise(function (a, s) {
    var u = { value: s },
      l = {
        value: function () {
          --o === 0 && a()
        },
      }
    ;(r.each(function () {
      var f = xt(this, i),
        h = f.on
      ;(h !== e &&
        ((n = (e = h).copy()), n._.cancel.push(u), n._.interrupt.push(u), n._.end.push(l)),
        (f.on = n))
    }),
      o === 0 && a())
  })
}
var Zu = 0
function Et(e, n, r, i) {
  ;((this._groups = e), (this._parents = n), (this._name = r), (this._id = i))
}
function Ci() {
  return ++Zu
}
var kt = _e.prototype
Et.prototype = {
  constructor: Et,
  select: Ou,
  selectAll: Eu,
  selectChild: kt.selectChild,
  selectChildren: kt.selectChildren,
  filter: ku,
  merge: Au,
  selection: Ru,
  transition: Xu,
  call: kt.call,
  nodes: kt.nodes,
  node: kt.node,
  size: kt.size,
  empty: kt.empty,
  each: kt.each,
  on: Mu,
  attr: su,
  attrTween: hu,
  style: ju,
  styleTween: Lu,
  text: Gu,
  textTween: Wu,
  remove: Pu,
  tween: tu,
  delay: gu,
  duration: vu,
  ease: xu,
  easeVarying: wu,
  end: Yu,
  [Symbol.iterator]: kt[Symbol.iterator],
}
function Ku(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2
}
var Qu = { time: null, delay: 0, duration: 250, ease: Ku }
function Ju(e, n) {
  for (var r; !(r = e.__transition) || !(r = r[n]); )
    if (!(e = e.parentNode)) throw new Error(`transition ${n} not found`)
  return r
}
function tl(e) {
  var n, r
  e instanceof Et
    ? ((n = e._id), (e = e._name))
    : ((n = Ci()), ((r = Qu).time = zn()), (e = e == null ? null : e + ''))
  for (var i = this._groups, o = i.length, a = 0; a < o; ++a)
    for (var s = i[a], u = s.length, l, f = 0; f < u; ++f)
      (l = s[f]) && We(l, e, n, f, s, r || Ju(l, n))
  return new Et(i, this._parents, e, n)
}
_e.prototype.interrupt = Ks
_e.prototype.transition = tl
const Ce = e => () => e
function el(e, { sourceEvent: n, target: r, transform: i, dispatch: o }) {
  Object.defineProperties(this, {
    type: { value: e, enumerable: !0, configurable: !0 },
    sourceEvent: { value: n, enumerable: !0, configurable: !0 },
    target: { value: r, enumerable: !0, configurable: !0 },
    transform: { value: i, enumerable: !0, configurable: !0 },
    _: { value: o },
  })
}
function Tt(e, n, r) {
  ;((this.k = e), (this.x = n), (this.y = r))
}
Tt.prototype = {
  constructor: Tt,
  scale: function (e) {
    return e === 1 ? this : new Tt(this.k * e, this.x, this.y)
  },
  translate: function (e, n) {
    return (e === 0) & (n === 0) ? this : new Tt(this.k, this.x + this.k * e, this.y + this.k * n)
  },
  apply: function (e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y]
  },
  applyX: function (e) {
    return e * this.k + this.x
  },
  applyY: function (e) {
    return e * this.k + this.y
  },
  invert: function (e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k]
  },
  invertX: function (e) {
    return (e - this.x) / this.k
  },
  invertY: function (e) {
    return (e - this.y) / this.k
  },
  rescaleX: function (e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e))
  },
  rescaleY: function (e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e))
  },
  toString: function () {
    return 'translate(' + this.x + ',' + this.y + ') scale(' + this.k + ')'
  },
}
var In = new Tt(1, 0, 0)
gt.prototype = Tt.prototype
function gt(e) {
  for (; !e.__zoom; ) if (!(e = e.parentNode)) return In
  return e.__zoom
}
function nn(e) {
  e.stopImmediatePropagation()
}
function Zt(e) {
  ;(e.preventDefault(), e.stopImmediatePropagation())
}
function nl(e) {
  return (!e.ctrlKey || e.type === 'wheel') && !e.button
}
function rl() {
  var e = this
  return e instanceof SVGElement
    ? ((e = e.ownerSVGElement || e),
      e.hasAttribute('viewBox')
        ? ((e = e.viewBox.baseVal),
          [
            [e.x, e.y],
            [e.x + e.width, e.y + e.height],
          ])
        : [
            [0, 0],
            [e.width.baseVal.value, e.height.baseVal.value],
          ])
    : [
        [0, 0],
        [e.clientWidth, e.clientHeight],
      ]
}
function hr() {
  return this.__zoom || In
}
function il(e) {
  return -e.deltaY * (e.deltaMode === 1 ? 0.05 : e.deltaMode ? 1 : 0.002) * (e.ctrlKey ? 10 : 1)
}
function ol() {
  return navigator.maxTouchPoints || 'ontouchstart' in this
}
function al(e, n, r) {
  var i = e.invertX(n[0][0]) - r[0][0],
    o = e.invertX(n[1][0]) - r[1][0],
    a = e.invertY(n[0][1]) - r[0][1],
    s = e.invertY(n[1][1]) - r[1][1]
  return e.translate(
    o > i ? (i + o) / 2 : Math.min(0, i) || Math.max(0, o),
    s > a ? (a + s) / 2 : Math.min(0, a) || Math.max(0, s)
  )
}
function sl() {
  var e = nl,
    n = rl,
    r = al,
    i = il,
    o = ol,
    a = [0, 1 / 0],
    s = [
      [-1 / 0, -1 / 0],
      [1 / 0, 1 / 0],
    ],
    u = 250,
    l = qs,
    f = ve('start', 'zoom', 'end'),
    h,
    c,
    d,
    p = 500,
    y = 150,
    m = 0,
    _ = 10
  function g(k) {
    k.property('__zoom', hr)
      .on('wheel.zoom', M, { passive: !1 })
      .on('mousedown.zoom', R)
      .on('dblclick.zoom', O)
      .filter(o)
      .on('touchstart.zoom', z)
      .on('touchmove.zoom', N)
      .on('touchend.zoom touchcancel.zoom', j)
      .style('-webkit-tap-highlight-color', 'rgba(0,0,0,0)')
  }
  ;((g.transform = function (k, E, T, $) {
    var D = k.selection ? k.selection() : k
    ;(D.property('__zoom', hr),
      k !== D
        ? b(k, E, T, $)
        : D.interrupt().each(function () {
            A(this, arguments)
              .event($)
              .start()
              .zoom(null, typeof E == 'function' ? E.apply(this, arguments) : E)
              .end()
          }))
  }),
    (g.scaleBy = function (k, E, T, $) {
      g.scaleTo(
        k,
        function () {
          var D = this.__zoom.k,
            F = typeof E == 'function' ? E.apply(this, arguments) : E
          return D * F
        },
        T,
        $
      )
    }),
    (g.scaleTo = function (k, E, T, $) {
      g.transform(
        k,
        function () {
          var D = n.apply(this, arguments),
            F = this.__zoom,
            U = T == null ? x(D) : typeof T == 'function' ? T.apply(this, arguments) : T,
            L = F.invert(U),
            H = typeof E == 'function' ? E.apply(this, arguments) : E
          return r(C(w(F, H), U, L), D, s)
        },
        T,
        $
      )
    }),
    (g.translateBy = function (k, E, T, $) {
      g.transform(
        k,
        function () {
          return r(
            this.__zoom.translate(
              typeof E == 'function' ? E.apply(this, arguments) : E,
              typeof T == 'function' ? T.apply(this, arguments) : T
            ),
            n.apply(this, arguments),
            s
          )
        },
        null,
        $
      )
    }),
    (g.translateTo = function (k, E, T, $, D) {
      g.transform(
        k,
        function () {
          var F = n.apply(this, arguments),
            U = this.__zoom,
            L = $ == null ? x(F) : typeof $ == 'function' ? $.apply(this, arguments) : $
          return r(
            In.translate(L[0], L[1])
              .scale(U.k)
              .translate(
                typeof E == 'function' ? -E.apply(this, arguments) : -E,
                typeof T == 'function' ? -T.apply(this, arguments) : -T
              ),
            F,
            s
          )
        },
        $,
        D
      )
    }))
  function w(k, E) {
    return ((E = Math.max(a[0], Math.min(a[1], E))), E === k.k ? k : new Tt(E, k.x, k.y))
  }
  function C(k, E, T) {
    var $ = E[0] - T[0] * k.k,
      D = E[1] - T[1] * k.k
    return $ === k.x && D === k.y ? k : new Tt(k.k, $, D)
  }
  function x(k) {
    return [(+k[0][0] + +k[1][0]) / 2, (+k[0][1] + +k[1][1]) / 2]
  }
  function b(k, E, T, $) {
    k.on('start.zoom', function () {
      A(this, arguments).event($).start()
    })
      .on('interrupt.zoom end.zoom', function () {
        A(this, arguments).event($).end()
      })
      .tween('zoom', function () {
        var D = this,
          F = arguments,
          U = A(D, F).event($),
          L = n.apply(D, F),
          H = T == null ? x(L) : typeof T == 'function' ? T.apply(D, F) : T,
          Y = Math.max(L[1][0] - L[0][0], L[1][1] - L[0][1]),
          X = D.__zoom,
          lt = typeof E == 'function' ? E.apply(D, F) : E,
          bt = l(X.invert(H).concat(Y / X.k), lt.invert(H).concat(Y / lt.k))
        return function (ft) {
          if (ft === 1) ft = lt
          else {
            var wt = bt(ft),
              Qe = Y / wt[2]
            ft = new Tt(Qe, H[0] - wt[0] * Qe, H[1] - wt[1] * Qe)
          }
          U.zoom(null, ft)
        }
      })
  }
  function A(k, E, T) {
    return (!T && k.__zooming) || new S(k, E)
  }
  function S(k, E) {
    ;((this.that = k),
      (this.args = E),
      (this.active = 0),
      (this.sourceEvent = null),
      (this.extent = n.apply(k, E)),
      (this.taps = 0))
  }
  S.prototype = {
    event: function (k) {
      return (k && (this.sourceEvent = k), this)
    },
    start: function () {
      return (++this.active === 1 && ((this.that.__zooming = this), this.emit('start')), this)
    },
    zoom: function (k, E) {
      return (
        this.mouse && k !== 'mouse' && (this.mouse[1] = E.invert(this.mouse[0])),
        this.touch0 && k !== 'touch' && (this.touch0[1] = E.invert(this.touch0[0])),
        this.touch1 && k !== 'touch' && (this.touch1[1] = E.invert(this.touch1[0])),
        (this.that.__zoom = E),
        this.emit('zoom'),
        this
      )
    },
    end: function () {
      return (--this.active === 0 && (delete this.that.__zooming, this.emit('end')), this)
    },
    emit: function (k) {
      var E = st(this.that).datum()
      f.call(
        k,
        this.that,
        new el(k, {
          sourceEvent: this.sourceEvent,
          target: g,
          type: k,
          transform: this.that.__zoom,
          dispatch: f,
        }),
        E
      )
    },
  }
  function M(k, ...E) {
    if (!e.apply(this, arguments)) return
    var T = A(this, E).event(k),
      $ = this.__zoom,
      D = Math.max(a[0], Math.min(a[1], $.k * Math.pow(2, i.apply(this, arguments)))),
      F = yt(k)
    if (T.wheel)
      ((T.mouse[0][0] !== F[0] || T.mouse[0][1] !== F[1]) &&
        (T.mouse[1] = $.invert((T.mouse[0] = F))),
        clearTimeout(T.wheel))
    else {
      if ($.k === D) return
      ;((T.mouse = [F, $.invert(F)]), Ee(this), T.start())
    }
    ;(Zt(k),
      (T.wheel = setTimeout(U, y)),
      T.zoom('mouse', r(C(w($, D), T.mouse[0], T.mouse[1]), T.extent, s)))
    function U() {
      ;((T.wheel = null), T.end())
    }
  }
  function R(k, ...E) {
    if (d || !e.apply(this, arguments)) return
    var T = k.currentTarget,
      $ = A(this, E, !0).event(k),
      D = st(k.view).on('mousemove.zoom', H, !0).on('mouseup.zoom', Y, !0),
      F = yt(k, T),
      U = k.clientX,
      L = k.clientY
    ;(hi(k.view), nn(k), ($.mouse = [F, this.__zoom.invert(F)]), Ee(this), $.start())
    function H(X) {
      if ((Zt(X), !$.moved)) {
        var lt = X.clientX - U,
          bt = X.clientY - L
        $.moved = lt * lt + bt * bt > m
      }
      $.event(X).zoom(
        'mouse',
        r(C($.that.__zoom, ($.mouse[0] = yt(X, T)), $.mouse[1]), $.extent, s)
      )
    }
    function Y(X) {
      ;(D.on('mousemove.zoom mouseup.zoom', null), di(X.view, $.moved), Zt(X), $.event(X).end())
    }
  }
  function O(k, ...E) {
    if (e.apply(this, arguments)) {
      var T = this.__zoom,
        $ = yt(k.changedTouches ? k.changedTouches[0] : k, this),
        D = T.invert($),
        F = T.k * (k.shiftKey ? 0.5 : 2),
        U = r(C(w(T, F), $, D), n.apply(this, E), s)
      ;(Zt(k),
        u > 0
          ? st(this).transition().duration(u).call(b, U, $, k)
          : st(this).call(g.transform, U, $, k))
    }
  }
  function z(k, ...E) {
    if (e.apply(this, arguments)) {
      var T = k.touches,
        $ = T.length,
        D = A(this, E, k.changedTouches.length === $).event(k),
        F,
        U,
        L,
        H
      for (nn(k), U = 0; U < $; ++U)
        ((L = T[U]),
          (H = yt(L, this)),
          (H = [H, this.__zoom.invert(H), L.identifier]),
          D.touch0
            ? !D.touch1 && D.touch0[2] !== H[2] && ((D.touch1 = H), (D.taps = 0))
            : ((D.touch0 = H), (F = !0), (D.taps = 1 + !!h)))
      ;(h && (h = clearTimeout(h)),
        F &&
          (D.taps < 2 &&
            ((c = H[0]),
            (h = setTimeout(function () {
              h = null
            }, p))),
          Ee(this),
          D.start()))
    }
  }
  function N(k, ...E) {
    if (this.__zooming) {
      var T = A(this, E).event(k),
        $ = k.changedTouches,
        D = $.length,
        F,
        U,
        L,
        H
      for (Zt(k), F = 0; F < D; ++F)
        ((U = $[F]),
          (L = yt(U, this)),
          T.touch0 && T.touch0[2] === U.identifier
            ? (T.touch0[0] = L)
            : T.touch1 && T.touch1[2] === U.identifier && (T.touch1[0] = L))
      if (((U = T.that.__zoom), T.touch1)) {
        var Y = T.touch0[0],
          X = T.touch0[1],
          lt = T.touch1[0],
          bt = T.touch1[1],
          ft = (ft = lt[0] - Y[0]) * ft + (ft = lt[1] - Y[1]) * ft,
          wt = (wt = bt[0] - X[0]) * wt + (wt = bt[1] - X[1]) * wt
        ;((U = w(U, Math.sqrt(ft / wt))),
          (L = [(Y[0] + lt[0]) / 2, (Y[1] + lt[1]) / 2]),
          (H = [(X[0] + bt[0]) / 2, (X[1] + bt[1]) / 2]))
      } else if (T.touch0) ((L = T.touch0[0]), (H = T.touch0[1]))
      else return
      T.zoom('touch', r(C(U, L, H), T.extent, s))
    }
  }
  function j(k, ...E) {
    if (this.__zooming) {
      var T = A(this, E).event(k),
        $ = k.changedTouches,
        D = $.length,
        F,
        U
      for (
        nn(k),
          d && clearTimeout(d),
          d = setTimeout(function () {
            d = null
          }, p),
          F = 0;
        F < D;
        ++F
      )
        ((U = $[F]),
          T.touch0 && T.touch0[2] === U.identifier
            ? delete T.touch0
            : T.touch1 && T.touch1[2] === U.identifier && delete T.touch1)
      if ((T.touch1 && !T.touch0 && ((T.touch0 = T.touch1), delete T.touch1), T.touch0))
        T.touch0[1] = this.__zoom.invert(T.touch0[0])
      else if (
        (T.end(), T.taps === 2 && ((U = yt(U, this)), Math.hypot(c[0] - U[0], c[1] - U[1]) < _))
      ) {
        var L = st(this).on('dblclick.zoom')
        L && L.apply(this, arguments)
      }
    }
  }
  return (
    (g.wheelDelta = function (k) {
      return arguments.length ? ((i = typeof k == 'function' ? k : Ce(+k)), g) : i
    }),
    (g.filter = function (k) {
      return arguments.length ? ((e = typeof k == 'function' ? k : Ce(!!k)), g) : e
    }),
    (g.touchable = function (k) {
      return arguments.length ? ((o = typeof k == 'function' ? k : Ce(!!k)), g) : o
    }),
    (g.extent = function (k) {
      return arguments.length
        ? ((n =
            typeof k == 'function'
              ? k
              : Ce([
                  [+k[0][0], +k[0][1]],
                  [+k[1][0], +k[1][1]],
                ])),
          g)
        : n
    }),
    (g.scaleExtent = function (k) {
      return arguments.length ? ((a[0] = +k[0]), (a[1] = +k[1]), g) : [a[0], a[1]]
    }),
    (g.translateExtent = function (k) {
      return arguments.length
        ? ((s[0][0] = +k[0][0]),
          (s[1][0] = +k[1][0]),
          (s[0][1] = +k[0][1]),
          (s[1][1] = +k[1][1]),
          g)
        : [
            [s[0][0], s[0][1]],
            [s[1][0], s[1][1]],
          ]
    }),
    (g.constrain = function (k) {
      return arguments.length ? ((r = k), g) : r
    }),
    (g.duration = function (k) {
      return arguments.length ? ((u = +k), g) : u
    }),
    (g.interpolate = function (k) {
      return arguments.length ? ((l = k), g) : l
    }),
    (g.on = function () {
      var k = f.on.apply(f, arguments)
      return k === f ? g : k
    }),
    (g.clickDistance = function (k) {
      return arguments.length ? ((m = (k = +k) * k), g) : Math.sqrt(m)
    }),
    (g.tapDistance = function (k) {
      return arguments.length ? ((_ = +k), g) : _
    }),
    g
  )
}
class dr extends Map {
  constructor(n, r = fl) {
    if (
      (super(),
      Object.defineProperties(this, { _intern: { value: new Map() }, _key: { value: r } }),
      n != null)
    )
      for (const [i, o] of n) this.set(i, o)
  }
  get(n) {
    return super.get(pr(this, n))
  }
  has(n) {
    return super.has(pr(this, n))
  }
  set(n, r) {
    return super.set(ul(this, n), r)
  }
  delete(n) {
    return super.delete(ll(this, n))
  }
}
function pr({ _intern: e, _key: n }, r) {
  const i = n(r)
  return e.has(i) ? e.get(i) : r
}
function ul({ _intern: e, _key: n }, r) {
  const i = n(r)
  return e.has(i) ? e.get(i) : (e.set(i, r), r)
}
function ll({ _intern: e, _key: n }, r) {
  const i = n(r)
  return (e.has(i) && ((r = e.get(i)), e.delete(i)), r)
}
function fl(e) {
  return e !== null && typeof e == 'object' ? e.valueOf() : e
}
function gr(e, n) {
  let r
  if (n === void 0) for (const i of e) i != null && (r < i || (r === void 0 && i >= i)) && (r = i)
  else {
    let i = -1
    for (let o of e) (o = n(o, ++i, e)) != null && (r < o || (r === void 0 && o >= o)) && (r = o)
  }
  return r
}
function yr(e, n) {
  let r
  if (n === void 0) for (const i of e) i != null && (r > i || (r === void 0 && i >= i)) && (r = i)
  else {
    let i = -1
    for (let o of e) (o = n(o, ++i, e)) != null && (r > o || (r === void 0 && o >= o)) && (r = o)
  }
  return r
}
function cl(e, n) {
  let r = 0
  if (n === void 0) for (let i of e) (i = +i) && (r += i)
  else {
    let i = -1
    for (let o of e) (o = +n(o, ++i, e)) && (r += o)
  }
  return r
}
var hl = typeof global == 'object' && global && global.Object === Object && global
const dl = hl
var pl = typeof self == 'object' && self && self.Object === Object && self,
  gl = dl || pl || Function('return this')()
const Si = gl
var yl = Si.Symbol
const Fe = yl
var Mi = Object.prototype,
  _l = Mi.hasOwnProperty,
  vl = Mi.toString,
  Kt = Fe ? Fe.toStringTag : void 0
function ml(e) {
  var n = _l.call(e, Kt),
    r = e[Kt]
  try {
    e[Kt] = void 0
    var i = !0
  } catch {}
  var o = vl.call(e)
  return (i && (n ? (e[Kt] = r) : delete e[Kt]), o)
}
var xl = Object.prototype,
  bl = xl.toString
function wl(e) {
  return bl.call(e)
}
var kl = '[object Null]',
  Al = '[object Undefined]',
  _r = Fe ? Fe.toStringTag : void 0
function Cl(e) {
  return e == null ? (e === void 0 ? Al : kl) : _r && _r in Object(e) ? ml(e) : wl(e)
}
function Sl(e) {
  return e != null && typeof e == 'object'
}
var Ml = '[object Symbol]'
function Tl(e) {
  return typeof e == 'symbol' || (Sl(e) && Cl(e) == Ml)
}
var Pl = /\s/
function Ol(e) {
  for (var n = e.length; n-- && Pl.test(e.charAt(n)); );
  return n
}
var El = /^\s+/
function zl(e) {
  return e && e.slice(0, Ol(e) + 1).replace(El, '')
}
function Ue(e) {
  var n = typeof e
  return e != null && (n == 'object' || n == 'function')
}
var vr = 0 / 0,
  Rl = /^[-+]0x[0-9a-f]+$/i,
  Nl = /^0b[01]+$/i,
  $l = /^0o[0-7]+$/i,
  Il = parseInt
function mr(e) {
  if (typeof e == 'number') return e
  if (Tl(e)) return vr
  if (Ue(e)) {
    var n = typeof e.valueOf == 'function' ? e.valueOf() : e
    e = Ue(n) ? n + '' : n
  }
  if (typeof e != 'string') return e === 0 ? e : +e
  e = zl(e)
  var r = Nl.test(e)
  return r || $l.test(e) ? Il(e.slice(2), r ? 2 : 8) : Rl.test(e) ? vr : +e
}
var Dl = function () {
  return Si.Date.now()
}
const rn = Dl
var jl = 'Expected a function',
  Fl = Math.max,
  Ul = Math.min
function Ti(e, n, r) {
  var i,
    o,
    a,
    s,
    u,
    l,
    f = 0,
    h = !1,
    c = !1,
    d = !0
  if (typeof e != 'function') throw new TypeError(jl)
  ;((n = mr(n) || 0),
    Ue(r) &&
      ((h = !!r.leading),
      (c = 'maxWait' in r),
      (a = c ? Fl(mr(r.maxWait) || 0, n) : a),
      (d = 'trailing' in r ? !!r.trailing : d)))
  function p(A) {
    var S = i,
      M = o
    return ((i = o = void 0), (f = A), (s = e.apply(M, S)), s)
  }
  function y(A) {
    return ((f = A), (u = setTimeout(g, n)), h ? p(A) : s)
  }
  function m(A) {
    var S = A - l,
      M = A - f,
      R = n - S
    return c ? Ul(R, a - M) : R
  }
  function _(A) {
    var S = A - l,
      M = A - f
    return l === void 0 || S >= n || S < 0 || (c && M >= a)
  }
  function g() {
    var A = rn()
    if (_(A)) return w(A)
    u = setTimeout(g, m(A))
  }
  function w(A) {
    return ((u = void 0), d && i ? p(A) : ((i = o = void 0), s))
  }
  function C() {
    ;(u !== void 0 && clearTimeout(u), (f = 0), (i = l = o = u = void 0))
  }
  function x() {
    return u === void 0 ? s : w(rn())
  }
  function b() {
    var A = rn(),
      S = _(A)
    if (((i = arguments), (o = this), (l = A), S)) {
      if (u === void 0) return y(l)
      if (c) return (clearTimeout(u), (u = setTimeout(g, n)), p(l))
    }
    return (u === void 0 && (u = setTimeout(g, n)), s)
  }
  return ((b.cancel = C), (b.flush = x), b)
}
var Ll = 'Expected a function'
function Hl(e, n, r) {
  var i = !0,
    o = !0
  if (typeof e != 'function') throw new TypeError(Ll)
  return (
    Ue(r) && ((i = 'leading' in r ? !!r.leading : i), (o = 'trailing' in r ? !!r.trailing : o)),
    Ti(e, n, { leading: i, maxWait: n, trailing: o })
  )
}
var Ft = Object.freeze({
    Linear: Object.freeze({
      None: function (e) {
        return e
      },
      In: function (e) {
        return e
      },
      Out: function (e) {
        return e
      },
      InOut: function (e) {
        return e
      },
    }),
    Quadratic: Object.freeze({
      In: function (e) {
        return e * e
      },
      Out: function (e) {
        return e * (2 - e)
      },
      InOut: function (e) {
        return (e *= 2) < 1 ? 0.5 * e * e : -0.5 * (--e * (e - 2) - 1)
      },
    }),
    Cubic: Object.freeze({
      In: function (e) {
        return e * e * e
      },
      Out: function (e) {
        return --e * e * e + 1
      },
      InOut: function (e) {
        return (e *= 2) < 1 ? 0.5 * e * e * e : 0.5 * ((e -= 2) * e * e + 2)
      },
    }),
    Quartic: Object.freeze({
      In: function (e) {
        return e * e * e * e
      },
      Out: function (e) {
        return 1 - --e * e * e * e
      },
      InOut: function (e) {
        return (e *= 2) < 1 ? 0.5 * e * e * e * e : -0.5 * ((e -= 2) * e * e * e - 2)
      },
    }),
    Quintic: Object.freeze({
      In: function (e) {
        return e * e * e * e * e
      },
      Out: function (e) {
        return --e * e * e * e * e + 1
      },
      InOut: function (e) {
        return (e *= 2) < 1 ? 0.5 * e * e * e * e * e : 0.5 * ((e -= 2) * e * e * e * e + 2)
      },
    }),
    Sinusoidal: Object.freeze({
      In: function (e) {
        return 1 - Math.sin(((1 - e) * Math.PI) / 2)
      },
      Out: function (e) {
        return Math.sin((e * Math.PI) / 2)
      },
      InOut: function (e) {
        return 0.5 * (1 - Math.sin(Math.PI * (0.5 - e)))
      },
    }),
    Exponential: Object.freeze({
      In: function (e) {
        return e === 0 ? 0 : Math.pow(1024, e - 1)
      },
      Out: function (e) {
        return e === 1 ? 1 : 1 - Math.pow(2, -10 * e)
      },
      InOut: function (e) {
        return e === 0
          ? 0
          : e === 1
            ? 1
            : (e *= 2) < 1
              ? 0.5 * Math.pow(1024, e - 1)
              : 0.5 * (-Math.pow(2, -10 * (e - 1)) + 2)
      },
    }),
    Circular: Object.freeze({
      In: function (e) {
        return 1 - Math.sqrt(1 - e * e)
      },
      Out: function (e) {
        return Math.sqrt(1 - --e * e)
      },
      InOut: function (e) {
        return (e *= 2) < 1
          ? -0.5 * (Math.sqrt(1 - e * e) - 1)
          : 0.5 * (Math.sqrt(1 - (e -= 2) * e) + 1)
      },
    }),
    Elastic: Object.freeze({
      In: function (e) {
        return e === 0
          ? 0
          : e === 1
            ? 1
            : -Math.pow(2, 10 * (e - 1)) * Math.sin((e - 1.1) * 5 * Math.PI)
      },
      Out: function (e) {
        return e === 0
          ? 0
          : e === 1
            ? 1
            : Math.pow(2, -10 * e) * Math.sin((e - 0.1) * 5 * Math.PI) + 1
      },
      InOut: function (e) {
        return e === 0
          ? 0
          : e === 1
            ? 1
            : ((e *= 2),
              e < 1
                ? -0.5 * Math.pow(2, 10 * (e - 1)) * Math.sin((e - 1.1) * 5 * Math.PI)
                : 0.5 * Math.pow(2, -10 * (e - 1)) * Math.sin((e - 1.1) * 5 * Math.PI) + 1)
      },
    }),
    Back: Object.freeze({
      In: function (e) {
        var n = 1.70158
        return e === 1 ? 1 : e * e * ((n + 1) * e - n)
      },
      Out: function (e) {
        var n = 1.70158
        return e === 0 ? 0 : --e * e * ((n + 1) * e + n) + 1
      },
      InOut: function (e) {
        var n = 2.5949095
        return (e *= 2) < 1
          ? 0.5 * (e * e * ((n + 1) * e - n))
          : 0.5 * ((e -= 2) * e * ((n + 1) * e + n) + 2)
      },
    }),
    Bounce: Object.freeze({
      In: function (e) {
        return 1 - Ft.Bounce.Out(1 - e)
      },
      Out: function (e) {
        return e < 1 / 2.75
          ? 7.5625 * e * e
          : e < 2 / 2.75
            ? 7.5625 * (e -= 1.5 / 2.75) * e + 0.75
            : e < 2.5 / 2.75
              ? 7.5625 * (e -= 2.25 / 2.75) * e + 0.9375
              : 7.5625 * (e -= 2.625 / 2.75) * e + 0.984375
      },
      InOut: function (e) {
        return e < 0.5 ? Ft.Bounce.In(e * 2) * 0.5 : Ft.Bounce.Out(e * 2 - 1) * 0.5 + 0.5
      },
    }),
    generatePow: function (e) {
      return (
        e === void 0 && (e = 4),
        (e = e < Number.EPSILON ? Number.EPSILON : e),
        (e = e > 1e4 ? 1e4 : e),
        {
          In: function (n) {
            return Math.pow(n, e)
          },
          Out: function (n) {
            return 1 - Math.pow(1 - n, e)
          },
          InOut: function (n) {
            return n < 0.5 ? Math.pow(n * 2, e) / 2 : (1 - Math.pow(2 - n * 2, e)) / 2 + 0.5
          },
        }
      )
    },
  }),
  oe = function () {
    return performance.now()
  },
  Pi = (function () {
    function e() {
      for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r]
      ;((this._tweens = {}), (this._tweensAddedDuringUpdate = {}), this.add.apply(this, n))
    }
    return (
      (e.prototype.getAll = function () {
        var n = this
        return Object.keys(this._tweens).map(function (r) {
          return n._tweens[r]
        })
      }),
      (e.prototype.removeAll = function () {
        this._tweens = {}
      }),
      (e.prototype.add = function () {
        for (var n, r = [], i = 0; i < arguments.length; i++) r[i] = arguments[i]
        for (var o = 0, a = r; o < a.length; o++) {
          var s = a[o]
          ;((n = s._group) === null || n === void 0 || n.remove(s),
            (s._group = this),
            (this._tweens[s.getId()] = s),
            (this._tweensAddedDuringUpdate[s.getId()] = s))
        }
      }),
      (e.prototype.remove = function () {
        for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r]
        for (var i = 0, o = n; i < o.length; i++) {
          var a = o[i]
          ;((a._group = void 0),
            delete this._tweens[a.getId()],
            delete this._tweensAddedDuringUpdate[a.getId()])
        }
      }),
      (e.prototype.allStopped = function () {
        return this.getAll().every(function (n) {
          return !n.isPlaying()
        })
      }),
      (e.prototype.update = function (n, r) {
        ;(n === void 0 && (n = oe()), r === void 0 && (r = !0))
        var i = Object.keys(this._tweens)
        if (i.length !== 0)
          for (; i.length > 0; ) {
            this._tweensAddedDuringUpdate = {}
            for (var o = 0; o < i.length; o++) {
              var a = this._tweens[i[o]],
                s = !r
              a && a.update(n, s) === !1 && !r && this.remove(a)
            }
            i = Object.keys(this._tweensAddedDuringUpdate)
          }
      }),
      e
    )
  })(),
  qt = {
    Linear: function (e, n) {
      var r = e.length - 1,
        i = r * n,
        o = Math.floor(i),
        a = qt.Utils.Linear
      return n < 0
        ? a(e[0], e[1], i)
        : n > 1
          ? a(e[r], e[r - 1], r - i)
          : a(e[o], e[o + 1 > r ? r : o + 1], i - o)
    },
    Bezier: function (e, n) {
      for (var r = 0, i = e.length - 1, o = Math.pow, a = qt.Utils.Bernstein, s = 0; s <= i; s++)
        r += o(1 - n, i - s) * o(n, s) * e[s] * a(i, s)
      return r
    },
    CatmullRom: function (e, n) {
      var r = e.length - 1,
        i = r * n,
        o = Math.floor(i),
        a = qt.Utils.CatmullRom
      return e[0] === e[r]
        ? (n < 0 && (o = Math.floor((i = r * (1 + n)))),
          a(e[(o - 1 + r) % r], e[o], e[(o + 1) % r], e[(o + 2) % r], i - o))
        : n < 0
          ? e[0] - (a(e[0], e[0], e[1], e[1], -i) - e[0])
          : n > 1
            ? e[r] - (a(e[r], e[r], e[r - 1], e[r - 1], i - r) - e[r])
            : a(e[o ? o - 1 : 0], e[o], e[r < o + 1 ? r : o + 1], e[r < o + 2 ? r : o + 2], i - o)
    },
    Utils: {
      Linear: function (e, n, r) {
        return (n - e) * r + e
      },
      Bernstein: function (e, n) {
        var r = qt.Utils.Factorial
        return r(e) / r(n) / r(e - n)
      },
      Factorial: (function () {
        var e = [1]
        return function (n) {
          var r = 1
          if (e[n]) return e[n]
          for (var i = n; i > 1; i--) r *= i
          return ((e[n] = r), r)
        }
      })(),
      CatmullRom: function (e, n, r, i, o) {
        var a = (r - e) * 0.5,
          s = (i - n) * 0.5,
          u = o * o,
          l = o * u
        return (2 * n - 2 * r + a + s) * l + (-3 * n + 3 * r - 2 * a - s) * u + a * o + n
      },
    },
  },
  ql = (function () {
    function e() {}
    return (
      (e.nextId = function () {
        return e._nextId++
      }),
      (e._nextId = 0),
      e
    )
  })(),
  mn = new Pi(),
  xr = (function () {
    function e(n, r) {
      ;((this._isPaused = !1),
        (this._pauseStart = 0),
        (this._valuesStart = {}),
        (this._valuesEnd = {}),
        (this._valuesStartRepeat = {}),
        (this._duration = 1e3),
        (this._isDynamic = !1),
        (this._initialRepeat = 0),
        (this._repeat = 0),
        (this._yoyo = !1),
        (this._isPlaying = !1),
        (this._reversed = !1),
        (this._delayTime = 0),
        (this._startTime = 0),
        (this._easingFunction = Ft.Linear.None),
        (this._interpolationFunction = qt.Linear),
        (this._chainedTweens = []),
        (this._onStartCallbackFired = !1),
        (this._onEveryStartCallbackFired = !1),
        (this._id = ql.nextId()),
        (this._isChainStopped = !1),
        (this._propertiesAreSetUp = !1),
        (this._goToEnd = !1),
        (this._object = n),
        typeof r == 'object'
          ? ((this._group = r), r.add(this))
          : r === !0 && ((this._group = mn), mn.add(this)))
    }
    return (
      (e.prototype.getId = function () {
        return this._id
      }),
      (e.prototype.isPlaying = function () {
        return this._isPlaying
      }),
      (e.prototype.isPaused = function () {
        return this._isPaused
      }),
      (e.prototype.getDuration = function () {
        return this._duration
      }),
      (e.prototype.to = function (n, r) {
        if ((r === void 0 && (r = 1e3), this._isPlaying))
          throw new Error(
            'Can not call Tween.to() while Tween is already started or paused. Stop the Tween first.'
          )
        return (
          (this._valuesEnd = n),
          (this._propertiesAreSetUp = !1),
          (this._duration = r < 0 ? 0 : r),
          this
        )
      }),
      (e.prototype.duration = function (n) {
        return (n === void 0 && (n = 1e3), (this._duration = n < 0 ? 0 : n), this)
      }),
      (e.prototype.dynamic = function (n) {
        return (n === void 0 && (n = !1), (this._isDynamic = n), this)
      }),
      (e.prototype.start = function (n, r) {
        if ((n === void 0 && (n = oe()), r === void 0 && (r = !1), this._isPlaying)) return this
        if (((this._repeat = this._initialRepeat), this._reversed)) {
          this._reversed = !1
          for (var i in this._valuesStartRepeat)
            (this._swapEndStartRepeatValues(i), (this._valuesStart[i] = this._valuesStartRepeat[i]))
        }
        if (
          ((this._isPlaying = !0),
          (this._isPaused = !1),
          (this._onStartCallbackFired = !1),
          (this._onEveryStartCallbackFired = !1),
          (this._isChainStopped = !1),
          (this._startTime = n),
          (this._startTime += this._delayTime),
          !this._propertiesAreSetUp || r)
        ) {
          if (((this._propertiesAreSetUp = !0), !this._isDynamic)) {
            var o = {}
            for (var a in this._valuesEnd) o[a] = this._valuesEnd[a]
            this._valuesEnd = o
          }
          this._setupProperties(
            this._object,
            this._valuesStart,
            this._valuesEnd,
            this._valuesStartRepeat,
            r
          )
        }
        return this
      }),
      (e.prototype.startFromCurrentValues = function (n) {
        return this.start(n, !0)
      }),
      (e.prototype._setupProperties = function (n, r, i, o, a) {
        for (var s in i) {
          var u = n[s],
            l = Array.isArray(u),
            f = l ? 'array' : typeof u,
            h = !l && Array.isArray(i[s])
          if (!(f === 'undefined' || f === 'function')) {
            if (h) {
              var c = i[s]
              if (c.length === 0) continue
              for (var d = [u], p = 0, y = c.length; p < y; p += 1) {
                var m = this._handleRelativeValue(u, c[p])
                if (isNaN(m)) {
                  ;((h = !1), console.warn('Found invalid interpolation list. Skipping.'))
                  break
                }
                d.push(m)
              }
              h && (i[s] = d)
            }
            if ((f === 'object' || l) && u && !h) {
              r[s] = l ? [] : {}
              var _ = u
              for (var g in _) r[s][g] = _[g]
              o[s] = l ? [] : {}
              var c = i[s]
              if (!this._isDynamic) {
                var w = {}
                for (var g in c) w[g] = c[g]
                i[s] = c = w
              }
              this._setupProperties(_, r[s], c, o[s], a)
            } else
              ((typeof r[s] > 'u' || a) && (r[s] = u),
                l || (r[s] *= 1),
                h ? (o[s] = i[s].slice().reverse()) : (o[s] = r[s] || 0))
          }
        }
      }),
      (e.prototype.stop = function () {
        return (
          this._isChainStopped || ((this._isChainStopped = !0), this.stopChainedTweens()),
          this._isPlaying
            ? ((this._isPlaying = !1),
              (this._isPaused = !1),
              this._onStopCallback && this._onStopCallback(this._object),
              this)
            : this
        )
      }),
      (e.prototype.end = function () {
        return ((this._goToEnd = !0), this.update(this._startTime + this._duration), this)
      }),
      (e.prototype.pause = function (n) {
        return (
          n === void 0 && (n = oe()),
          this._isPaused || !this._isPlaying
            ? this
            : ((this._isPaused = !0), (this._pauseStart = n), this)
        )
      }),
      (e.prototype.resume = function (n) {
        return (
          n === void 0 && (n = oe()),
          !this._isPaused || !this._isPlaying
            ? this
            : ((this._isPaused = !1),
              (this._startTime += n - this._pauseStart),
              (this._pauseStart = 0),
              this)
        )
      }),
      (e.prototype.stopChainedTweens = function () {
        for (var n = 0, r = this._chainedTweens.length; n < r; n++) this._chainedTweens[n].stop()
        return this
      }),
      (e.prototype.group = function (n) {
        return n
          ? (n.add(this), this)
          : (console.warn(
              'tween.group() without args has been removed, use group.add(tween) instead.'
            ),
            this)
      }),
      (e.prototype.remove = function () {
        var n
        return ((n = this._group) === null || n === void 0 || n.remove(this), this)
      }),
      (e.prototype.delay = function (n) {
        return (n === void 0 && (n = 0), (this._delayTime = n), this)
      }),
      (e.prototype.repeat = function (n) {
        return (n === void 0 && (n = 0), (this._initialRepeat = n), (this._repeat = n), this)
      }),
      (e.prototype.repeatDelay = function (n) {
        return ((this._repeatDelayTime = n), this)
      }),
      (e.prototype.yoyo = function (n) {
        return (n === void 0 && (n = !1), (this._yoyo = n), this)
      }),
      (e.prototype.easing = function (n) {
        return (n === void 0 && (n = Ft.Linear.None), (this._easingFunction = n), this)
      }),
      (e.prototype.interpolation = function (n) {
        return (n === void 0 && (n = qt.Linear), (this._interpolationFunction = n), this)
      }),
      (e.prototype.chain = function () {
        for (var n = [], r = 0; r < arguments.length; r++) n[r] = arguments[r]
        return ((this._chainedTweens = n), this)
      }),
      (e.prototype.onStart = function (n) {
        return ((this._onStartCallback = n), this)
      }),
      (e.prototype.onEveryStart = function (n) {
        return ((this._onEveryStartCallback = n), this)
      }),
      (e.prototype.onUpdate = function (n) {
        return ((this._onUpdateCallback = n), this)
      }),
      (e.prototype.onRepeat = function (n) {
        return ((this._onRepeatCallback = n), this)
      }),
      (e.prototype.onComplete = function (n) {
        return ((this._onCompleteCallback = n), this)
      }),
      (e.prototype.onStop = function (n) {
        return ((this._onStopCallback = n), this)
      }),
      (e.prototype.update = function (n, r) {
        var i = this,
          o
        if ((n === void 0 && (n = oe()), r === void 0 && (r = e.autoStartOnUpdate), this._isPaused))
          return !0
        var a
        if (!this._goToEnd && !this._isPlaying)
          if (r) this.start(n, !0)
          else return !1
        if (((this._goToEnd = !1), n < this._startTime)) return !0
        ;(this._onStartCallbackFired === !1 &&
          (this._onStartCallback && this._onStartCallback(this._object),
          (this._onStartCallbackFired = !0)),
          this._onEveryStartCallbackFired === !1 &&
            (this._onEveryStartCallback && this._onEveryStartCallback(this._object),
            (this._onEveryStartCallbackFired = !0)))
        var s = n - this._startTime,
          u =
            this._duration +
            ((o = this._repeatDelayTime) !== null && o !== void 0 ? o : this._delayTime),
          l = this._duration + this._repeat * u,
          f = function () {
            if (i._duration === 0 || s > l) return 1
            var m = Math.trunc(s / u),
              _ = s - m * u,
              g = Math.min(_ / i._duration, 1)
            return g === 0 && s === i._duration ? 1 : g
          },
          h = f(),
          c = this._easingFunction(h)
        if (
          (this._updateProperties(this._object, this._valuesStart, this._valuesEnd, c),
          this._onUpdateCallback && this._onUpdateCallback(this._object, h),
          this._duration === 0 || s >= this._duration)
        )
          if (this._repeat > 0) {
            var d = Math.min(Math.trunc((s - this._duration) / u) + 1, this._repeat)
            isFinite(this._repeat) && (this._repeat -= d)
            for (a in this._valuesStartRepeat)
              (!this._yoyo &&
                typeof this._valuesEnd[a] == 'string' &&
                (this._valuesStartRepeat[a] =
                  this._valuesStartRepeat[a] + parseFloat(this._valuesEnd[a])),
                this._yoyo && this._swapEndStartRepeatValues(a),
                (this._valuesStart[a] = this._valuesStartRepeat[a]))
            return (
              this._yoyo && (this._reversed = !this._reversed),
              (this._startTime += u * d),
              this._onRepeatCallback && this._onRepeatCallback(this._object),
              (this._onEveryStartCallbackFired = !1),
              !0
            )
          } else {
            this._onCompleteCallback && this._onCompleteCallback(this._object)
            for (var p = 0, y = this._chainedTweens.length; p < y; p++)
              this._chainedTweens[p].start(this._startTime + this._duration, !1)
            return ((this._isPlaying = !1), !1)
          }
        return !0
      }),
      (e.prototype._updateProperties = function (n, r, i, o) {
        for (var a in i)
          if (r[a] !== void 0) {
            var s = r[a] || 0,
              u = i[a],
              l = Array.isArray(n[a]),
              f = Array.isArray(u),
              h = !l && f
            h
              ? (n[a] = this._interpolationFunction(u, o))
              : typeof u == 'object' && u
                ? this._updateProperties(n[a], s, u, o)
                : ((u = this._handleRelativeValue(s, u)),
                  typeof u == 'number' && (n[a] = s + (u - s) * o))
          }
      }),
      (e.prototype._handleRelativeValue = function (n, r) {
        return typeof r != 'string'
          ? r
          : r.charAt(0) === '+' || r.charAt(0) === '-'
            ? n + parseFloat(r)
            : parseFloat(r)
      }),
      (e.prototype._swapEndStartRepeatValues = function (n) {
        var r = this._valuesStartRepeat[n],
          i = this._valuesEnd[n]
        ;(typeof i == 'string'
          ? (this._valuesStartRepeat[n] = this._valuesStartRepeat[n] + parseFloat(i))
          : (this._valuesStartRepeat[n] = this._valuesEnd[n]),
          (this._valuesEnd[n] = r))
      }),
      (e.autoStartOnUpdate = !1),
      e
    )
  })(),
  mt = mn
mt.getAll.bind(mt)
mt.removeAll.bind(mt)
mt.add.bind(mt)
mt.remove.bind(mt)
mt.update.bind(mt)
function br(e, n) {
  ;(n == null || n > e.length) && (n = e.length)
  for (var r = 0, i = Array(n); r < n; r++) i[r] = e[r]
  return i
}
function Gl(e) {
  if (Array.isArray(e)) return e
}
function Vl(e, n) {
  if (!(e instanceof n)) throw new TypeError('Cannot call a class as a function')
}
function Bl(e, n, r) {
  return (Object.defineProperty(e, 'prototype', { writable: !1 }), e)
}
function Wl(e, n) {
  var r = e == null ? null : (typeof Symbol < 'u' && e[Symbol.iterator]) || e['@@iterator']
  if (r != null) {
    var i,
      o,
      a,
      s,
      u = [],
      l = !0,
      f = !1
    try {
      if (((a = (r = r.call(e)).next), n !== 0))
        for (; !(l = (i = a.call(r)).done) && (u.push(i.value), u.length !== n); l = !0);
    } catch (h) {
      ;((f = !0), (o = h))
    } finally {
      try {
        if (!l && r.return != null && ((s = r.return()), Object(s) !== s)) return
      } finally {
        if (f) throw o
      }
    }
    return u
  }
}
function Xl() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Yl(e, n) {
  return Gl(e) || Wl(e, n) || Zl(e, n) || Xl()
}
function Zl(e, n) {
  if (e) {
    if (typeof e == 'string') return br(e, n)
    var r = {}.toString.call(e).slice(8, -1)
    return (
      r === 'Object' && e.constructor && (r = e.constructor.name),
      r === 'Map' || r === 'Set'
        ? Array.from(e)
        : r === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
          ? br(e, n)
          : void 0
    )
  }
}
var Kl = Bl(function e(n, r) {
  var i = r.default,
    o = i === void 0 ? null : i,
    a = r.triggerUpdate,
    s = a === void 0 ? !0 : a,
    u = r.onChange,
    l = u === void 0 ? function (f, h) {} : u
  ;(Vl(this, e),
    (this.name = n),
    (this.defaultVal = o),
    (this.triggerUpdate = s),
    (this.onChange = l))
})
function Dn(e) {
  var n = e.stateInit,
    r =
      n === void 0
        ? function () {
            return {}
          }
        : n,
    i = e.props,
    o = i === void 0 ? {} : i,
    a = e.methods,
    s = a === void 0 ? {} : a,
    u = e.aliases,
    l = u === void 0 ? {} : u,
    f = e.init,
    h = f === void 0 ? function () {} : f,
    c = e.update,
    d = c === void 0 ? function () {} : c,
    p = Object.keys(o).map(function (y) {
      return new Kl(y, o[y])
    })
  return function y() {
    for (var m = arguments.length, _ = new Array(m), g = 0; g < m; g++) _[g] = arguments[g]
    var w = !!(this instanceof y && this.constructor),
      C = w ? _.shift() : void 0,
      x = _[0],
      b = x === void 0 ? {} : x,
      A = Object.assign({}, r instanceof Function ? r(b) : r, { initialised: !1 }),
      S = {}
    function M(z) {
      return (R(z, b), O(), M)
    }
    var R = function (N, j) {
        ;(h.call(M, N, A, j), (A.initialised = !0))
      },
      O = Ti(function () {
        A.initialised && (d.call(M, A, S), (S = {}))
      }, 1)
    return (
      p.forEach(function (z) {
        M[z.name] = N(z)
        function N(j) {
          var k = j.name,
            E = j.triggerUpdate,
            T = E === void 0 ? !1 : E,
            $ = j.onChange,
            D = $ === void 0 ? function (L, H) {} : $,
            F = j.defaultVal,
            U = F === void 0 ? null : F
          return function (L) {
            var H = A[k]
            if (!arguments.length) return H
            var Y = L === void 0 ? U : L
            return ((A[k] = Y), D.call(M, Y, A, H), !S.hasOwnProperty(k) && (S[k] = H), T && O(), M)
          }
        }
      }),
      Object.keys(s).forEach(function (z) {
        M[z] = function () {
          for (var N, j = arguments.length, k = new Array(j), E = 0; E < j; E++) k[E] = arguments[E]
          return (N = s[z]).call.apply(N, [M, A].concat(k))
        }
      }),
      Object.entries(l).forEach(function (z) {
        var N = Yl(z, 2),
          j = N[0],
          k = N[1]
        return (M[j] = M[k])
      }),
      (M.resetProps = function () {
        return (
          p.forEach(function (z) {
            M[z.name](z.defaultVal)
          }),
          M
        )
      }),
      M.resetProps(),
      (A._rerender = O),
      w && C && M(C),
      M
    )
  }
}
var q = function (e) {
  return typeof e == 'function'
    ? e
    : typeof e == 'string'
      ? function (n) {
          return n[e]
        }
      : function (n) {
          return e
        }
}
function Le(e) {
  '@babel/helpers - typeof'
  return (
    (Le =
      typeof Symbol == 'function' && typeof Symbol.iterator == 'symbol'
        ? function (n) {
            return typeof n
          }
        : function (n) {
            return n &&
              typeof Symbol == 'function' &&
              n.constructor === Symbol &&
              n !== Symbol.prototype
              ? 'symbol'
              : typeof n
          }),
    Le(e)
  )
}
var Ql = /^\s+/,
  Jl = /\s+$/
function I(e, n) {
  if (((e = e || ''), (n = n || {}), e instanceof I)) return e
  if (!(this instanceof I)) return new I(e, n)
  var r = tf(e)
  ;((this._originalInput = e),
    (this._r = r.r),
    (this._g = r.g),
    (this._b = r.b),
    (this._a = r.a),
    (this._roundA = Math.round(100 * this._a) / 100),
    (this._format = n.format || r.format),
    (this._gradientType = n.gradientType),
    this._r < 1 && (this._r = Math.round(this._r)),
    this._g < 1 && (this._g = Math.round(this._g)),
    this._b < 1 && (this._b = Math.round(this._b)),
    (this._ok = r.ok))
}
I.prototype = {
  isDark: function () {
    return this.getBrightness() < 128
  },
  isLight: function () {
    return !this.isDark()
  },
  isValid: function () {
    return this._ok
  },
  getOriginalInput: function () {
    return this._originalInput
  },
  getFormat: function () {
    return this._format
  },
  getAlpha: function () {
    return this._a
  },
  getBrightness: function () {
    var n = this.toRgb()
    return (n.r * 299 + n.g * 587 + n.b * 114) / 1e3
  },
  getLuminance: function () {
    var n = this.toRgb(),
      r,
      i,
      o,
      a,
      s,
      u
    return (
      (r = n.r / 255),
      (i = n.g / 255),
      (o = n.b / 255),
      r <= 0.03928 ? (a = r / 12.92) : (a = Math.pow((r + 0.055) / 1.055, 2.4)),
      i <= 0.03928 ? (s = i / 12.92) : (s = Math.pow((i + 0.055) / 1.055, 2.4)),
      o <= 0.03928 ? (u = o / 12.92) : (u = Math.pow((o + 0.055) / 1.055, 2.4)),
      0.2126 * a + 0.7152 * s + 0.0722 * u
    )
  },
  setAlpha: function (n) {
    return ((this._a = Oi(n)), (this._roundA = Math.round(100 * this._a) / 100), this)
  },
  toHsv: function () {
    var n = kr(this._r, this._g, this._b)
    return { h: n.h * 360, s: n.s, v: n.v, a: this._a }
  },
  toHsvString: function () {
    var n = kr(this._r, this._g, this._b),
      r = Math.round(n.h * 360),
      i = Math.round(n.s * 100),
      o = Math.round(n.v * 100)
    return this._a == 1
      ? 'hsv(' + r + ', ' + i + '%, ' + o + '%)'
      : 'hsva(' + r + ', ' + i + '%, ' + o + '%, ' + this._roundA + ')'
  },
  toHsl: function () {
    var n = wr(this._r, this._g, this._b)
    return { h: n.h * 360, s: n.s, l: n.l, a: this._a }
  },
  toHslString: function () {
    var n = wr(this._r, this._g, this._b),
      r = Math.round(n.h * 360),
      i = Math.round(n.s * 100),
      o = Math.round(n.l * 100)
    return this._a == 1
      ? 'hsl(' + r + ', ' + i + '%, ' + o + '%)'
      : 'hsla(' + r + ', ' + i + '%, ' + o + '%, ' + this._roundA + ')'
  },
  toHex: function (n) {
    return Ar(this._r, this._g, this._b, n)
  },
  toHexString: function (n) {
    return '#' + this.toHex(n)
  },
  toHex8: function (n) {
    return of(this._r, this._g, this._b, this._a, n)
  },
  toHex8String: function (n) {
    return '#' + this.toHex8(n)
  },
  toRgb: function () {
    return { r: Math.round(this._r), g: Math.round(this._g), b: Math.round(this._b), a: this._a }
  },
  toRgbString: function () {
    return this._a == 1
      ? 'rgb(' + Math.round(this._r) + ', ' + Math.round(this._g) + ', ' + Math.round(this._b) + ')'
      : 'rgba(' +
          Math.round(this._r) +
          ', ' +
          Math.round(this._g) +
          ', ' +
          Math.round(this._b) +
          ', ' +
          this._roundA +
          ')'
  },
  toPercentageRgb: function () {
    return {
      r: Math.round(B(this._r, 255) * 100) + '%',
      g: Math.round(B(this._g, 255) * 100) + '%',
      b: Math.round(B(this._b, 255) * 100) + '%',
      a: this._a,
    }
  },
  toPercentageRgbString: function () {
    return this._a == 1
      ? 'rgb(' +
          Math.round(B(this._r, 255) * 100) +
          '%, ' +
          Math.round(B(this._g, 255) * 100) +
          '%, ' +
          Math.round(B(this._b, 255) * 100) +
          '%)'
      : 'rgba(' +
          Math.round(B(this._r, 255) * 100) +
          '%, ' +
          Math.round(B(this._g, 255) * 100) +
          '%, ' +
          Math.round(B(this._b, 255) * 100) +
          '%, ' +
          this._roundA +
          ')'
  },
  toName: function () {
    return this._a === 0
      ? 'transparent'
      : this._a < 1
        ? !1
        : _f[Ar(this._r, this._g, this._b, !0)] || !1
  },
  toFilter: function (n) {
    var r = '#' + Cr(this._r, this._g, this._b, this._a),
      i = r,
      o = this._gradientType ? 'GradientType = 1, ' : ''
    if (n) {
      var a = I(n)
      i = '#' + Cr(a._r, a._g, a._b, a._a)
    }
    return (
      'progid:DXImageTransform.Microsoft.gradient(' +
      o +
      'startColorstr=' +
      r +
      ',endColorstr=' +
      i +
      ')'
    )
  },
  toString: function (n) {
    var r = !!n
    n = n || this._format
    var i = !1,
      o = this._a < 1 && this._a >= 0,
      a =
        !r &&
        o &&
        (n === 'hex' ||
          n === 'hex6' ||
          n === 'hex3' ||
          n === 'hex4' ||
          n === 'hex8' ||
          n === 'name')
    return a
      ? n === 'name' && this._a === 0
        ? this.toName()
        : this.toRgbString()
      : (n === 'rgb' && (i = this.toRgbString()),
        n === 'prgb' && (i = this.toPercentageRgbString()),
        (n === 'hex' || n === 'hex6') && (i = this.toHexString()),
        n === 'hex3' && (i = this.toHexString(!0)),
        n === 'hex4' && (i = this.toHex8String(!0)),
        n === 'hex8' && (i = this.toHex8String()),
        n === 'name' && (i = this.toName()),
        n === 'hsl' && (i = this.toHslString()),
        n === 'hsv' && (i = this.toHsvString()),
        i || this.toHexString())
  },
  clone: function () {
    return I(this.toString())
  },
  _applyModification: function (n, r) {
    var i = n.apply(null, [this].concat([].slice.call(r)))
    return ((this._r = i._r), (this._g = i._g), (this._b = i._b), this.setAlpha(i._a), this)
  },
  lighten: function () {
    return this._applyModification(lf, arguments)
  },
  brighten: function () {
    return this._applyModification(ff, arguments)
  },
  darken: function () {
    return this._applyModification(cf, arguments)
  },
  desaturate: function () {
    return this._applyModification(af, arguments)
  },
  saturate: function () {
    return this._applyModification(sf, arguments)
  },
  greyscale: function () {
    return this._applyModification(uf, arguments)
  },
  spin: function () {
    return this._applyModification(hf, arguments)
  },
  _applyCombination: function (n, r) {
    return n.apply(null, [this].concat([].slice.call(r)))
  },
  analogous: function () {
    return this._applyCombination(gf, arguments)
  },
  complement: function () {
    return this._applyCombination(df, arguments)
  },
  monochromatic: function () {
    return this._applyCombination(yf, arguments)
  },
  splitcomplement: function () {
    return this._applyCombination(pf, arguments)
  },
  triad: function () {
    return this._applyCombination(Sr, [3])
  },
  tetrad: function () {
    return this._applyCombination(Sr, [4])
  },
}
I.fromRatio = function (e, n) {
  if (Le(e) == 'object') {
    var r = {}
    for (var i in e) e.hasOwnProperty(i) && (i === 'a' ? (r[i] = e[i]) : (r[i] = ae(e[i])))
    e = r
  }
  return I(e, n)
}
function tf(e) {
  var n = { r: 0, g: 0, b: 0 },
    r = 1,
    i = null,
    o = null,
    a = null,
    s = !1,
    u = !1
  return (
    typeof e == 'string' && (e = bf(e)),
    Le(e) == 'object' &&
      (At(e.r) && At(e.g) && At(e.b)
        ? ((n = ef(e.r, e.g, e.b)), (s = !0), (u = String(e.r).substr(-1) === '%' ? 'prgb' : 'rgb'))
        : At(e.h) && At(e.s) && At(e.v)
          ? ((i = ae(e.s)), (o = ae(e.v)), (n = rf(e.h, i, o)), (s = !0), (u = 'hsv'))
          : At(e.h) &&
            At(e.s) &&
            At(e.l) &&
            ((i = ae(e.s)), (a = ae(e.l)), (n = nf(e.h, i, a)), (s = !0), (u = 'hsl')),
      e.hasOwnProperty('a') && (r = e.a)),
    (r = Oi(r)),
    {
      ok: s,
      format: e.format || u,
      r: Math.min(255, Math.max(n.r, 0)),
      g: Math.min(255, Math.max(n.g, 0)),
      b: Math.min(255, Math.max(n.b, 0)),
      a: r,
    }
  )
}
function ef(e, n, r) {
  return { r: B(e, 255) * 255, g: B(n, 255) * 255, b: B(r, 255) * 255 }
}
function wr(e, n, r) {
  ;((e = B(e, 255)), (n = B(n, 255)), (r = B(r, 255)))
  var i = Math.max(e, n, r),
    o = Math.min(e, n, r),
    a,
    s,
    u = (i + o) / 2
  if (i == o) a = s = 0
  else {
    var l = i - o
    switch (((s = u > 0.5 ? l / (2 - i - o) : l / (i + o)), i)) {
      case e:
        a = (n - r) / l + (n < r ? 6 : 0)
        break
      case n:
        a = (r - e) / l + 2
        break
      case r:
        a = (e - n) / l + 4
        break
    }
    a /= 6
  }
  return { h: a, s, l: u }
}
function nf(e, n, r) {
  var i, o, a
  ;((e = B(e, 360)), (n = B(n, 100)), (r = B(r, 100)))
  function s(f, h, c) {
    return (
      c < 0 && (c += 1),
      c > 1 && (c -= 1),
      c < 1 / 6
        ? f + (h - f) * 6 * c
        : c < 1 / 2
          ? h
          : c < 2 / 3
            ? f + (h - f) * (2 / 3 - c) * 6
            : f
    )
  }
  if (n === 0) i = o = a = r
  else {
    var u = r < 0.5 ? r * (1 + n) : r + n - r * n,
      l = 2 * r - u
    ;((i = s(l, u, e + 1 / 3)), (o = s(l, u, e)), (a = s(l, u, e - 1 / 3)))
  }
  return { r: i * 255, g: o * 255, b: a * 255 }
}
function kr(e, n, r) {
  ;((e = B(e, 255)), (n = B(n, 255)), (r = B(r, 255)))
  var i = Math.max(e, n, r),
    o = Math.min(e, n, r),
    a,
    s,
    u = i,
    l = i - o
  if (((s = i === 0 ? 0 : l / i), i == o)) a = 0
  else {
    switch (i) {
      case e:
        a = (n - r) / l + (n < r ? 6 : 0)
        break
      case n:
        a = (r - e) / l + 2
        break
      case r:
        a = (e - n) / l + 4
        break
    }
    a /= 6
  }
  return { h: a, s, v: u }
}
function rf(e, n, r) {
  ;((e = B(e, 360) * 6), (n = B(n, 100)), (r = B(r, 100)))
  var i = Math.floor(e),
    o = e - i,
    a = r * (1 - n),
    s = r * (1 - o * n),
    u = r * (1 - (1 - o) * n),
    l = i % 6,
    f = [r, s, a, a, u, r][l],
    h = [u, r, r, s, a, a][l],
    c = [a, a, u, r, r, s][l]
  return { r: f * 255, g: h * 255, b: c * 255 }
}
function Ar(e, n, r, i) {
  var o = [
    dt(Math.round(e).toString(16)),
    dt(Math.round(n).toString(16)),
    dt(Math.round(r).toString(16)),
  ]
  return i &&
    o[0].charAt(0) == o[0].charAt(1) &&
    o[1].charAt(0) == o[1].charAt(1) &&
    o[2].charAt(0) == o[2].charAt(1)
    ? o[0].charAt(0) + o[1].charAt(0) + o[2].charAt(0)
    : o.join('')
}
function of(e, n, r, i, o) {
  var a = [
    dt(Math.round(e).toString(16)),
    dt(Math.round(n).toString(16)),
    dt(Math.round(r).toString(16)),
    dt(Ei(i)),
  ]
  return o &&
    a[0].charAt(0) == a[0].charAt(1) &&
    a[1].charAt(0) == a[1].charAt(1) &&
    a[2].charAt(0) == a[2].charAt(1) &&
    a[3].charAt(0) == a[3].charAt(1)
    ? a[0].charAt(0) + a[1].charAt(0) + a[2].charAt(0) + a[3].charAt(0)
    : a.join('')
}
function Cr(e, n, r, i) {
  var o = [
    dt(Ei(i)),
    dt(Math.round(e).toString(16)),
    dt(Math.round(n).toString(16)),
    dt(Math.round(r).toString(16)),
  ]
  return o.join('')
}
I.equals = function (e, n) {
  return !e || !n ? !1 : I(e).toRgbString() == I(n).toRgbString()
}
I.random = function () {
  return I.fromRatio({ r: Math.random(), g: Math.random(), b: Math.random() })
}
function af(e, n) {
  n = n === 0 ? 0 : n || 10
  var r = I(e).toHsl()
  return ((r.s -= n / 100), (r.s = Xe(r.s)), I(r))
}
function sf(e, n) {
  n = n === 0 ? 0 : n || 10
  var r = I(e).toHsl()
  return ((r.s += n / 100), (r.s = Xe(r.s)), I(r))
}
function uf(e) {
  return I(e).desaturate(100)
}
function lf(e, n) {
  n = n === 0 ? 0 : n || 10
  var r = I(e).toHsl()
  return ((r.l += n / 100), (r.l = Xe(r.l)), I(r))
}
function ff(e, n) {
  n = n === 0 ? 0 : n || 10
  var r = I(e).toRgb()
  return (
    (r.r = Math.max(0, Math.min(255, r.r - Math.round(255 * -(n / 100))))),
    (r.g = Math.max(0, Math.min(255, r.g - Math.round(255 * -(n / 100))))),
    (r.b = Math.max(0, Math.min(255, r.b - Math.round(255 * -(n / 100))))),
    I(r)
  )
}
function cf(e, n) {
  n = n === 0 ? 0 : n || 10
  var r = I(e).toHsl()
  return ((r.l -= n / 100), (r.l = Xe(r.l)), I(r))
}
function hf(e, n) {
  var r = I(e).toHsl(),
    i = (r.h + n) % 360
  return ((r.h = i < 0 ? 360 + i : i), I(r))
}
function df(e) {
  var n = I(e).toHsl()
  return ((n.h = (n.h + 180) % 360), I(n))
}
function Sr(e, n) {
  if (isNaN(n) || n <= 0) throw new Error('Argument to polyad must be a positive number')
  for (var r = I(e).toHsl(), i = [I(e)], o = 360 / n, a = 1; a < n; a++)
    i.push(I({ h: (r.h + a * o) % 360, s: r.s, l: r.l }))
  return i
}
function pf(e) {
  var n = I(e).toHsl(),
    r = n.h
  return [I(e), I({ h: (r + 72) % 360, s: n.s, l: n.l }), I({ h: (r + 216) % 360, s: n.s, l: n.l })]
}
function gf(e, n, r) {
  ;((n = n || 6), (r = r || 30))
  var i = I(e).toHsl(),
    o = 360 / r,
    a = [I(e)]
  for (i.h = (i.h - ((o * n) >> 1) + 720) % 360; --n; ) ((i.h = (i.h + o) % 360), a.push(I(i)))
  return a
}
function yf(e, n) {
  n = n || 6
  for (var r = I(e).toHsv(), i = r.h, o = r.s, a = r.v, s = [], u = 1 / n; n--; )
    (s.push(I({ h: i, s: o, v: a })), (a = (a + u) % 1))
  return s
}
I.mix = function (e, n, r) {
  r = r === 0 ? 0 : r || 50
  var i = I(e).toRgb(),
    o = I(n).toRgb(),
    a = r / 100,
    s = {
      r: (o.r - i.r) * a + i.r,
      g: (o.g - i.g) * a + i.g,
      b: (o.b - i.b) * a + i.b,
      a: (o.a - i.a) * a + i.a,
    }
  return I(s)
}
I.readability = function (e, n) {
  var r = I(e),
    i = I(n)
  return (
    (Math.max(r.getLuminance(), i.getLuminance()) + 0.05) /
    (Math.min(r.getLuminance(), i.getLuminance()) + 0.05)
  )
}
I.isReadable = function (e, n, r) {
  var i = I.readability(e, n),
    o,
    a
  switch (((a = !1), (o = wf(r)), o.level + o.size)) {
    case 'AAsmall':
    case 'AAAlarge':
      a = i >= 4.5
      break
    case 'AAlarge':
      a = i >= 3
      break
    case 'AAAsmall':
      a = i >= 7
      break
  }
  return a
}
I.mostReadable = function (e, n, r) {
  var i = null,
    o = 0,
    a,
    s,
    u,
    l
  ;((r = r || {}), (s = r.includeFallbackColors), (u = r.level), (l = r.size))
  for (var f = 0; f < n.length; f++)
    ((a = I.readability(e, n[f])), a > o && ((o = a), (i = I(n[f]))))
  return I.isReadable(e, i, { level: u, size: l }) || !s
    ? i
    : ((r.includeFallbackColors = !1), I.mostReadable(e, ['#fff', '#000'], r))
}
var xn = (I.names = {
    aliceblue: 'f0f8ff',
    antiquewhite: 'faebd7',
    aqua: '0ff',
    aquamarine: '7fffd4',
    azure: 'f0ffff',
    beige: 'f5f5dc',
    bisque: 'ffe4c4',
    black: '000',
    blanchedalmond: 'ffebcd',
    blue: '00f',
    blueviolet: '8a2be2',
    brown: 'a52a2a',
    burlywood: 'deb887',
    burntsienna: 'ea7e5d',
    cadetblue: '5f9ea0',
    chartreuse: '7fff00',
    chocolate: 'd2691e',
    coral: 'ff7f50',
    cornflowerblue: '6495ed',
    cornsilk: 'fff8dc',
    crimson: 'dc143c',
    cyan: '0ff',
    darkblue: '00008b',
    darkcyan: '008b8b',
    darkgoldenrod: 'b8860b',
    darkgray: 'a9a9a9',
    darkgreen: '006400',
    darkgrey: 'a9a9a9',
    darkkhaki: 'bdb76b',
    darkmagenta: '8b008b',
    darkolivegreen: '556b2f',
    darkorange: 'ff8c00',
    darkorchid: '9932cc',
    darkred: '8b0000',
    darksalmon: 'e9967a',
    darkseagreen: '8fbc8f',
    darkslateblue: '483d8b',
    darkslategray: '2f4f4f',
    darkslategrey: '2f4f4f',
    darkturquoise: '00ced1',
    darkviolet: '9400d3',
    deeppink: 'ff1493',
    deepskyblue: '00bfff',
    dimgray: '696969',
    dimgrey: '696969',
    dodgerblue: '1e90ff',
    firebrick: 'b22222',
    floralwhite: 'fffaf0',
    forestgreen: '228b22',
    fuchsia: 'f0f',
    gainsboro: 'dcdcdc',
    ghostwhite: 'f8f8ff',
    gold: 'ffd700',
    goldenrod: 'daa520',
    gray: '808080',
    green: '008000',
    greenyellow: 'adff2f',
    grey: '808080',
    honeydew: 'f0fff0',
    hotpink: 'ff69b4',
    indianred: 'cd5c5c',
    indigo: '4b0082',
    ivory: 'fffff0',
    khaki: 'f0e68c',
    lavender: 'e6e6fa',
    lavenderblush: 'fff0f5',
    lawngreen: '7cfc00',
    lemonchiffon: 'fffacd',
    lightblue: 'add8e6',
    lightcoral: 'f08080',
    lightcyan: 'e0ffff',
    lightgoldenrodyellow: 'fafad2',
    lightgray: 'd3d3d3',
    lightgreen: '90ee90',
    lightgrey: 'd3d3d3',
    lightpink: 'ffb6c1',
    lightsalmon: 'ffa07a',
    lightseagreen: '20b2aa',
    lightskyblue: '87cefa',
    lightslategray: '789',
    lightslategrey: '789',
    lightsteelblue: 'b0c4de',
    lightyellow: 'ffffe0',
    lime: '0f0',
    limegreen: '32cd32',
    linen: 'faf0e6',
    magenta: 'f0f',
    maroon: '800000',
    mediumaquamarine: '66cdaa',
    mediumblue: '0000cd',
    mediumorchid: 'ba55d3',
    mediumpurple: '9370db',
    mediumseagreen: '3cb371',
    mediumslateblue: '7b68ee',
    mediumspringgreen: '00fa9a',
    mediumturquoise: '48d1cc',
    mediumvioletred: 'c71585',
    midnightblue: '191970',
    mintcream: 'f5fffa',
    mistyrose: 'ffe4e1',
    moccasin: 'ffe4b5',
    navajowhite: 'ffdead',
    navy: '000080',
    oldlace: 'fdf5e6',
    olive: '808000',
    olivedrab: '6b8e23',
    orange: 'ffa500',
    orangered: 'ff4500',
    orchid: 'da70d6',
    palegoldenrod: 'eee8aa',
    palegreen: '98fb98',
    paleturquoise: 'afeeee',
    palevioletred: 'db7093',
    papayawhip: 'ffefd5',
    peachpuff: 'ffdab9',
    peru: 'cd853f',
    pink: 'ffc0cb',
    plum: 'dda0dd',
    powderblue: 'b0e0e6',
    purple: '800080',
    rebeccapurple: '663399',
    red: 'f00',
    rosybrown: 'bc8f8f',
    royalblue: '4169e1',
    saddlebrown: '8b4513',
    salmon: 'fa8072',
    sandybrown: 'f4a460',
    seagreen: '2e8b57',
    seashell: 'fff5ee',
    sienna: 'a0522d',
    silver: 'c0c0c0',
    skyblue: '87ceeb',
    slateblue: '6a5acd',
    slategray: '708090',
    slategrey: '708090',
    snow: 'fffafa',
    springgreen: '00ff7f',
    steelblue: '4682b4',
    tan: 'd2b48c',
    teal: '008080',
    thistle: 'd8bfd8',
    tomato: 'ff6347',
    turquoise: '40e0d0',
    violet: 'ee82ee',
    wheat: 'f5deb3',
    white: 'fff',
    whitesmoke: 'f5f5f5',
    yellow: 'ff0',
    yellowgreen: '9acd32',
  }),
  _f = (I.hexNames = vf(xn))
function vf(e) {
  var n = {}
  for (var r in e) e.hasOwnProperty(r) && (n[e[r]] = r)
  return n
}
function Oi(e) {
  return ((e = parseFloat(e)), (isNaN(e) || e < 0 || e > 1) && (e = 1), e)
}
function B(e, n) {
  mf(e) && (e = '100%')
  var r = xf(e)
  return (
    (e = Math.min(n, Math.max(0, parseFloat(e)))),
    r && (e = parseInt(e * n, 10) / 100),
    Math.abs(e - n) < 1e-6 ? 1 : (e % n) / parseFloat(n)
  )
}
function Xe(e) {
  return Math.min(1, Math.max(0, e))
}
function nt(e) {
  return parseInt(e, 16)
}
function mf(e) {
  return typeof e == 'string' && e.indexOf('.') != -1 && parseFloat(e) === 1
}
function xf(e) {
  return typeof e == 'string' && e.indexOf('%') != -1
}
function dt(e) {
  return e.length == 1 ? '0' + e : '' + e
}
function ae(e) {
  return (e <= 1 && (e = e * 100 + '%'), e)
}
function Ei(e) {
  return Math.round(parseFloat(e) * 255).toString(16)
}
function Mr(e) {
  return nt(e) / 255
}
var ct = (function () {
  var e = '[-\\+]?\\d+%?',
    n = '[-\\+]?\\d*\\.\\d+%?',
    r = '(?:' + n + ')|(?:' + e + ')',
    i = '[\\s|\\(]+(' + r + ')[,|\\s]+(' + r + ')[,|\\s]+(' + r + ')\\s*\\)?',
    o = '[\\s|\\(]+(' + r + ')[,|\\s]+(' + r + ')[,|\\s]+(' + r + ')[,|\\s]+(' + r + ')\\s*\\)?'
  return {
    CSS_UNIT: new RegExp(r),
    rgb: new RegExp('rgb' + i),
    rgba: new RegExp('rgba' + o),
    hsl: new RegExp('hsl' + i),
    hsla: new RegExp('hsla' + o),
    hsv: new RegExp('hsv' + i),
    hsva: new RegExp('hsva' + o),
    hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
    hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
    hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
  }
})()
function At(e) {
  return !!ct.CSS_UNIT.exec(e)
}
function bf(e) {
  e = e.replace(Ql, '').replace(Jl, '').toLowerCase()
  var n = !1
  if (xn[e]) ((e = xn[e]), (n = !0))
  else if (e == 'transparent') return { r: 0, g: 0, b: 0, a: 0, format: 'name' }
  var r
  return (r = ct.rgb.exec(e))
    ? { r: r[1], g: r[2], b: r[3] }
    : (r = ct.rgba.exec(e))
      ? { r: r[1], g: r[2], b: r[3], a: r[4] }
      : (r = ct.hsl.exec(e))
        ? { h: r[1], s: r[2], l: r[3] }
        : (r = ct.hsla.exec(e))
          ? { h: r[1], s: r[2], l: r[3], a: r[4] }
          : (r = ct.hsv.exec(e))
            ? { h: r[1], s: r[2], v: r[3] }
            : (r = ct.hsva.exec(e))
              ? { h: r[1], s: r[2], v: r[3], a: r[4] }
              : (r = ct.hex8.exec(e))
                ? {
                    r: nt(r[1]),
                    g: nt(r[2]),
                    b: nt(r[3]),
                    a: Mr(r[4]),
                    format: n ? 'name' : 'hex8',
                  }
                : (r = ct.hex6.exec(e))
                  ? { r: nt(r[1]), g: nt(r[2]), b: nt(r[3]), format: n ? 'name' : 'hex' }
                  : (r = ct.hex4.exec(e))
                    ? {
                        r: nt(r[1] + '' + r[1]),
                        g: nt(r[2] + '' + r[2]),
                        b: nt(r[3] + '' + r[3]),
                        a: Mr(r[4] + '' + r[4]),
                        format: n ? 'name' : 'hex8',
                      }
                    : (r = ct.hex3.exec(e))
                      ? {
                          r: nt(r[1] + '' + r[1]),
                          g: nt(r[2] + '' + r[2]),
                          b: nt(r[3] + '' + r[3]),
                          format: n ? 'name' : 'hex',
                        }
                      : !1
}
function wf(e) {
  var n, r
  return (
    (e = e || { level: 'AA', size: 'small' }),
    (n = (e.level || 'AA').toUpperCase()),
    (r = (e.size || 'small').toLowerCase()),
    n !== 'AA' && n !== 'AAA' && (n = 'AA'),
    r !== 'small' && r !== 'large' && (r = 'small'),
    { level: n, size: r }
  )
}
function bn(e, n) {
  ;(n == null || n > e.length) && (n = e.length)
  for (var r = 0, i = Array(n); r < n; r++) i[r] = e[r]
  return i
}
function kf(e) {
  if (Array.isArray(e)) return bn(e)
}
function zi(e, n, r) {
  if (typeof e == 'function' ? e === n : e.has(n)) return arguments.length < 3 ? n : r
  throw new TypeError('Private element is not present on this object')
}
function Af(e, n) {
  if (n.has(e))
    throw new TypeError('Cannot initialize the same private elements twice on an object')
}
function Cf(e, n) {
  if (!(e instanceof n)) throw new TypeError('Cannot call a class as a function')
}
function it(e, n) {
  return e.get(zi(e, n))
}
function Tr(e, n, r) {
  ;(Af(e, n), n.set(e, r))
}
function Pr(e, n, r) {
  return (e.set(zi(e, n), r), r)
}
function Sf(e, n) {
  for (var r = 0; r < n.length; r++) {
    var i = n[r]
    ;((i.enumerable = i.enumerable || !1),
      (i.configurable = !0),
      'value' in i && (i.writable = !0),
      Object.defineProperty(e, zf(i.key), i))
  }
}
function Mf(e, n, r) {
  return (n && Sf(e.prototype, n), Object.defineProperty(e, 'prototype', { writable: !1 }), e)
}
function Tf(e) {
  if ((typeof Symbol < 'u' && e[Symbol.iterator] != null) || e['@@iterator'] != null)
    return Array.from(e)
}
function Pf() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Of(e) {
  return kf(e) || Tf(e) || Rf(e) || Pf()
}
function Ef(e, n) {
  if (typeof e != 'object' || !e) return e
  var r = e[Symbol.toPrimitive]
  if (r !== void 0) {
    var i = r.call(e, n)
    if (typeof i != 'object') return i
    throw new TypeError('@@toPrimitive must return a primitive value.')
  }
  return String(e)
}
function zf(e) {
  var n = Ef(e, 'string')
  return typeof n == 'symbol' ? n : n + ''
}
function Rf(e, n) {
  if (e) {
    if (typeof e == 'string') return bn(e, n)
    var r = {}.toString.call(e).slice(8, -1)
    return (
      r === 'Object' && e.constructor && (r = e.constructor.name),
      r === 'Map' || r === 'Set'
        ? Array.from(e)
        : r === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
          ? bn(e, n)
          : void 0
    )
  }
}
var Nf = 123,
  $f = function (n) {
    return '#'.concat(Math.min(n, Math.pow(2, 24)).toString(16).padStart(6, '0'))
  },
  Ri = function (n, r, i) {
    return (n << 16) + (r << 8) + i
  },
  If = function (n) {
    var r = I(n).toRgb(),
      i = r.r,
      o = r.g,
      a = r.b
    return Ri(i, o, a)
  },
  Or = function (n, r) {
    return (n * Nf) % Math.pow(2, r)
  },
  $t = new WeakMap(),
  Ct = new WeakMap(),
  Df = (function () {
    function e() {
      var n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 6
      ;(Cf(this, e), Tr(this, $t, void 0), Tr(this, Ct, void 0), Pr(Ct, this, n), this.reset())
    }
    return Mf(e, [
      {
        key: 'reset',
        value: function () {
          Pr($t, this, ['__reserved for background__'])
        },
      },
      {
        key: 'register',
        value: function (r) {
          if (it($t, this).length >= Math.pow(2, 24 - it(Ct, this))) return null
          var i = it($t, this).length,
            o = Or(i, it(Ct, this)),
            a = $f(i + (o << (24 - it(Ct, this))))
          return (it($t, this).push(r), a)
        },
      },
      {
        key: 'lookup',
        value: function (r) {
          if (!r) return null
          var i = typeof r == 'string' ? If(r) : Ri.apply(void 0, Of(r))
          if (!i) return null
          var o = i & (Math.pow(2, 24 - it(Ct, this)) - 1),
            a = (i >> (24 - it(Ct, this))) & (Math.pow(2, it(Ct, this)) - 1)
          return Or(o, it(Ct, this)) !== a || o >= it($t, this).length ? null : it($t, this)[o]
        },
      },
    ])
  })(),
  xe,
  W,
  Ni,
  $i,
  It,
  Er,
  Ii,
  Di,
  ji,
  jn,
  wn,
  kn,
  ge = {},
  Fi = [],
  jf = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,
  Ye = Array.isArray
function _t(e, n) {
  for (var r in n) e[r] = n[r]
  return e
}
function Fn(e) {
  e && e.parentNode && e.parentNode.removeChild(e)
}
function Ff(e, n, r) {
  var i,
    o,
    a,
    s = {}
  for (a in n) a == 'key' ? (i = n[a]) : a == 'ref' ? (o = n[a]) : (s[a] = n[a])
  if (
    (arguments.length > 2 && (s.children = arguments.length > 3 ? xe.call(arguments, 2) : r),
    typeof e == 'function' && e.defaultProps != null)
  )
    for (a in e.defaultProps) s[a] === void 0 && (s[a] = e.defaultProps[a])
  return se(e, s, i, o, null)
}
function se(e, n, r, i, o) {
  var a = {
    type: e,
    props: n,
    key: r,
    ref: i,
    __k: null,
    __: null,
    __b: 0,
    __e: null,
    __c: null,
    constructor: void 0,
    __v: o ?? ++Ni,
    __i: -1,
    __u: 0,
  }
  return (o == null && W.vnode != null && W.vnode(a), a)
}
function Ze(e) {
  return e.children
}
function ze(e, n) {
  ;((this.props = e), (this.context = n))
}
function Xt(e, n) {
  if (n == null) return e.__ ? Xt(e.__, e.__i + 1) : null
  for (var r; n < e.__k.length; n++) if ((r = e.__k[n]) != null && r.__e != null) return r.__e
  return typeof e.type == 'function' ? Xt(e) : null
}
function Ui(e) {
  var n, r
  if ((e = e.__) != null && e.__c != null) {
    for (e.__e = e.__c.base = null, n = 0; n < e.__k.length; n++)
      if ((r = e.__k[n]) != null && r.__e != null) {
        e.__e = e.__c.base = r.__e
        break
      }
    return Ui(e)
  }
}
function zr(e) {
  ;((!e.__d && (e.__d = !0) && It.push(e) && !He.__r++) || Er != W.debounceRendering) &&
    ((Er = W.debounceRendering) || Ii)(He)
}
function He() {
  for (var e, n, r, i, o, a, s, u = 1; It.length; )
    (It.length > u && It.sort(Di),
      (e = It.shift()),
      (u = It.length),
      e.__d &&
        ((r = void 0),
        (i = void 0),
        (o = (i = (n = e).__v).__e),
        (a = []),
        (s = []),
        n.__P &&
          (((r = _t({}, i)).__v = i.__v + 1),
          W.vnode && W.vnode(r),
          Un(
            n.__P,
            r,
            i,
            n.__n,
            n.__P.namespaceURI,
            32 & i.__u ? [o] : null,
            a,
            o ?? Xt(i),
            !!(32 & i.__u),
            s
          ),
          (r.__v = i.__v),
          (r.__.__k[r.__i] = r),
          qi(a, r, s),
          (i.__e = i.__ = null),
          r.__e != o && Ui(r))))
  He.__r = 0
}
function Li(e, n, r, i, o, a, s, u, l, f, h) {
  var c,
    d,
    p,
    y,
    m,
    _,
    g,
    w = (i && i.__k) || Fi,
    C = n.length
  for (l = Uf(r, n, w, l, C), c = 0; c < C; c++)
    (p = r.__k[c]) != null &&
      ((d = p.__i == -1 ? ge : w[p.__i] || ge),
      (p.__i = c),
      (_ = Un(e, p, d, o, a, s, u, l, f, h)),
      (y = p.__e),
      p.ref && d.ref != p.ref && (d.ref && Ln(d.ref, null, p), h.push(p.ref, p.__c || y, p)),
      m == null && y != null && (m = y),
      (g = !!(4 & p.__u)) || d.__k === p.__k
        ? (l = Hi(p, l, e, g))
        : typeof p.type == 'function' && _ !== void 0
          ? (l = _)
          : y && (l = y.nextSibling),
      (p.__u &= -7))
  return ((r.__e = m), l)
}
function Uf(e, n, r, i, o) {
  var a,
    s,
    u,
    l,
    f,
    h = r.length,
    c = h,
    d = 0
  for (e.__k = new Array(o), a = 0; a < o; a++)
    (s = n[a]) != null && typeof s != 'boolean' && typeof s != 'function'
      ? ((l = a + d),
        ((s = e.__k[a] =
          typeof s == 'string' ||
          typeof s == 'number' ||
          typeof s == 'bigint' ||
          s.constructor == String
            ? se(null, s, null, null, null)
            : Ye(s)
              ? se(Ze, { children: s }, null, null, null)
              : s.constructor == null && s.__b > 0
                ? se(s.type, s.props, s.key, s.ref ? s.ref : null, s.__v)
                : s).__ = e),
        (s.__b = e.__b + 1),
        (u = null),
        (f = s.__i = Lf(s, r, l, c)) != -1 && (c--, (u = r[f]) && (u.__u |= 2)),
        u == null || u.__v == null
          ? (f == -1 && (o > h ? d-- : o < h && d++), typeof s.type != 'function' && (s.__u |= 4))
          : f != l && (f == l - 1 ? d-- : f == l + 1 ? d++ : (f > l ? d-- : d++, (s.__u |= 4))))
      : (e.__k[a] = null)
  if (c)
    for (a = 0; a < h; a++)
      (u = r[a]) != null && !(2 & u.__u) && (u.__e == i && (i = Xt(u)), Vi(u, u))
  return i
}
function Hi(e, n, r, i) {
  var o, a
  if (typeof e.type == 'function') {
    for (o = e.__k, a = 0; o && a < o.length; a++) o[a] && ((o[a].__ = e), (n = Hi(o[a], n, r, i)))
    return n
  }
  e.__e != n &&
    (i && (n && e.type && !n.parentNode && (n = Xt(e)), r.insertBefore(e.__e, n || null)),
    (n = e.__e))
  do n = n && n.nextSibling
  while (n != null && n.nodeType == 8)
  return n
}
function Lf(e, n, r, i) {
  var o,
    a,
    s,
    u = e.key,
    l = e.type,
    f = n[r],
    h = f != null && (2 & f.__u) == 0
  if ((f === null && e.key == null) || (h && u == f.key && l == f.type)) return r
  if (i > (h ? 1 : 0)) {
    for (o = r - 1, a = r + 1; o >= 0 || a < n.length; )
      if ((f = n[(s = o >= 0 ? o-- : a++)]) != null && !(2 & f.__u) && u == f.key && l == f.type)
        return s
  }
  return -1
}
function Rr(e, n, r) {
  n[0] == '-'
    ? e.setProperty(n, r ?? '')
    : (e[n] = r == null ? '' : typeof r != 'number' || jf.test(n) ? r : r + 'px')
}
function Se(e, n, r, i, o) {
  var a, s
  t: if (n == 'style')
    if (typeof r == 'string') e.style.cssText = r
    else {
      if ((typeof i == 'string' && (e.style.cssText = i = ''), i))
        for (n in i) (r && n in r) || Rr(e.style, n, '')
      if (r) for (n in r) (i && r[n] == i[n]) || Rr(e.style, n, r[n])
    }
  else if (n[0] == 'o' && n[1] == 'n')
    ((a = n != (n = n.replace(ji, '$1'))),
      (s = n.toLowerCase()),
      (n = s in e || n == 'onFocusOut' || n == 'onFocusIn' ? s.slice(2) : n.slice(2)),
      e.l || (e.l = {}),
      (e.l[n + a] = r),
      r
        ? i
          ? (r.u = i.u)
          : ((r.u = jn), e.addEventListener(n, a ? kn : wn, a))
        : e.removeEventListener(n, a ? kn : wn, a))
  else {
    if (o == 'http://www.w3.org/2000/svg') n = n.replace(/xlink(H|:h)/, 'h').replace(/sName$/, 's')
    else if (
      n != 'width' &&
      n != 'height' &&
      n != 'href' &&
      n != 'list' &&
      n != 'form' &&
      n != 'tabIndex' &&
      n != 'download' &&
      n != 'rowSpan' &&
      n != 'colSpan' &&
      n != 'role' &&
      n != 'popover' &&
      n in e
    )
      try {
        e[n] = r ?? ''
        break t
      } catch {}
    typeof r == 'function' ||
      (r == null || (r === !1 && n[4] != '-')
        ? e.removeAttribute(n)
        : e.setAttribute(n, n == 'popover' && r == 1 ? '' : r))
  }
}
function Nr(e) {
  return function (n) {
    if (this.l) {
      var r = this.l[n.type + e]
      if (n.t == null) n.t = jn++
      else if (n.t < r.u) return
      return r(W.event ? W.event(n) : n)
    }
  }
}
function Un(e, n, r, i, o, a, s, u, l, f) {
  var h,
    c,
    d,
    p,
    y,
    m,
    _,
    g,
    w,
    C,
    x,
    b,
    A,
    S,
    M,
    R,
    O,
    z = n.type
  if (n.constructor != null) return null
  ;(128 & r.__u && ((l = !!(32 & r.__u)), (a = [(u = n.__e = r.__e)])), (h = W.__b) && h(n))
  t: if (typeof z == 'function')
    try {
      if (
        ((g = n.props),
        (w = 'prototype' in z && z.prototype.render),
        (C = (h = z.contextType) && i[h.__c]),
        (x = h ? (C ? C.props.value : h.__) : i),
        r.__c
          ? (_ = (c = n.__c = r.__c).__ = c.__E)
          : (w
              ? (n.__c = c = new z(g, x))
              : ((n.__c = c = new ze(g, x)), (c.constructor = z), (c.render = qf)),
            C && C.sub(c),
            (c.props = g),
            c.state || (c.state = {}),
            (c.context = x),
            (c.__n = i),
            (d = c.__d = !0),
            (c.__h = []),
            (c._sb = [])),
        w && c.__s == null && (c.__s = c.state),
        w &&
          z.getDerivedStateFromProps != null &&
          (c.__s == c.state && (c.__s = _t({}, c.__s)),
          _t(c.__s, z.getDerivedStateFromProps(g, c.__s))),
        (p = c.props),
        (y = c.state),
        (c.__v = n),
        d)
      )
        (w &&
          z.getDerivedStateFromProps == null &&
          c.componentWillMount != null &&
          c.componentWillMount(),
          w && c.componentDidMount != null && c.__h.push(c.componentDidMount))
      else {
        if (
          (w &&
            z.getDerivedStateFromProps == null &&
            g !== p &&
            c.componentWillReceiveProps != null &&
            c.componentWillReceiveProps(g, x),
          (!c.__e &&
            c.shouldComponentUpdate != null &&
            c.shouldComponentUpdate(g, c.__s, x) === !1) ||
            n.__v == r.__v)
        ) {
          for (
            n.__v != r.__v && ((c.props = g), (c.state = c.__s), (c.__d = !1)),
              n.__e = r.__e,
              n.__k = r.__k,
              n.__k.some(function (N) {
                N && (N.__ = n)
              }),
              b = 0;
            b < c._sb.length;
            b++
          )
            c.__h.push(c._sb[b])
          ;((c._sb = []), c.__h.length && s.push(c))
          break t
        }
        ;(c.componentWillUpdate != null && c.componentWillUpdate(g, c.__s, x),
          w &&
            c.componentDidUpdate != null &&
            c.__h.push(function () {
              c.componentDidUpdate(p, y, m)
            }))
      }
      if (((c.context = x), (c.props = g), (c.__P = e), (c.__e = !1), (A = W.__r), (S = 0), w)) {
        for (
          c.state = c.__s, c.__d = !1, A && A(n), h = c.render(c.props, c.state, c.context), M = 0;
          M < c._sb.length;
          M++
        )
          c.__h.push(c._sb[M])
        c._sb = []
      } else
        do ((c.__d = !1), A && A(n), (h = c.render(c.props, c.state, c.context)), (c.state = c.__s))
        while (c.__d && ++S < 25)
      ;((c.state = c.__s),
        c.getChildContext != null && (i = _t(_t({}, i), c.getChildContext())),
        w && !d && c.getSnapshotBeforeUpdate != null && (m = c.getSnapshotBeforeUpdate(p, y)),
        (R = h),
        h != null && h.type === Ze && h.key == null && (R = Gi(h.props.children)),
        (u = Li(e, Ye(R) ? R : [R], n, r, i, o, a, s, u, l, f)),
        (c.base = n.__e),
        (n.__u &= -161),
        c.__h.length && s.push(c),
        _ && (c.__E = c.__ = null))
    } catch (N) {
      if (((n.__v = null), l || a != null))
        if (N.then) {
          for (n.__u |= l ? 160 : 128; u && u.nodeType == 8 && u.nextSibling; ) u = u.nextSibling
          ;((a[a.indexOf(u)] = null), (n.__e = u))
        } else {
          for (O = a.length; O--; ) Fn(a[O])
          An(n)
        }
      else ((n.__e = r.__e), (n.__k = r.__k), N.then || An(n))
      W.__e(N, n, r)
    }
  else
    a == null && n.__v == r.__v
      ? ((n.__k = r.__k), (n.__e = r.__e))
      : (u = n.__e = Hf(r.__e, n, r, i, o, a, s, l, f))
  return ((h = W.diffed) && h(n), 128 & n.__u ? void 0 : u)
}
function An(e) {
  ;(e && e.__c && (e.__c.__e = !0), e && e.__k && e.__k.forEach(An))
}
function qi(e, n, r) {
  for (var i = 0; i < r.length; i++) Ln(r[i], r[++i], r[++i])
  ;(W.__c && W.__c(n, e),
    e.some(function (o) {
      try {
        ;((e = o.__h),
          (o.__h = []),
          e.some(function (a) {
            a.call(o)
          }))
      } catch (a) {
        W.__e(a, o.__v)
      }
    }))
}
function Gi(e) {
  return typeof e != 'object' || e == null || (e.__b && e.__b > 0)
    ? e
    : Ye(e)
      ? e.map(Gi)
      : _t({}, e)
}
function Hf(e, n, r, i, o, a, s, u, l) {
  var f,
    h,
    c,
    d,
    p,
    y,
    m,
    _ = r.props,
    g = n.props,
    w = n.type
  if (
    (w == 'svg'
      ? (o = 'http://www.w3.org/2000/svg')
      : w == 'math'
        ? (o = 'http://www.w3.org/1998/Math/MathML')
        : o || (o = 'http://www.w3.org/1999/xhtml'),
    a != null)
  ) {
    for (f = 0; f < a.length; f++)
      if ((p = a[f]) && 'setAttribute' in p == !!w && (w ? p.localName == w : p.nodeType == 3)) {
        ;((e = p), (a[f] = null))
        break
      }
  }
  if (e == null) {
    if (w == null) return document.createTextNode(g)
    ;((e = document.createElementNS(o, w, g.is && g)),
      u && (W.__m && W.__m(n, a), (u = !1)),
      (a = null))
  }
  if (w == null) _ === g || (u && e.data == g) || (e.data = g)
  else {
    if (((a = a && xe.call(e.childNodes)), (_ = r.props || ge), !u && a != null))
      for (_ = {}, f = 0; f < e.attributes.length; f++) _[(p = e.attributes[f]).name] = p.value
    for (f in _)
      if (((p = _[f]), f != 'children')) {
        if (f == 'dangerouslySetInnerHTML') c = p
        else if (!(f in g)) {
          if ((f == 'value' && 'defaultValue' in g) || (f == 'checked' && 'defaultChecked' in g))
            continue
          Se(e, f, null, p, o)
        }
      }
    for (f in g)
      ((p = g[f]),
        f == 'children'
          ? (d = p)
          : f == 'dangerouslySetInnerHTML'
            ? (h = p)
            : f == 'value'
              ? (y = p)
              : f == 'checked'
                ? (m = p)
                : (u && typeof p != 'function') || _[f] === p || Se(e, f, p, _[f], o))
    if (h)
      (u || (c && (h.__html == c.__html || h.__html == e.innerHTML)) || (e.innerHTML = h.__html),
        (n.__k = []))
    else if (
      (c && (e.innerHTML = ''),
      Li(
        n.type == 'template' ? e.content : e,
        Ye(d) ? d : [d],
        n,
        r,
        i,
        w == 'foreignObject' ? 'http://www.w3.org/1999/xhtml' : o,
        a,
        s,
        a ? a[0] : r.__k && Xt(r, 0),
        u,
        l
      ),
      a != null)
    )
      for (f = a.length; f--; ) Fn(a[f])
    u ||
      ((f = 'value'),
      w == 'progress' && y == null
        ? e.removeAttribute('value')
        : y != null &&
          (y !== e[f] || (w == 'progress' && !y) || (w == 'option' && y != _[f])) &&
          Se(e, f, y, _[f], o),
      (f = 'checked'),
      m != null && m != e[f] && Se(e, f, m, _[f], o))
  }
  return e
}
function Ln(e, n, r) {
  try {
    if (typeof e == 'function') {
      var i = typeof e.__u == 'function'
      ;(i && e.__u(), (i && n == null) || (e.__u = e(n)))
    } else e.current = n
  } catch (o) {
    W.__e(o, r)
  }
}
function Vi(e, n, r) {
  var i, o
  if (
    (W.unmount && W.unmount(e),
    (i = e.ref) && ((i.current && i.current != e.__e) || Ln(i, null, n)),
    (i = e.__c) != null)
  ) {
    if (i.componentWillUnmount)
      try {
        i.componentWillUnmount()
      } catch (a) {
        W.__e(a, n)
      }
    i.base = i.__P = null
  }
  if ((i = e.__k))
    for (o = 0; o < i.length; o++) i[o] && Vi(i[o], n, r || typeof e.type != 'function')
  ;(r || Fn(e.__e), (e.__c = e.__ = e.__e = void 0))
}
function qf(e, n, r) {
  return this.constructor(e, r)
}
function Gf(e, n, r) {
  var i, o, a, s
  ;(n == document && (n = document.documentElement),
    W.__ && W.__(e, n),
    (o = (i = typeof r == 'function') ? null : (r && r.__k) || n.__k),
    (a = []),
    (s = []),
    Un(
      n,
      (e = ((!i && r) || n).__k = Ff(Ze, null, [e])),
      o || ge,
      ge,
      n.namespaceURI,
      !i && r ? [r] : o ? null : n.firstChild ? xe.call(n.childNodes) : null,
      a,
      !i && r ? r : o ? o.__e : n.firstChild,
      i,
      s
    ),
    qi(a, e, s))
}
function Bi(e, n, r) {
  var i,
    o,
    a,
    s,
    u = _t({}, e.props)
  for (a in (e.type && e.type.defaultProps && (s = e.type.defaultProps), n))
    a == 'key'
      ? (i = n[a])
      : a == 'ref'
        ? (o = n[a])
        : (u[a] = n[a] === void 0 && s != null ? s[a] : n[a])
  return (
    arguments.length > 2 && (u.children = arguments.length > 3 ? xe.call(arguments, 2) : r),
    se(e.type, u, i || e.key, o || e.ref, null)
  )
}
;((xe = Fi.slice),
  (W = {
    __e: function (e, n, r, i) {
      for (var o, a, s; (n = n.__); )
        if ((o = n.__c) && !o.__)
          try {
            if (
              ((a = o.constructor) &&
                a.getDerivedStateFromError != null &&
                (o.setState(a.getDerivedStateFromError(e)), (s = o.__d)),
              o.componentDidCatch != null && (o.componentDidCatch(e, i || {}), (s = o.__d)),
              s)
            )
              return (o.__E = o)
          } catch (u) {
            e = u
          }
      throw e
    },
  }),
  (Ni = 0),
  ($i = function (e) {
    return e != null && e.constructor == null
  }),
  (ze.prototype.setState = function (e, n) {
    var r
    ;((r = this.__s != null && this.__s != this.state ? this.__s : (this.__s = _t({}, this.state))),
      typeof e == 'function' && (e = e(_t({}, r), this.props)),
      e && _t(r, e),
      e != null && this.__v && (n && this._sb.push(n), zr(this)))
  }),
  (ze.prototype.forceUpdate = function (e) {
    this.__v && ((this.__e = !0), e && this.__h.push(e), zr(this))
  }),
  (ze.prototype.render = Ze),
  (It = []),
  (Ii = typeof Promise == 'function' ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout),
  (Di = function (e, n) {
    return e.__v.__b - n.__v.__b
  }),
  (He.__r = 0),
  (ji = /(PointerCapture)$|Capture$/i),
  (jn = 0),
  (wn = Nr(!1)),
  (kn = Nr(!0)))
function $r(e, n) {
  ;(n == null || n > e.length) && (n = e.length)
  for (var r = 0, i = Array(n); r < n; r++) i[r] = e[r]
  return i
}
function Vf(e) {
  if (Array.isArray(e)) return e
}
function Bf(e, n, r) {
  return (
    (n = Qf(n)) in e
      ? Object.defineProperty(e, n, { value: r, enumerable: !0, configurable: !0, writable: !0 })
      : (e[n] = r),
    e
  )
}
function Wf(e, n) {
  var r = e == null ? null : (typeof Symbol < 'u' && e[Symbol.iterator]) || e['@@iterator']
  if (r != null) {
    var i,
      o,
      a,
      s,
      u = [],
      l = !0,
      f = !1
    try {
      if (((a = (r = r.call(e)).next), n !== 0))
        for (; !(l = (i = a.call(r)).done) && (u.push(i.value), u.length !== n); l = !0);
    } catch (h) {
      ;((f = !0), (o = h))
    } finally {
      try {
        if (!l && r.return != null && ((s = r.return()), Object(s) !== s)) return
      } finally {
        if (f) throw o
      }
    }
    return u
  }
}
function Xf() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Ir(e, n) {
  var r = Object.keys(e)
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e)
    ;(n &&
      (i = i.filter(function (o) {
        return Object.getOwnPropertyDescriptor(e, o).enumerable
      })),
      r.push.apply(r, i))
  }
  return r
}
function Yf(e) {
  for (var n = 1; n < arguments.length; n++) {
    var r = arguments[n] != null ? arguments[n] : {}
    n % 2
      ? Ir(Object(r), !0).forEach(function (i) {
          Bf(e, i, r[i])
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
        : Ir(Object(r)).forEach(function (i) {
            Object.defineProperty(e, i, Object.getOwnPropertyDescriptor(r, i))
          })
  }
  return e
}
function Zf(e, n) {
  return Vf(e) || Wf(e, n) || Jf(e, n) || Xf()
}
function Kf(e, n) {
  if (typeof e != 'object' || !e) return e
  var r = e[Symbol.toPrimitive]
  if (r !== void 0) {
    var i = r.call(e, n)
    if (typeof i != 'object') return i
    throw new TypeError('@@toPrimitive must return a primitive value.')
  }
  return (n === 'string' ? String : Number)(e)
}
function Qf(e) {
  var n = Kf(e, 'string')
  return typeof n == 'symbol' ? n : n + ''
}
function qe(e) {
  '@babel/helpers - typeof'
  return (
    (qe =
      typeof Symbol == 'function' && typeof Symbol.iterator == 'symbol'
        ? function (n) {
            return typeof n
          }
        : function (n) {
            return n &&
              typeof Symbol == 'function' &&
              n.constructor === Symbol &&
              n !== Symbol.prototype
              ? 'symbol'
              : typeof n
          }),
    qe(e)
  )
}
function Jf(e, n) {
  if (e) {
    if (typeof e == 'string') return $r(e, n)
    var r = {}.toString.call(e).slice(8, -1)
    return (
      r === 'Object' && e.constructor && (r = e.constructor.name),
      r === 'Map' || r === 'Set'
        ? Array.from(e)
        : r === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
          ? $r(e, n)
          : void 0
    )
  }
}
var Cn = function (n) {
    if (qe(n) !== 'object') return n
    var r = Bi(n)
    if (r.props) {
      var i
      ;((r.props = Yf({}, r.props)),
        r != null &&
          (i = r.props) !== null &&
          i !== void 0 &&
          i.children &&
          (r.props.children = Array.isArray(r.props.children)
            ? r.props.children.map(Cn)
            : Cn(r.props.children)))
    }
    return r
  },
  tc = function (n) {
    return $i(Bi(n))
  },
  ec = function (n, r) {
    ;(delete r.__k, Gf(Cn(n), r))
  }
function nc(e, n) {
  n === void 0 && (n = {})
  var r = n.insertAt
  if (!(typeof document > 'u')) {
    var i = document.head || document.getElementsByTagName('head')[0],
      o = document.createElement('style')
    ;((o.type = 'text/css'),
      r === 'top' && i.firstChild ? i.insertBefore(o, i.firstChild) : i.appendChild(o),
      o.styleSheet ? (o.styleSheet.cssText = e) : o.appendChild(document.createTextNode(e)))
  }
}
var rc = `.float-tooltip-kap {
  position: absolute;
  width: max-content; /* prevent shrinking near right edge */
  max-width: max(50%, 150px);
  padding: 3px 5px;
  border-radius: 3px;
  font: 12px sans-serif;
  color: #eee;
  background: rgba(0,0,0,0.6);
  pointer-events: none;
}
`
nc(rc)
var ic = Dn({
  props: {
    content: { default: !1 },
    offsetX: { triggerUpdate: !1 },
    offsetY: { triggerUpdate: !1 },
  },
  init: function (n, r) {
    var i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
      o = i.style,
      a = o === void 0 ? {} : o,
      s = !!n && qe(n) === 'object' && !!n.node && typeof n.node == 'function',
      u = st(s ? n.node() : n)
    ;(u.style('position') === 'static' && u.style('position', 'relative'),
      (r.tooltipEl = u.append('div').attr('class', 'float-tooltip-kap')),
      Object.entries(a).forEach(function (f) {
        var h = Zf(f, 2),
          c = h[0],
          d = h[1]
        return r.tooltipEl.style(c, d)
      }),
      r.tooltipEl.style('left', '-10000px').style('display', 'none'))
    var l = 'tooltip-'.concat(Math.round(Math.random() * 1e12))
    ;((r.mouseInside = !1),
      u.on('mousemove.'.concat(l), function (f) {
        r.mouseInside = !0
        var h = yt(f),
          c = u.node(),
          d = c.offsetWidth,
          p = c.offsetHeight,
          y = [
            r.offsetX === null || r.offsetX === void 0
              ? '-'.concat((h[0] / d) * 100, '%')
              : typeof r.offsetX == 'number'
                ? 'calc(-50% + '.concat(r.offsetX, 'px)')
                : r.offsetX,
            r.offsetY === null || r.offsetY === void 0
              ? p > 130 && p - h[1] < 100
                ? 'calc(-100% - 6px)'
                : '21px'
              : typeof r.offsetY == 'number'
                ? r.offsetY < 0
                  ? 'calc(-100% - '.concat(Math.abs(r.offsetY), 'px)')
                  : ''.concat(r.offsetY, 'px')
                : r.offsetY,
          ]
        ;(r.tooltipEl
          .style('left', h[0] + 'px')
          .style('top', h[1] + 'px')
          .style('transform', 'translate('.concat(y.join(','), ')')),
          r.content && r.tooltipEl.style('display', 'inline'))
      }),
      u.on('mouseover.'.concat(l), function () {
        ;((r.mouseInside = !0), r.content && r.tooltipEl.style('display', 'inline'))
      }),
      u.on('mouseout.'.concat(l), function () {
        ;((r.mouseInside = !1), r.tooltipEl.style('display', 'none'))
      }))
  },
  update: function (n) {
    ;(n.tooltipEl.style('display', n.content && n.mouseInside ? 'inline' : 'none'),
      n.content
        ? n.content instanceof HTMLElement
          ? (n.tooltipEl.text(''),
            n.tooltipEl.append(function () {
              return n.content
            }))
          : typeof n.content == 'string'
            ? n.tooltipEl.html(n.content)
            : tc(n.content)
              ? (n.tooltipEl.text(''), ec(n.content, n.tooltipEl.node()))
              : (n.tooltipEl.style('display', 'none'),
                console.warn(
                  'Tooltip content is invalid, skipping.',
                  n.content,
                  n.content.toString()
                ))
        : n.tooltipEl.text(''))
  },
})
function oc(e, n, r) {
  var i,
    o = 1
  ;(e == null && (e = 0), n == null && (n = 0), r == null && (r = 0))
  function a() {
    var s,
      u = i.length,
      l,
      f = 0,
      h = 0,
      c = 0
    for (s = 0; s < u; ++s) ((l = i[s]), (f += l.x || 0), (h += l.y || 0), (c += l.z || 0))
    for (f = (f / u - e) * o, h = (h / u - n) * o, c = (c / u - r) * o, s = 0; s < u; ++s)
      ((l = i[s]), f && (l.x -= f), h && (l.y -= h), c && (l.z -= c))
  }
  return (
    (a.initialize = function (s) {
      i = s
    }),
    (a.x = function (s) {
      return arguments.length ? ((e = +s), a) : e
    }),
    (a.y = function (s) {
      return arguments.length ? ((n = +s), a) : n
    }),
    (a.z = function (s) {
      return arguments.length ? ((r = +s), a) : r
    }),
    (a.strength = function (s) {
      return arguments.length ? ((o = +s), a) : o
    }),
    a
  )
}
function ac(e) {
  const n = +this._x.call(null, e)
  return Wi(this.cover(n), n, e)
}
function Wi(e, n, r) {
  if (isNaN(n)) return e
  var i,
    o = e._root,
    a = { data: r },
    s = e._x0,
    u = e._x1,
    l,
    f,
    h,
    c,
    d
  if (!o) return ((e._root = a), e)
  for (; o.length; )
    if (((h = n >= (l = (s + u) / 2)) ? (s = l) : (u = l), (i = o), !(o = o[(c = +h)])))
      return ((i[c] = a), e)
  if (((f = +e._x.call(null, o.data)), n === f))
    return ((a.next = o), i ? (i[c] = a) : (e._root = a), e)
  do
    ((i = i ? (i[c] = new Array(2)) : (e._root = new Array(2))),
      (h = n >= (l = (s + u) / 2)) ? (s = l) : (u = l))
  while ((c = +h) == (d = +(f >= l)))
  return ((i[d] = o), (i[c] = a), e)
}
function sc(e) {
  Array.isArray(e) || (e = Array.from(e))
  const n = e.length,
    r = new Float64Array(n)
  let i = 1 / 0,
    o = -1 / 0
  for (let a = 0, s; a < n; ++a)
    isNaN((s = +this._x.call(null, e[a]))) || ((r[a] = s), s < i && (i = s), s > o && (o = s))
  if (i > o) return this
  this.cover(i).cover(o)
  for (let a = 0; a < n; ++a) Wi(this, r[a], e[a])
  return this
}
function uc(e) {
  if (isNaN((e = +e))) return this
  var n = this._x0,
    r = this._x1
  if (isNaN(n)) r = (n = Math.floor(e)) + 1
  else {
    for (var i = r - n || 1, o = this._root, a, s; n > e || e >= r; )
      switch (((s = +(e < n)), (a = new Array(2)), (a[s] = o), (o = a), (i *= 2), s)) {
        case 0:
          r = n + i
          break
        case 1:
          n = r - i
          break
      }
    this._root && this._root.length && (this._root = o)
  }
  return ((this._x0 = n), (this._x1 = r), this)
}
function lc() {
  var e = []
  return (
    this.visit(function (n) {
      if (!n.length)
        do e.push(n.data)
        while ((n = n.next))
    }),
    e
  )
}
function fc(e) {
  return arguments.length
    ? this.cover(+e[0][0]).cover(+e[1][0])
    : isNaN(this._x0)
      ? void 0
      : [[this._x0], [this._x1]]
}
function Ot(e, n, r) {
  ;((this.node = e), (this.x0 = n), (this.x1 = r))
}
function cc(e, n) {
  var r,
    i = this._x0,
    o,
    a,
    s = this._x1,
    u = [],
    l = this._root,
    f,
    h
  for (
    l && u.push(new Ot(l, i, s)), n == null ? (n = 1 / 0) : ((i = e - n), (s = e + n));
    (f = u.pop());

  )
    if (!(!(l = f.node) || (o = f.x0) > s || (a = f.x1) < i))
      if (l.length) {
        var c = (o + a) / 2
        ;(u.push(new Ot(l[1], c, a), new Ot(l[0], o, c)),
          (h = +(e >= c)) &&
            ((f = u[u.length - 1]),
            (u[u.length - 1] = u[u.length - 1 - h]),
            (u[u.length - 1 - h] = f)))
      } else {
        var d = Math.abs(e - +this._x.call(null, l.data))
        d < n && ((n = d), (i = e - d), (s = e + d), (r = l.data))
      }
  return r
}
function hc(e) {
  if (isNaN((l = +this._x.call(null, e)))) return this
  var n,
    r = this._root,
    i,
    o,
    a,
    s = this._x0,
    u = this._x1,
    l,
    f,
    h,
    c,
    d
  if (!r) return this
  if (r.length)
    for (;;) {
      if (((h = l >= (f = (s + u) / 2)) ? (s = f) : (u = f), (n = r), !(r = r[(c = +h)])))
        return this
      if (!r.length) break
      n[(c + 1) & 1] && ((i = n), (d = c))
    }
  for (; r.data !== e; ) if (((o = r), !(r = r.next))) return this
  return (
    (a = r.next) && delete r.next,
    o
      ? (a ? (o.next = a) : delete o.next, this)
      : n
        ? (a ? (n[c] = a) : delete n[c],
          (r = n[0] || n[1]) &&
            r === (n[1] || n[0]) &&
            !r.length &&
            (i ? (i[d] = r) : (this._root = r)),
          this)
        : ((this._root = a), this)
  )
}
function dc(e) {
  for (var n = 0, r = e.length; n < r; ++n) this.remove(e[n])
  return this
}
function pc() {
  return this._root
}
function gc() {
  var e = 0
  return (
    this.visit(function (n) {
      if (!n.length)
        do ++e
        while ((n = n.next))
    }),
    e
  )
}
function yc(e) {
  var n = [],
    r,
    i = this._root,
    o,
    a,
    s
  for (i && n.push(new Ot(i, this._x0, this._x1)); (r = n.pop()); )
    if (!e((i = r.node), (a = r.x0), (s = r.x1)) && i.length) {
      var u = (a + s) / 2
      ;((o = i[1]) && n.push(new Ot(o, u, s)), (o = i[0]) && n.push(new Ot(o, a, u)))
    }
  return this
}
function _c(e) {
  var n = [],
    r = [],
    i
  for (this._root && n.push(new Ot(this._root, this._x0, this._x1)); (i = n.pop()); ) {
    var o = i.node
    if (o.length) {
      var a,
        s = i.x0,
        u = i.x1,
        l = (s + u) / 2
      ;((a = o[0]) && n.push(new Ot(a, s, l)), (a = o[1]) && n.push(new Ot(a, l, u)))
    }
    r.push(i)
  }
  for (; (i = r.pop()); ) e(i.node, i.x0, i.x1)
  return this
}
function vc(e) {
  return e[0]
}
function mc(e) {
  return arguments.length ? ((this._x = e), this) : this._x
}
function Xi(e, n) {
  var r = new Hn(n ?? vc, NaN, NaN)
  return e == null ? r : r.addAll(e)
}
function Hn(e, n, r) {
  ;((this._x = e), (this._x0 = n), (this._x1 = r), (this._root = void 0))
}
function Dr(e) {
  for (var n = { data: e.data }, r = n; (e = e.next); ) r = r.next = { data: e.data }
  return n
}
var et = (Xi.prototype = Hn.prototype)
et.copy = function () {
  var e = new Hn(this._x, this._x0, this._x1),
    n = this._root,
    r,
    i
  if (!n) return e
  if (!n.length) return ((e._root = Dr(n)), e)
  for (r = [{ source: n, target: (e._root = new Array(2)) }]; (n = r.pop()); )
    for (var o = 0; o < 2; ++o)
      (i = n.source[o]) &&
        (i.length
          ? r.push({ source: i, target: (n.target[o] = new Array(2)) })
          : (n.target[o] = Dr(i)))
  return e
}
et.add = ac
et.addAll = sc
et.cover = uc
et.data = lc
et.extent = fc
et.find = cc
et.remove = hc
et.removeAll = dc
et.root = pc
et.size = gc
et.visit = yc
et.visitAfter = _c
et.x = mc
function xc(e) {
  const n = +this._x.call(null, e),
    r = +this._y.call(null, e)
  return Yi(this.cover(n, r), n, r, e)
}
function Yi(e, n, r, i) {
  if (isNaN(n) || isNaN(r)) return e
  var o,
    a = e._root,
    s = { data: i },
    u = e._x0,
    l = e._y0,
    f = e._x1,
    h = e._y1,
    c,
    d,
    p,
    y,
    m,
    _,
    g,
    w
  if (!a) return ((e._root = s), e)
  for (; a.length; )
    if (
      ((m = n >= (c = (u + f) / 2)) ? (u = c) : (f = c),
      (_ = r >= (d = (l + h) / 2)) ? (l = d) : (h = d),
      (o = a),
      !(a = a[(g = (_ << 1) | m)]))
    )
      return ((o[g] = s), e)
  if (((p = +e._x.call(null, a.data)), (y = +e._y.call(null, a.data)), n === p && r === y))
    return ((s.next = a), o ? (o[g] = s) : (e._root = s), e)
  do
    ((o = o ? (o[g] = new Array(4)) : (e._root = new Array(4))),
      (m = n >= (c = (u + f) / 2)) ? (u = c) : (f = c),
      (_ = r >= (d = (l + h) / 2)) ? (l = d) : (h = d))
  while ((g = (_ << 1) | m) === (w = ((y >= d) << 1) | (p >= c)))
  return ((o[w] = a), (o[g] = s), e)
}
function bc(e) {
  var n,
    r,
    i = e.length,
    o,
    a,
    s = new Array(i),
    u = new Array(i),
    l = 1 / 0,
    f = 1 / 0,
    h = -1 / 0,
    c = -1 / 0
  for (r = 0; r < i; ++r)
    isNaN((o = +this._x.call(null, (n = e[r])))) ||
      isNaN((a = +this._y.call(null, n))) ||
      ((s[r] = o),
      (u[r] = a),
      o < l && (l = o),
      o > h && (h = o),
      a < f && (f = a),
      a > c && (c = a))
  if (l > h || f > c) return this
  for (this.cover(l, f).cover(h, c), r = 0; r < i; ++r) Yi(this, s[r], u[r], e[r])
  return this
}
function wc(e, n) {
  if (isNaN((e = +e)) || isNaN((n = +n))) return this
  var r = this._x0,
    i = this._y0,
    o = this._x1,
    a = this._y1
  if (isNaN(r)) ((o = (r = Math.floor(e)) + 1), (a = (i = Math.floor(n)) + 1))
  else {
    for (var s = o - r || 1, u = this._root, l, f; r > e || e >= o || i > n || n >= a; )
      switch (
        ((f = ((n < i) << 1) | (e < r)), (l = new Array(4)), (l[f] = u), (u = l), (s *= 2), f)
      ) {
        case 0:
          ;((o = r + s), (a = i + s))
          break
        case 1:
          ;((r = o - s), (a = i + s))
          break
        case 2:
          ;((o = r + s), (i = a - s))
          break
        case 3:
          ;((r = o - s), (i = a - s))
          break
      }
    this._root && this._root.length && (this._root = u)
  }
  return ((this._x0 = r), (this._y0 = i), (this._x1 = o), (this._y1 = a), this)
}
function kc() {
  var e = []
  return (
    this.visit(function (n) {
      if (!n.length)
        do e.push(n.data)
        while ((n = n.next))
    }),
    e
  )
}
function Ac(e) {
  return arguments.length
    ? this.cover(+e[0][0], +e[0][1]).cover(+e[1][0], +e[1][1])
    : isNaN(this._x0)
      ? void 0
      : [
          [this._x0, this._y0],
          [this._x1, this._y1],
        ]
}
function Q(e, n, r, i, o) {
  ;((this.node = e), (this.x0 = n), (this.y0 = r), (this.x1 = i), (this.y1 = o))
}
function Cc(e, n, r) {
  var i,
    o = this._x0,
    a = this._y0,
    s,
    u,
    l,
    f,
    h = this._x1,
    c = this._y1,
    d = [],
    p = this._root,
    y,
    m
  for (
    p && d.push(new Q(p, o, a, h, c)),
      r == null ? (r = 1 / 0) : ((o = e - r), (a = n - r), (h = e + r), (c = n + r), (r *= r));
    (y = d.pop());

  )
    if (!(!(p = y.node) || (s = y.x0) > h || (u = y.y0) > c || (l = y.x1) < o || (f = y.y1) < a))
      if (p.length) {
        var _ = (s + l) / 2,
          g = (u + f) / 2
        ;(d.push(
          new Q(p[3], _, g, l, f),
          new Q(p[2], s, g, _, f),
          new Q(p[1], _, u, l, g),
          new Q(p[0], s, u, _, g)
        ),
          (m = ((n >= g) << 1) | (e >= _)) &&
            ((y = d[d.length - 1]),
            (d[d.length - 1] = d[d.length - 1 - m]),
            (d[d.length - 1 - m] = y)))
      } else {
        var w = e - +this._x.call(null, p.data),
          C = n - +this._y.call(null, p.data),
          x = w * w + C * C
        if (x < r) {
          var b = Math.sqrt((r = x))
          ;((o = e - b), (a = n - b), (h = e + b), (c = n + b), (i = p.data))
        }
      }
  return i
}
function Sc(e) {
  if (isNaN((h = +this._x.call(null, e))) || isNaN((c = +this._y.call(null, e)))) return this
  var n,
    r = this._root,
    i,
    o,
    a,
    s = this._x0,
    u = this._y0,
    l = this._x1,
    f = this._y1,
    h,
    c,
    d,
    p,
    y,
    m,
    _,
    g
  if (!r) return this
  if (r.length)
    for (;;) {
      if (
        ((y = h >= (d = (s + l) / 2)) ? (s = d) : (l = d),
        (m = c >= (p = (u + f) / 2)) ? (u = p) : (f = p),
        (n = r),
        !(r = r[(_ = (m << 1) | y)]))
      )
        return this
      if (!r.length) break
      ;(n[(_ + 1) & 3] || n[(_ + 2) & 3] || n[(_ + 3) & 3]) && ((i = n), (g = _))
    }
  for (; r.data !== e; ) if (((o = r), !(r = r.next))) return this
  return (
    (a = r.next) && delete r.next,
    o
      ? (a ? (o.next = a) : delete o.next, this)
      : n
        ? (a ? (n[_] = a) : delete n[_],
          (r = n[0] || n[1] || n[2] || n[3]) &&
            r === (n[3] || n[2] || n[1] || n[0]) &&
            !r.length &&
            (i ? (i[g] = r) : (this._root = r)),
          this)
        : ((this._root = a), this)
  )
}
function Mc(e) {
  for (var n = 0, r = e.length; n < r; ++n) this.remove(e[n])
  return this
}
function Tc() {
  return this._root
}
function Pc() {
  var e = 0
  return (
    this.visit(function (n) {
      if (!n.length)
        do ++e
        while ((n = n.next))
    }),
    e
  )
}
function Oc(e) {
  var n = [],
    r,
    i = this._root,
    o,
    a,
    s,
    u,
    l
  for (i && n.push(new Q(i, this._x0, this._y0, this._x1, this._y1)); (r = n.pop()); )
    if (!e((i = r.node), (a = r.x0), (s = r.y0), (u = r.x1), (l = r.y1)) && i.length) {
      var f = (a + u) / 2,
        h = (s + l) / 2
      ;((o = i[3]) && n.push(new Q(o, f, h, u, l)),
        (o = i[2]) && n.push(new Q(o, a, h, f, l)),
        (o = i[1]) && n.push(new Q(o, f, s, u, h)),
        (o = i[0]) && n.push(new Q(o, a, s, f, h)))
    }
  return this
}
function Ec(e) {
  var n = [],
    r = [],
    i
  for (
    this._root && n.push(new Q(this._root, this._x0, this._y0, this._x1, this._y1));
    (i = n.pop());

  ) {
    var o = i.node
    if (o.length) {
      var a,
        s = i.x0,
        u = i.y0,
        l = i.x1,
        f = i.y1,
        h = (s + l) / 2,
        c = (u + f) / 2
      ;((a = o[0]) && n.push(new Q(a, s, u, h, c)),
        (a = o[1]) && n.push(new Q(a, h, u, l, c)),
        (a = o[2]) && n.push(new Q(a, s, c, h, f)),
        (a = o[3]) && n.push(new Q(a, h, c, l, f)))
    }
    r.push(i)
  }
  for (; (i = r.pop()); ) e(i.node, i.x0, i.y0, i.x1, i.y1)
  return this
}
function zc(e) {
  return e[0]
}
function Rc(e) {
  return arguments.length ? ((this._x = e), this) : this._x
}
function Nc(e) {
  return e[1]
}
function $c(e) {
  return arguments.length ? ((this._y = e), this) : this._y
}
function Zi(e, n, r) {
  var i = new qn(n ?? zc, r ?? Nc, NaN, NaN, NaN, NaN)
  return e == null ? i : i.addAll(e)
}
function qn(e, n, r, i, o, a) {
  ;((this._x = e),
    (this._y = n),
    (this._x0 = r),
    (this._y0 = i),
    (this._x1 = o),
    (this._y1 = a),
    (this._root = void 0))
}
function jr(e) {
  for (var n = { data: e.data }, r = n; (e = e.next); ) r = r.next = { data: e.data }
  return n
}
var J = (Zi.prototype = qn.prototype)
J.copy = function () {
  var e = new qn(this._x, this._y, this._x0, this._y0, this._x1, this._y1),
    n = this._root,
    r,
    i
  if (!n) return e
  if (!n.length) return ((e._root = jr(n)), e)
  for (r = [{ source: n, target: (e._root = new Array(4)) }]; (n = r.pop()); )
    for (var o = 0; o < 4; ++o)
      (i = n.source[o]) &&
        (i.length
          ? r.push({ source: i, target: (n.target[o] = new Array(4)) })
          : (n.target[o] = jr(i)))
  return e
}
J.add = xc
J.addAll = bc
J.cover = wc
J.data = kc
J.extent = Ac
J.find = Cc
J.remove = Sc
J.removeAll = Mc
J.root = Tc
J.size = Pc
J.visit = Oc
J.visitAfter = Ec
J.x = Rc
J.y = $c
function Ic(e) {
  const n = +this._x.call(null, e),
    r = +this._y.call(null, e),
    i = +this._z.call(null, e)
  return Ki(this.cover(n, r, i), n, r, i, e)
}
function Ki(e, n, r, i, o) {
  if (isNaN(n) || isNaN(r) || isNaN(i)) return e
  var a,
    s = e._root,
    u = { data: o },
    l = e._x0,
    f = e._y0,
    h = e._z0,
    c = e._x1,
    d = e._y1,
    p = e._z1,
    y,
    m,
    _,
    g,
    w,
    C,
    x,
    b,
    A,
    S,
    M
  if (!s) return ((e._root = u), e)
  for (; s.length; )
    if (
      ((x = n >= (y = (l + c) / 2)) ? (l = y) : (c = y),
      (b = r >= (m = (f + d) / 2)) ? (f = m) : (d = m),
      (A = i >= (_ = (h + p) / 2)) ? (h = _) : (p = _),
      (a = s),
      !(s = s[(S = (A << 2) | (b << 1) | x)]))
    )
      return ((a[S] = u), e)
  if (
    ((g = +e._x.call(null, s.data)),
    (w = +e._y.call(null, s.data)),
    (C = +e._z.call(null, s.data)),
    n === g && r === w && i === C)
  )
    return ((u.next = s), a ? (a[S] = u) : (e._root = u), e)
  do
    ((a = a ? (a[S] = new Array(8)) : (e._root = new Array(8))),
      (x = n >= (y = (l + c) / 2)) ? (l = y) : (c = y),
      (b = r >= (m = (f + d) / 2)) ? (f = m) : (d = m),
      (A = i >= (_ = (h + p) / 2)) ? (h = _) : (p = _))
  while ((S = (A << 2) | (b << 1) | x) === (M = ((C >= _) << 2) | ((w >= m) << 1) | (g >= y)))
  return ((a[M] = s), (a[S] = u), e)
}
function Dc(e) {
  Array.isArray(e) || (e = Array.from(e))
  const n = e.length,
    r = new Float64Array(n),
    i = new Float64Array(n),
    o = new Float64Array(n)
  let a = 1 / 0,
    s = 1 / 0,
    u = 1 / 0,
    l = -1 / 0,
    f = -1 / 0,
    h = -1 / 0
  for (let c = 0, d, p, y, m; c < n; ++c)
    isNaN((p = +this._x.call(null, (d = e[c])))) ||
      isNaN((y = +this._y.call(null, d))) ||
      isNaN((m = +this._z.call(null, d))) ||
      ((r[c] = p),
      (i[c] = y),
      (o[c] = m),
      p < a && (a = p),
      p > l && (l = p),
      y < s && (s = y),
      y > f && (f = y),
      m < u && (u = m),
      m > h && (h = m))
  if (a > l || s > f || u > h) return this
  this.cover(a, s, u).cover(l, f, h)
  for (let c = 0; c < n; ++c) Ki(this, r[c], i[c], o[c], e[c])
  return this
}
function jc(e, n, r) {
  if (isNaN((e = +e)) || isNaN((n = +n)) || isNaN((r = +r))) return this
  var i = this._x0,
    o = this._y0,
    a = this._z0,
    s = this._x1,
    u = this._y1,
    l = this._z1
  if (isNaN(i))
    ((s = (i = Math.floor(e)) + 1), (u = (o = Math.floor(n)) + 1), (l = (a = Math.floor(r)) + 1))
  else {
    for (
      var f = s - i || 1, h = this._root, c, d;
      i > e || e >= s || o > n || n >= u || a > r || r >= l;

    )
      switch (
        ((d = ((r < a) << 2) | ((n < o) << 1) | (e < i)),
        (c = new Array(8)),
        (c[d] = h),
        (h = c),
        (f *= 2),
        d)
      ) {
        case 0:
          ;((s = i + f), (u = o + f), (l = a + f))
          break
        case 1:
          ;((i = s - f), (u = o + f), (l = a + f))
          break
        case 2:
          ;((s = i + f), (o = u - f), (l = a + f))
          break
        case 3:
          ;((i = s - f), (o = u - f), (l = a + f))
          break
        case 4:
          ;((s = i + f), (u = o + f), (a = l - f))
          break
        case 5:
          ;((i = s - f), (u = o + f), (a = l - f))
          break
        case 6:
          ;((s = i + f), (o = u - f), (a = l - f))
          break
        case 7:
          ;((i = s - f), (o = u - f), (a = l - f))
          break
      }
    this._root && this._root.length && (this._root = h)
  }
  return (
    (this._x0 = i),
    (this._y0 = o),
    (this._z0 = a),
    (this._x1 = s),
    (this._y1 = u),
    (this._z1 = l),
    this
  )
}
function Fc() {
  var e = []
  return (
    this.visit(function (n) {
      if (!n.length)
        do e.push(n.data)
        while ((n = n.next))
    }),
    e
  )
}
function Uc(e) {
  return arguments.length
    ? this.cover(+e[0][0], +e[0][1], +e[0][2]).cover(+e[1][0], +e[1][1], +e[1][2])
    : isNaN(this._x0)
      ? void 0
      : [
          [this._x0, this._y0, this._z0],
          [this._x1, this._y1, this._z1],
        ]
}
function G(e, n, r, i, o, a, s) {
  ;((this.node = e),
    (this.x0 = n),
    (this.y0 = r),
    (this.z0 = i),
    (this.x1 = o),
    (this.y1 = a),
    (this.z1 = s))
}
function Lc(e, n, r, i) {
  var o,
    a = this._x0,
    s = this._y0,
    u = this._z0,
    l,
    f,
    h,
    c,
    d,
    p,
    y = this._x1,
    m = this._y1,
    _ = this._z1,
    g = [],
    w = this._root,
    C,
    x
  for (
    w && g.push(new G(w, a, s, u, y, m, _)),
      i == null
        ? (i = 1 / 0)
        : ((a = e - i), (s = n - i), (u = r - i), (y = e + i), (m = n + i), (_ = r + i), (i *= i));
    (C = g.pop());

  )
    if (
      !(
        !(w = C.node) ||
        (l = C.x0) > y ||
        (f = C.y0) > m ||
        (h = C.z0) > _ ||
        (c = C.x1) < a ||
        (d = C.y1) < s ||
        (p = C.z1) < u
      )
    )
      if (w.length) {
        var b = (l + c) / 2,
          A = (f + d) / 2,
          S = (h + p) / 2
        ;(g.push(
          new G(w[7], b, A, S, c, d, p),
          new G(w[6], l, A, S, b, d, p),
          new G(w[5], b, f, S, c, A, p),
          new G(w[4], l, f, S, b, A, p),
          new G(w[3], b, A, h, c, d, S),
          new G(w[2], l, A, h, b, d, S),
          new G(w[1], b, f, h, c, A, S),
          new G(w[0], l, f, h, b, A, S)
        ),
          (x = ((r >= S) << 2) | ((n >= A) << 1) | (e >= b)) &&
            ((C = g[g.length - 1]),
            (g[g.length - 1] = g[g.length - 1 - x]),
            (g[g.length - 1 - x] = C)))
      } else {
        var M = e - +this._x.call(null, w.data),
          R = n - +this._y.call(null, w.data),
          O = r - +this._z.call(null, w.data),
          z = M * M + R * R + O * O
        if (z < i) {
          var N = Math.sqrt((i = z))
          ;((a = e - N),
            (s = n - N),
            (u = r - N),
            (y = e + N),
            (m = n + N),
            (_ = r + N),
            (o = w.data))
        }
      }
  return o
}
const Hc = (e, n, r, i, o, a) => Math.sqrt((e - i) ** 2 + (n - o) ** 2 + (r - a) ** 2)
function qc(e, n, r, i) {
  const o = [],
    a = e - i,
    s = n - i,
    u = r - i,
    l = e + i,
    f = n + i,
    h = r + i
  return (
    this.visit((c, d, p, y, m, _, g) => {
      if (!c.length)
        do {
          const w = c.data
          Hc(e, n, r, this._x(w), this._y(w), this._z(w)) <= i && o.push(w)
        } while ((c = c.next))
      return d > l || p > f || y > h || m < a || _ < s || g < u
    }),
    o
  )
}
function Gc(e) {
  if (
    isNaN((d = +this._x.call(null, e))) ||
    isNaN((p = +this._y.call(null, e))) ||
    isNaN((y = +this._z.call(null, e)))
  )
    return this
  var n,
    r = this._root,
    i,
    o,
    a,
    s = this._x0,
    u = this._y0,
    l = this._z0,
    f = this._x1,
    h = this._y1,
    c = this._z1,
    d,
    p,
    y,
    m,
    _,
    g,
    w,
    C,
    x,
    b,
    A
  if (!r) return this
  if (r.length)
    for (;;) {
      if (
        ((w = d >= (m = (s + f) / 2)) ? (s = m) : (f = m),
        (C = p >= (_ = (u + h) / 2)) ? (u = _) : (h = _),
        (x = y >= (g = (l + c) / 2)) ? (l = g) : (c = g),
        (n = r),
        !(r = r[(b = (x << 2) | (C << 1) | w)]))
      )
        return this
      if (!r.length) break
      ;(n[(b + 1) & 7] ||
        n[(b + 2) & 7] ||
        n[(b + 3) & 7] ||
        n[(b + 4) & 7] ||
        n[(b + 5) & 7] ||
        n[(b + 6) & 7] ||
        n[(b + 7) & 7]) &&
        ((i = n), (A = b))
    }
  for (; r.data !== e; ) if (((o = r), !(r = r.next))) return this
  return (
    (a = r.next) && delete r.next,
    o
      ? (a ? (o.next = a) : delete o.next, this)
      : n
        ? (a ? (n[b] = a) : delete n[b],
          (r = n[0] || n[1] || n[2] || n[3] || n[4] || n[5] || n[6] || n[7]) &&
            r === (n[7] || n[6] || n[5] || n[4] || n[3] || n[2] || n[1] || n[0]) &&
            !r.length &&
            (i ? (i[A] = r) : (this._root = r)),
          this)
        : ((this._root = a), this)
  )
}
function Vc(e) {
  for (var n = 0, r = e.length; n < r; ++n) this.remove(e[n])
  return this
}
function Bc() {
  return this._root
}
function Wc() {
  var e = 0
  return (
    this.visit(function (n) {
      if (!n.length)
        do ++e
        while ((n = n.next))
    }),
    e
  )
}
function Xc(e) {
  var n = [],
    r,
    i = this._root,
    o,
    a,
    s,
    u,
    l,
    f,
    h
  for (
    i && n.push(new G(i, this._x0, this._y0, this._z0, this._x1, this._y1, this._z1));
    (r = n.pop());

  )
    if (
      !e((i = r.node), (a = r.x0), (s = r.y0), (u = r.z0), (l = r.x1), (f = r.y1), (h = r.z1)) &&
      i.length
    ) {
      var c = (a + l) / 2,
        d = (s + f) / 2,
        p = (u + h) / 2
      ;((o = i[7]) && n.push(new G(o, c, d, p, l, f, h)),
        (o = i[6]) && n.push(new G(o, a, d, p, c, f, h)),
        (o = i[5]) && n.push(new G(o, c, s, p, l, d, h)),
        (o = i[4]) && n.push(new G(o, a, s, p, c, d, h)),
        (o = i[3]) && n.push(new G(o, c, d, u, l, f, p)),
        (o = i[2]) && n.push(new G(o, a, d, u, c, f, p)),
        (o = i[1]) && n.push(new G(o, c, s, u, l, d, p)),
        (o = i[0]) && n.push(new G(o, a, s, u, c, d, p)))
    }
  return this
}
function Yc(e) {
  var n = [],
    r = [],
    i
  for (
    this._root &&
    n.push(new G(this._root, this._x0, this._y0, this._z0, this._x1, this._y1, this._z1));
    (i = n.pop());

  ) {
    var o = i.node
    if (o.length) {
      var a,
        s = i.x0,
        u = i.y0,
        l = i.z0,
        f = i.x1,
        h = i.y1,
        c = i.z1,
        d = (s + f) / 2,
        p = (u + h) / 2,
        y = (l + c) / 2
      ;((a = o[0]) && n.push(new G(a, s, u, l, d, p, y)),
        (a = o[1]) && n.push(new G(a, d, u, l, f, p, y)),
        (a = o[2]) && n.push(new G(a, s, p, l, d, h, y)),
        (a = o[3]) && n.push(new G(a, d, p, l, f, h, y)),
        (a = o[4]) && n.push(new G(a, s, u, y, d, p, c)),
        (a = o[5]) && n.push(new G(a, d, u, y, f, p, c)),
        (a = o[6]) && n.push(new G(a, s, p, y, d, h, c)),
        (a = o[7]) && n.push(new G(a, d, p, y, f, h, c)))
    }
    r.push(i)
  }
  for (; (i = r.pop()); ) e(i.node, i.x0, i.y0, i.z0, i.x1, i.y1, i.z1)
  return this
}
function Zc(e) {
  return e[0]
}
function Kc(e) {
  return arguments.length ? ((this._x = e), this) : this._x
}
function Qc(e) {
  return e[1]
}
function Jc(e) {
  return arguments.length ? ((this._y = e), this) : this._y
}
function th(e) {
  return e[2]
}
function eh(e) {
  return arguments.length ? ((this._z = e), this) : this._z
}
function Qi(e, n, r, i) {
  var o = new Gn(n ?? Zc, r ?? Qc, i ?? th, NaN, NaN, NaN, NaN, NaN, NaN)
  return e == null ? o : o.addAll(e)
}
function Gn(e, n, r, i, o, a, s, u, l) {
  ;((this._x = e),
    (this._y = n),
    (this._z = r),
    (this._x0 = i),
    (this._y0 = o),
    (this._z0 = a),
    (this._x1 = s),
    (this._y1 = u),
    (this._z1 = l),
    (this._root = void 0))
}
function Fr(e) {
  for (var n = { data: e.data }, r = n; (e = e.next); ) r = r.next = { data: e.data }
  return n
}
var Z = (Qi.prototype = Gn.prototype)
Z.copy = function () {
  var e = new Gn(
      this._x,
      this._y,
      this._z,
      this._x0,
      this._y0,
      this._z0,
      this._x1,
      this._y1,
      this._z1
    ),
    n = this._root,
    r,
    i
  if (!n) return e
  if (!n.length) return ((e._root = Fr(n)), e)
  for (r = [{ source: n, target: (e._root = new Array(8)) }]; (n = r.pop()); )
    for (var o = 0; o < 8; ++o)
      (i = n.source[o]) &&
        (i.length
          ? r.push({ source: i, target: (n.target[o] = new Array(8)) })
          : (n.target[o] = Fr(i)))
  return e
}
Z.add = Ic
Z.addAll = Dc
Z.cover = jc
Z.data = Fc
Z.extent = Uc
Z.find = Lc
Z.findAllWithinRadius = qc
Z.remove = Gc
Z.removeAll = Vc
Z.root = Bc
Z.size = Wc
Z.visit = Xc
Z.visitAfter = Yc
Z.x = Kc
Z.y = Jc
Z.z = eh
function Pt(e) {
  return function () {
    return e
  }
}
function Mt(e) {
  return (e() - 0.5) * 1e-6
}
function nh(e) {
  return e.index
}
function Ur(e, n) {
  var r = e.get(n)
  if (!r) throw new Error('node not found: ' + n)
  return r
}
function rh(e) {
  var n = nh,
    r = d,
    i,
    o = Pt(30),
    a,
    s,
    u,
    l,
    f,
    h,
    c = 1
  e == null && (e = [])
  function d(g) {
    return 1 / Math.min(l[g.source.index], l[g.target.index])
  }
  function p(g) {
    for (var w = 0, C = e.length; w < c; ++w)
      for (var x = 0, b, A, S, M = 0, R = 0, O = 0, z, N; x < C; ++x)
        ((b = e[x]),
          (A = b.source),
          (S = b.target),
          (M = S.x + S.vx - A.x - A.vx || Mt(h)),
          u > 1 && (R = S.y + S.vy - A.y - A.vy || Mt(h)),
          u > 2 && (O = S.z + S.vz - A.z - A.vz || Mt(h)),
          (z = Math.sqrt(M * M + R * R + O * O)),
          (z = ((z - a[x]) / z) * g * i[x]),
          (M *= z),
          (R *= z),
          (O *= z),
          (S.vx -= M * (N = f[x])),
          u > 1 && (S.vy -= R * N),
          u > 2 && (S.vz -= O * N),
          (A.vx += M * (N = 1 - N)),
          u > 1 && (A.vy += R * N),
          u > 2 && (A.vz += O * N))
  }
  function y() {
    if (s) {
      var g,
        w = s.length,
        C = e.length,
        x = new Map(s.map((A, S) => [n(A, S, s), A])),
        b
      for (g = 0, l = new Array(w); g < C; ++g)
        ((b = e[g]),
          (b.index = g),
          typeof b.source != 'object' && (b.source = Ur(x, b.source)),
          typeof b.target != 'object' && (b.target = Ur(x, b.target)),
          (l[b.source.index] = (l[b.source.index] || 0) + 1),
          (l[b.target.index] = (l[b.target.index] || 0) + 1))
      for (g = 0, f = new Array(C); g < C; ++g)
        ((b = e[g]), (f[g] = l[b.source.index] / (l[b.source.index] + l[b.target.index])))
      ;((i = new Array(C)), m(), (a = new Array(C)), _())
    }
  }
  function m() {
    if (s) for (var g = 0, w = e.length; g < w; ++g) i[g] = +r(e[g], g, e)
  }
  function _() {
    if (s) for (var g = 0, w = e.length; g < w; ++g) a[g] = +o(e[g], g, e)
  }
  return (
    (p.initialize = function (g, ...w) {
      ;((s = g),
        (h = w.find(C => typeof C == 'function') || Math.random),
        (u = w.find(C => [1, 2, 3].includes(C)) || 2),
        y())
    }),
    (p.links = function (g) {
      return arguments.length ? ((e = g), y(), p) : e
    }),
    (p.id = function (g) {
      return arguments.length ? ((n = g), p) : n
    }),
    (p.iterations = function (g) {
      return arguments.length ? ((c = +g), p) : c
    }),
    (p.strength = function (g) {
      return arguments.length ? ((r = typeof g == 'function' ? g : Pt(+g)), m(), p) : r
    }),
    (p.distance = function (g) {
      return arguments.length ? ((o = typeof g == 'function' ? g : Pt(+g)), _(), p) : o
    }),
    p
  )
}
const ih = 1664525,
  oh = 1013904223,
  Lr = 4294967296
function ah() {
  let e = 1
  return () => (e = (ih * e + oh) % Lr) / Lr
}
var Hr = 3
function on(e) {
  return e.x
}
function qr(e) {
  return e.y
}
function sh(e) {
  return e.z
}
var uh = 10,
  lh = Math.PI * (3 - Math.sqrt(5)),
  fh = (Math.PI * 20) / (9 + Math.sqrt(221))
function ch(e, n) {
  n = n || 2
  var r = Math.min(Hr, Math.max(1, Math.round(n))),
    i,
    o = 1,
    a = 0.001,
    s = 1 - Math.pow(a, 1 / 300),
    u = 0,
    l = 0.6,
    f = new Map(),
    h = Rn(p),
    c = ve('tick', 'end'),
    d = ah()
  e == null && (e = [])
  function p() {
    ;(y(), c.call('tick', i), o < a && (h.stop(), c.call('end', i)))
  }
  function y(g) {
    var w,
      C = e.length,
      x
    g === void 0 && (g = 1)
    for (var b = 0; b < g; ++b)
      for (
        o += (u - o) * s,
          f.forEach(function (A) {
            A(o)
          }),
          w = 0;
        w < C;
        ++w
      )
        ((x = e[w]),
          x.fx == null ? (x.x += x.vx *= l) : ((x.x = x.fx), (x.vx = 0)),
          r > 1 && (x.fy == null ? (x.y += x.vy *= l) : ((x.y = x.fy), (x.vy = 0))),
          r > 2 && (x.fz == null ? (x.z += x.vz *= l) : ((x.z = x.fz), (x.vz = 0))))
    return i
  }
  function m() {
    for (var g = 0, w = e.length, C; g < w; ++g) {
      if (
        ((C = e[g]),
        (C.index = g),
        C.fx != null && (C.x = C.fx),
        C.fy != null && (C.y = C.fy),
        C.fz != null && (C.z = C.fz),
        isNaN(C.x) || (r > 1 && isNaN(C.y)) || (r > 2 && isNaN(C.z)))
      ) {
        var x = uh * (r > 2 ? Math.cbrt(0.5 + g) : r > 1 ? Math.sqrt(0.5 + g) : g),
          b = g * lh,
          A = g * fh
        r === 1
          ? (C.x = x)
          : r === 2
            ? ((C.x = x * Math.cos(b)), (C.y = x * Math.sin(b)))
            : ((C.x = x * Math.sin(b) * Math.cos(A)),
              (C.y = x * Math.cos(b)),
              (C.z = x * Math.sin(b) * Math.sin(A)))
      }
      ;(isNaN(C.vx) || (r > 1 && isNaN(C.vy)) || (r > 2 && isNaN(C.vz))) &&
        ((C.vx = 0), r > 1 && (C.vy = 0), r > 2 && (C.vz = 0))
    }
  }
  function _(g) {
    return (g.initialize && g.initialize(e, d, r), g)
  }
  return (
    m(),
    (i = {
      tick: y,
      restart: function () {
        return (h.restart(p), i)
      },
      stop: function () {
        return (h.stop(), i)
      },
      numDimensions: function (g) {
        return arguments.length
          ? ((r = Math.min(Hr, Math.max(1, Math.round(g)))), f.forEach(_), i)
          : r
      },
      nodes: function (g) {
        return arguments.length ? ((e = g), m(), f.forEach(_), i) : e
      },
      alpha: function (g) {
        return arguments.length ? ((o = +g), i) : o
      },
      alphaMin: function (g) {
        return arguments.length ? ((a = +g), i) : a
      },
      alphaDecay: function (g) {
        return arguments.length ? ((s = +g), i) : +s
      },
      alphaTarget: function (g) {
        return arguments.length ? ((u = +g), i) : u
      },
      velocityDecay: function (g) {
        return arguments.length ? ((l = 1 - g), i) : 1 - l
      },
      randomSource: function (g) {
        return arguments.length ? ((d = g), f.forEach(_), i) : d
      },
      force: function (g, w) {
        return arguments.length > 1 ? (w == null ? f.delete(g) : f.set(g, _(w)), i) : f.get(g)
      },
      find: function () {
        var g = Array.prototype.slice.call(arguments),
          w = g.shift() || 0,
          C = (r > 1 ? g.shift() : null) || 0,
          x = (r > 2 ? g.shift() : null) || 0,
          b = g.shift() || 1 / 0,
          A = 0,
          S = e.length,
          M,
          R,
          O,
          z,
          N,
          j
        for (b *= b, A = 0; A < S; ++A)
          ((N = e[A]),
            (M = w - N.x),
            (R = C - (N.y || 0)),
            (O = x - (N.z || 0)),
            (z = M * M + R * R + O * O),
            z < b && ((j = N), (b = z)))
        return j
      },
      on: function (g, w) {
        return arguments.length > 1 ? (c.on(g, w), i) : c.on(g)
      },
    })
  )
}
function hh() {
  var e,
    n,
    r,
    i,
    o,
    a = Pt(-30),
    s,
    u = 1,
    l = 1 / 0,
    f = 0.81
  function h(y) {
    var m,
      _ = e.length,
      g = (
        n === 1 ? Xi(e, on) : n === 2 ? Zi(e, on, qr) : n === 3 ? Qi(e, on, qr, sh) : null
      ).visitAfter(d)
    for (o = y, m = 0; m < _; ++m) ((r = e[m]), g.visit(p))
  }
  function c() {
    if (e) {
      var y,
        m = e.length,
        _
      for (s = new Array(m), y = 0; y < m; ++y) ((_ = e[y]), (s[_.index] = +a(_, y, e)))
    }
  }
  function d(y) {
    var m = 0,
      _,
      g,
      w = 0,
      C,
      x,
      b,
      A,
      S = y.length
    if (S) {
      for (C = x = b = A = 0; A < S; ++A)
        (_ = y[A]) &&
          (g = Math.abs(_.value)) &&
          ((m += _.value),
          (w += g),
          (C += g * (_.x || 0)),
          (x += g * (_.y || 0)),
          (b += g * (_.z || 0)))
      ;((m *= Math.sqrt(4 / S)), (y.x = C / w), n > 1 && (y.y = x / w), n > 2 && (y.z = b / w))
    } else {
      ;((_ = y), (_.x = _.data.x), n > 1 && (_.y = _.data.y), n > 2 && (_.z = _.data.z))
      do m += s[_.data.index]
      while ((_ = _.next))
    }
    y.value = m
  }
  function p(y, m, _, g, w) {
    if (!y.value) return !0
    var C = [_, g, w][n - 1],
      x = y.x - r.x,
      b = n > 1 ? y.y - r.y : 0,
      A = n > 2 ? y.z - r.z : 0,
      S = C - m,
      M = x * x + b * b + A * A
    if ((S * S) / f < M)
      return (
        M < l &&
          (x === 0 && ((x = Mt(i)), (M += x * x)),
          n > 1 && b === 0 && ((b = Mt(i)), (M += b * b)),
          n > 2 && A === 0 && ((A = Mt(i)), (M += A * A)),
          M < u && (M = Math.sqrt(u * M)),
          (r.vx += (x * y.value * o) / M),
          n > 1 && (r.vy += (b * y.value * o) / M),
          n > 2 && (r.vz += (A * y.value * o) / M)),
        !0
      )
    if (y.length || M >= l) return
    ;(y.data !== r || y.next) &&
      (x === 0 && ((x = Mt(i)), (M += x * x)),
      n > 1 && b === 0 && ((b = Mt(i)), (M += b * b)),
      n > 2 && A === 0 && ((A = Mt(i)), (M += A * A)),
      M < u && (M = Math.sqrt(u * M)))
    do
      y.data !== r &&
        ((S = (s[y.data.index] * o) / M),
        (r.vx += x * S),
        n > 1 && (r.vy += b * S),
        n > 2 && (r.vz += A * S))
    while ((y = y.next))
  }
  return (
    (h.initialize = function (y, ...m) {
      ;((e = y),
        (i = m.find(_ => typeof _ == 'function') || Math.random),
        (n = m.find(_ => [1, 2, 3].includes(_)) || 2),
        c())
    }),
    (h.strength = function (y) {
      return arguments.length ? ((a = typeof y == 'function' ? y : Pt(+y)), c(), h) : a
    }),
    (h.distanceMin = function (y) {
      return arguments.length ? ((u = y * y), h) : Math.sqrt(u)
    }),
    (h.distanceMax = function (y) {
      return arguments.length ? ((l = y * y), h) : Math.sqrt(l)
    }),
    (h.theta = function (y) {
      return arguments.length ? ((f = y * y), h) : Math.sqrt(f)
    }),
    h
  )
}
function dh(e, n, r, i) {
  var o,
    a,
    s = Pt(0.1),
    u,
    l
  ;(typeof e != 'function' && (e = Pt(+e)),
    n == null && (n = 0),
    r == null && (r = 0),
    i == null && (i = 0))
  function f(c) {
    for (var d = 0, p = o.length; d < p; ++d) {
      var y = o[d],
        m = y.x - n || 1e-6,
        _ = (y.y || 0) - r || 1e-6,
        g = (y.z || 0) - i || 1e-6,
        w = Math.sqrt(m * m + _ * _ + g * g),
        C = ((l[d] - w) * u[d] * c) / w
      ;((y.vx += m * C), a > 1 && (y.vy += _ * C), a > 2 && (y.vz += g * C))
    }
  }
  function h() {
    if (o) {
      var c,
        d = o.length
      for (u = new Array(d), l = new Array(d), c = 0; c < d; ++c)
        ((l[c] = +e(o[c], c, o)), (u[c] = isNaN(l[c]) ? 0 : +s(o[c], c, o)))
    }
  }
  return (
    (f.initialize = function (c, ...d) {
      ;((o = c), (a = d.find(p => [1, 2, 3].includes(p)) || 2), h())
    }),
    (f.strength = function (c) {
      return arguments.length ? ((s = typeof c == 'function' ? c : Pt(+c)), h(), f) : s
    }),
    (f.radius = function (c) {
      return arguments.length ? ((e = typeof c == 'function' ? c : Pt(+c)), h(), f) : e
    }),
    (f.x = function (c) {
      return arguments.length ? ((n = +c), f) : n
    }),
    (f.y = function (c) {
      return arguments.length ? ((r = +c), f) : r
    }),
    (f.z = function (c) {
      return arguments.length ? ((i = +c), f) : i
    }),
    f
  )
}
const { abs: Qt, cos: St, sin: Lt, acos: ph, atan2: Jt, sqrt: zt, pow: ot } = Math
function te(e) {
  return e < 0 ? -ot(-e, 1 / 3) : ot(e, 1 / 3)
}
const Ji = Math.PI,
  Me = 2 * Ji,
  Rt = Ji / 2,
  gh = 1e-6,
  an = Number.MAX_SAFE_INTEGER || 9007199254740991,
  sn = Number.MIN_SAFE_INTEGER || -9007199254740991,
  yh = { x: 0, y: 0, z: 0 },
  P = {
    Tvalues: [
      -0.06405689286260563, 0.06405689286260563, -0.1911188674736163, 0.1911188674736163,
      -0.3150426796961634, 0.3150426796961634, -0.4337935076260451, 0.4337935076260451,
      -0.5454214713888396, 0.5454214713888396, -0.6480936519369755, 0.6480936519369755,
      -0.7401241915785544, 0.7401241915785544, -0.820001985973903, 0.820001985973903,
      -0.8864155270044011, 0.8864155270044011, -0.9382745520027328, 0.9382745520027328,
      -0.9747285559713095, 0.9747285559713095, -0.9951872199970213, 0.9951872199970213,
    ],
    Cvalues: [
      0.12793819534675216, 0.12793819534675216, 0.1258374563468283, 0.1258374563468283,
      0.12167047292780339, 0.12167047292780339, 0.1155056680537256, 0.1155056680537256,
      0.10744427011596563, 0.10744427011596563, 0.09761865210411388, 0.09761865210411388,
      0.08619016153195327, 0.08619016153195327, 0.0733464814110803, 0.0733464814110803,
      0.05929858491543678, 0.05929858491543678, 0.04427743881741981, 0.04427743881741981,
      0.028531388628933663, 0.028531388628933663, 0.0123412297999872, 0.0123412297999872,
    ],
    arcfn: function (e, n) {
      const r = n(e)
      let i = r.x * r.x + r.y * r.y
      return (typeof r.z < 'u' && (i += r.z * r.z), zt(i))
    },
    compute: function (e, n, r) {
      if (e === 0) return ((n[0].t = 0), n[0])
      const i = n.length - 1
      if (e === 1) return ((n[i].t = 1), n[i])
      const o = 1 - e
      let a = n
      if (i === 0) return ((n[0].t = e), n[0])
      if (i === 1) {
        const u = { x: o * a[0].x + e * a[1].x, y: o * a[0].y + e * a[1].y, t: e }
        return (r && (u.z = o * a[0].z + e * a[1].z), u)
      }
      if (i < 4) {
        let u = o * o,
          l = e * e,
          f,
          h,
          c,
          d = 0
        i === 2
          ? ((a = [a[0], a[1], a[2], yh]), (f = u), (h = o * e * 2), (c = l))
          : i === 3 && ((f = u * o), (h = u * e * 3), (c = o * l * 3), (d = e * l))
        const p = {
          x: f * a[0].x + h * a[1].x + c * a[2].x + d * a[3].x,
          y: f * a[0].y + h * a[1].y + c * a[2].y + d * a[3].y,
          t: e,
        }
        return (r && (p.z = f * a[0].z + h * a[1].z + c * a[2].z + d * a[3].z), p)
      }
      const s = JSON.parse(JSON.stringify(n))
      for (; s.length > 1; ) {
        for (let u = 0; u < s.length - 1; u++)
          ((s[u] = {
            x: s[u].x + (s[u + 1].x - s[u].x) * e,
            y: s[u].y + (s[u + 1].y - s[u].y) * e,
          }),
            typeof s[u].z < 'u' && (s[u].z = s[u].z + (s[u + 1].z - s[u].z) * e))
        s.splice(s.length - 1, 1)
      }
      return ((s[0].t = e), s[0])
    },
    computeWithRatios: function (e, n, r, i) {
      const o = 1 - e,
        a = r,
        s = n
      let u = a[0],
        l = a[1],
        f = a[2],
        h = a[3],
        c
      if (((u *= o), (l *= e), s.length === 2))
        return (
          (c = u + l),
          {
            x: (u * s[0].x + l * s[1].x) / c,
            y: (u * s[0].y + l * s[1].y) / c,
            z: i ? (u * s[0].z + l * s[1].z) / c : !1,
            t: e,
          }
        )
      if (((u *= o), (l *= 2 * o), (f *= e * e), s.length === 3))
        return (
          (c = u + l + f),
          {
            x: (u * s[0].x + l * s[1].x + f * s[2].x) / c,
            y: (u * s[0].y + l * s[1].y + f * s[2].y) / c,
            z: i ? (u * s[0].z + l * s[1].z + f * s[2].z) / c : !1,
            t: e,
          }
        )
      if (((u *= o), (l *= 1.5 * o), (f *= 3 * o), (h *= e * e * e), s.length === 4))
        return (
          (c = u + l + f + h),
          {
            x: (u * s[0].x + l * s[1].x + f * s[2].x + h * s[3].x) / c,
            y: (u * s[0].y + l * s[1].y + f * s[2].y + h * s[3].y) / c,
            z: i ? (u * s[0].z + l * s[1].z + f * s[2].z + h * s[3].z) / c : !1,
            t: e,
          }
        )
    },
    derive: function (e, n) {
      const r = []
      for (let i = e, o = i.length, a = o - 1; o > 1; o--, a--) {
        const s = []
        for (let u = 0, l; u < a; u++)
          ((l = { x: a * (i[u + 1].x - i[u].x), y: a * (i[u + 1].y - i[u].y) }),
            n && (l.z = a * (i[u + 1].z - i[u].z)),
            s.push(l))
        ;(r.push(s), (i = s))
      }
      return r
    },
    between: function (e, n, r) {
      return (n <= e && e <= r) || P.approximately(e, n) || P.approximately(e, r)
    },
    approximately: function (e, n, r) {
      return Qt(e - n) <= (r || gh)
    },
    length: function (e) {
      const r = P.Tvalues.length
      let i = 0
      for (let o = 0, a; o < r; o++)
        ((a = 0.5 * P.Tvalues[o] + 0.5), (i += P.Cvalues[o] * P.arcfn(a, e)))
      return 0.5 * i
    },
    map: function (e, n, r, i, o) {
      const a = r - n,
        s = o - i,
        u = e - n,
        l = u / a
      return i + s * l
    },
    lerp: function (e, n, r) {
      const i = { x: n.x + e * (r.x - n.x), y: n.y + e * (r.y - n.y) }
      return (n.z !== void 0 && r.z !== void 0 && (i.z = n.z + e * (r.z - n.z)), i)
    },
    pointToString: function (e) {
      let n = e.x + '/' + e.y
      return (typeof e.z < 'u' && (n += '/' + e.z), n)
    },
    pointsToString: function (e) {
      return '[' + e.map(P.pointToString).join(', ') + ']'
    },
    copy: function (e) {
      return JSON.parse(JSON.stringify(e))
    },
    angle: function (e, n, r) {
      const i = n.x - e.x,
        o = n.y - e.y,
        a = r.x - e.x,
        s = r.y - e.y,
        u = i * s - o * a,
        l = i * a + o * s
      return Jt(u, l)
    },
    round: function (e, n) {
      const r = '' + e,
        i = r.indexOf('.')
      return parseFloat(r.substring(0, i + 1 + n))
    },
    dist: function (e, n) {
      const r = e.x - n.x,
        i = e.y - n.y
      return zt(r * r + i * i)
    },
    closest: function (e, n) {
      let r = ot(2, 63),
        i,
        o
      return (
        e.forEach(function (a, s) {
          ;((o = P.dist(n, a)), o < r && ((r = o), (i = s)))
        }),
        { mdist: r, mpos: i }
      )
    },
    abcratio: function (e, n) {
      if (n !== 2 && n !== 3) return !1
      if (typeof e > 'u') e = 0.5
      else if (e === 0 || e === 1) return e
      const r = ot(e, n) + ot(1 - e, n),
        i = r - 1
      return Qt(i / r)
    },
    projectionratio: function (e, n) {
      if (n !== 2 && n !== 3) return !1
      if (typeof e > 'u') e = 0.5
      else if (e === 0 || e === 1) return e
      const r = ot(1 - e, n),
        i = ot(e, n) + r
      return r / i
    },
    lli8: function (e, n, r, i, o, a, s, u) {
      const l = (e * i - n * r) * (o - s) - (e - r) * (o * u - a * s),
        f = (e * i - n * r) * (a - u) - (n - i) * (o * u - a * s),
        h = (e - r) * (a - u) - (n - i) * (o - s)
      return h == 0 ? !1 : { x: l / h, y: f / h }
    },
    lli4: function (e, n, r, i) {
      const o = e.x,
        a = e.y,
        s = n.x,
        u = n.y,
        l = r.x,
        f = r.y,
        h = i.x,
        c = i.y
      return P.lli8(o, a, s, u, l, f, h, c)
    },
    lli: function (e, n) {
      return P.lli4(e, e.c, n, n.c)
    },
    makeline: function (e, n) {
      return new V(e.x, e.y, (e.x + n.x) / 2, (e.y + n.y) / 2, n.x, n.y)
    },
    findbbox: function (e) {
      let n = an,
        r = an,
        i = sn,
        o = sn
      return (
        e.forEach(function (a) {
          const s = a.bbox()
          ;(n > s.x.min && (n = s.x.min),
            r > s.y.min && (r = s.y.min),
            i < s.x.max && (i = s.x.max),
            o < s.y.max && (o = s.y.max))
        }),
        {
          x: { min: n, mid: (n + i) / 2, max: i, size: i - n },
          y: { min: r, mid: (r + o) / 2, max: o, size: o - r },
        }
      )
    },
    shapeintersections: function (e, n, r, i, o) {
      if (!P.bboxoverlap(n, i)) return []
      const a = [],
        s = [e.startcap, e.forward, e.back, e.endcap],
        u = [r.startcap, r.forward, r.back, r.endcap]
      return (
        s.forEach(function (l) {
          l.virtual ||
            u.forEach(function (f) {
              if (f.virtual) return
              const h = l.intersects(f, o)
              h.length > 0 && ((h.c1 = l), (h.c2 = f), (h.s1 = e), (h.s2 = r), a.push(h))
            })
        }),
        a
      )
    },
    makeshape: function (e, n, r) {
      const i = n.points.length,
        o = e.points.length,
        a = P.makeline(n.points[i - 1], e.points[0]),
        s = P.makeline(e.points[o - 1], n.points[0]),
        u = { startcap: a, forward: e, back: n, endcap: s, bbox: P.findbbox([a, e, n, s]) }
      return (
        (u.intersections = function (l) {
          return P.shapeintersections(u, u.bbox, l, l.bbox, r)
        }),
        u
      )
    },
    getminmax: function (e, n, r) {
      if (!r) return { min: 0, max: 0 }
      let i = an,
        o = sn,
        a,
        s
      ;(r.indexOf(0) === -1 && (r = [0].concat(r)), r.indexOf(1) === -1 && r.push(1))
      for (let u = 0, l = r.length; u < l; u++)
        ((a = r[u]), (s = e.get(a)), s[n] < i && (i = s[n]), s[n] > o && (o = s[n]))
      return { min: i, mid: (i + o) / 2, max: o, size: o - i }
    },
    align: function (e, n) {
      const r = n.p1.x,
        i = n.p1.y,
        o = -Jt(n.p2.y - i, n.p2.x - r),
        a = function (s) {
          return {
            x: (s.x - r) * St(o) - (s.y - i) * Lt(o),
            y: (s.x - r) * Lt(o) + (s.y - i) * St(o),
          }
        }
      return e.map(a)
    },
    roots: function (e, n) {
      n = n || { p1: { x: 0, y: 0 }, p2: { x: 1, y: 0 } }
      const r = e.length - 1,
        i = P.align(e, n),
        o = function (S) {
          return 0 <= S && S <= 1
        }
      if (r === 2) {
        const S = i[0].y,
          M = i[1].y,
          R = i[2].y,
          O = S - 2 * M + R
        if (O !== 0) {
          const z = -zt(M * M - S * R),
            N = -S + M,
            j = -(z + N) / O,
            k = -(-z + N) / O
          return [j, k].filter(o)
        } else if (M !== R && O === 0) return [(2 * M - R) / (2 * M - 2 * R)].filter(o)
        return []
      }
      const a = i[0].y,
        s = i[1].y,
        u = i[2].y,
        l = i[3].y
      let f = -a + 3 * s - 3 * u + l,
        h = 3 * a - 6 * s + 3 * u,
        c = -3 * a + 3 * s,
        d = a
      if (P.approximately(f, 0)) {
        if (P.approximately(h, 0)) return P.approximately(c, 0) ? [] : [-d / c].filter(o)
        const S = zt(c * c - 4 * h * d),
          M = 2 * h
        return [(S - c) / M, (-c - S) / M].filter(o)
      }
      ;((h /= f), (c /= f), (d /= f))
      const p = (3 * c - h * h) / 3,
        y = p / 3,
        m = (2 * h * h * h - 9 * h * c + 27 * d) / 27,
        _ = m / 2,
        g = _ * _ + y * y * y
      let w, C, x, b, A
      if (g < 0) {
        const S = -p / 3,
          M = S * S * S,
          R = zt(M),
          O = -m / (2 * R),
          z = O < -1 ? -1 : O > 1 ? 1 : O,
          N = ph(z),
          j = te(R),
          k = 2 * j
        return (
          (x = k * St(N / 3) - h / 3),
          (b = k * St((N + Me) / 3) - h / 3),
          (A = k * St((N + 2 * Me) / 3) - h / 3),
          [x, b, A].filter(o)
        )
      } else {
        if (g === 0)
          return (
            (w = _ < 0 ? te(-_) : -te(_)),
            (x = 2 * w - h / 3),
            (b = -w - h / 3),
            [x, b].filter(o)
          )
        {
          const S = zt(g)
          return ((w = te(-_ + S)), (C = te(_ + S)), [w - C - h / 3].filter(o))
        }
      }
    },
    droots: function (e) {
      if (e.length === 3) {
        const n = e[0],
          r = e[1],
          i = e[2],
          o = n - 2 * r + i
        if (o !== 0) {
          const a = -zt(r * r - n * i),
            s = -n + r,
            u = -(a + s) / o,
            l = -(-a + s) / o
          return [u, l]
        } else if (r !== i && o === 0) return [(2 * r - i) / (2 * (r - i))]
        return []
      }
      if (e.length === 2) {
        const n = e[0],
          r = e[1]
        return n !== r ? [n / (n - r)] : []
      }
      return []
    },
    curvature: function (e, n, r, i, o) {
      let a,
        s,
        u,
        l,
        f = 0,
        h = 0
      const c = P.compute(e, n),
        d = P.compute(e, r),
        p = c.x * c.x + c.y * c.y
      if (
        (i
          ? ((a = zt(
              ot(c.y * d.z - d.y * c.z, 2) +
                ot(c.z * d.x - d.z * c.x, 2) +
                ot(c.x * d.y - d.x * c.y, 2)
            )),
            (s = ot(p + c.z * c.z, 3 / 2)))
          : ((a = c.x * d.y - c.y * d.x), (s = ot(p, 3 / 2))),
        a === 0 || s === 0)
      )
        return { k: 0, r: 0 }
      if (((f = a / s), (h = s / a), !o)) {
        const y = P.curvature(e - 0.001, n, r, i, !0).k,
          m = P.curvature(e + 0.001, n, r, i, !0).k
        ;((l = (m - f + (f - y)) / 2), (u = (Qt(m - f) + Qt(f - y)) / 2))
      }
      return { k: f, r: h, dk: l, adk: u }
    },
    inflections: function (e) {
      if (e.length < 4) return []
      const n = P.align(e, { p1: e[0], p2: e.slice(-1)[0] }),
        r = n[2].x * n[1].y,
        i = n[3].x * n[1].y,
        o = n[1].x * n[2].y,
        a = n[3].x * n[2].y,
        s = 18 * (-3 * r + 2 * i + 3 * o - a),
        u = 18 * (3 * r - i - 3 * o),
        l = 18 * (o - r)
      if (P.approximately(s, 0)) {
        if (!P.approximately(u, 0)) {
          let d = -l / u
          if (0 <= d && d <= 1) return [d]
        }
        return []
      }
      const f = 2 * s
      if (P.approximately(f, 0)) return []
      const h = u * u - 4 * s * l
      if (h < 0) return []
      const c = Math.sqrt(h)
      return [(c - u) / f, -(u + c) / f].filter(function (d) {
        return 0 <= d && d <= 1
      })
    },
    bboxoverlap: function (e, n) {
      const r = ['x', 'y'],
        i = r.length
      for (let o = 0, a, s, u, l; o < i; o++)
        if (
          ((a = r[o]),
          (s = e[a].mid),
          (u = n[a].mid),
          (l = (e[a].size + n[a].size) / 2),
          Qt(s - u) >= l)
        )
          return !1
      return !0
    },
    expandbox: function (e, n) {
      ;(n.x.min < e.x.min && (e.x.min = n.x.min),
        n.y.min < e.y.min && (e.y.min = n.y.min),
        n.z && n.z.min < e.z.min && (e.z.min = n.z.min),
        n.x.max > e.x.max && (e.x.max = n.x.max),
        n.y.max > e.y.max && (e.y.max = n.y.max),
        n.z && n.z.max > e.z.max && (e.z.max = n.z.max),
        (e.x.mid = (e.x.min + e.x.max) / 2),
        (e.y.mid = (e.y.min + e.y.max) / 2),
        e.z && (e.z.mid = (e.z.min + e.z.max) / 2),
        (e.x.size = e.x.max - e.x.min),
        (e.y.size = e.y.max - e.y.min),
        e.z && (e.z.size = e.z.max - e.z.min))
    },
    pairiteration: function (e, n, r) {
      const i = e.bbox(),
        o = n.bbox(),
        a = 1e5,
        s = r || 0.5
      if (i.x.size + i.y.size < s && o.x.size + o.y.size < s)
        return [(((a * (e._t1 + e._t2)) / 2) | 0) / a + '/' + (((a * (n._t1 + n._t2)) / 2) | 0) / a]
      let u = e.split(0.5),
        l = n.split(0.5),
        f = [
          { left: u.left, right: l.left },
          { left: u.left, right: l.right },
          { left: u.right, right: l.right },
          { left: u.right, right: l.left },
        ]
      f = f.filter(function (c) {
        return P.bboxoverlap(c.left.bbox(), c.right.bbox())
      })
      let h = []
      return (
        f.length === 0 ||
          (f.forEach(function (c) {
            h = h.concat(P.pairiteration(c.left, c.right, s))
          }),
          (h = h.filter(function (c, d) {
            return h.indexOf(c) === d
          }))),
        h
      )
    },
    getccenter: function (e, n, r) {
      const i = n.x - e.x,
        o = n.y - e.y,
        a = r.x - n.x,
        s = r.y - n.y,
        u = i * St(Rt) - o * Lt(Rt),
        l = i * Lt(Rt) + o * St(Rt),
        f = a * St(Rt) - s * Lt(Rt),
        h = a * Lt(Rt) + s * St(Rt),
        c = (e.x + n.x) / 2,
        d = (e.y + n.y) / 2,
        p = (n.x + r.x) / 2,
        y = (n.y + r.y) / 2,
        m = c + u,
        _ = d + l,
        g = p + f,
        w = y + h,
        C = P.lli8(c, d, m, _, p, y, g, w),
        x = P.dist(C, e)
      let b = Jt(e.y - C.y, e.x - C.x),
        A = Jt(n.y - C.y, n.x - C.x),
        S = Jt(r.y - C.y, r.x - C.x),
        M
      return (
        b < S
          ? ((b > A || A > S) && (b += Me), b > S && ((M = S), (S = b), (b = M)))
          : S < A && A < b
            ? ((M = S), (S = b), (b = M))
            : (S += Me),
        (C.s = b),
        (C.e = S),
        (C.r = x),
        C
      )
    },
    numberSort: function (e, n) {
      return e - n
    },
  }
class ue {
  constructor(n) {
    ;((this.curves = []),
      (this._3d = !1),
      n && ((this.curves = n), (this._3d = this.curves[0]._3d)))
  }
  valueOf() {
    return this.toString()
  }
  toString() {
    return (
      '[' +
      this.curves
        .map(function (n) {
          return P.pointsToString(n.points)
        })
        .join(', ') +
      ']'
    )
  }
  addCurve(n) {
    ;(this.curves.push(n), (this._3d = this._3d || n._3d))
  }
  length() {
    return this.curves
      .map(function (n) {
        return n.length()
      })
      .reduce(function (n, r) {
        return n + r
      })
  }
  curve(n) {
    return this.curves[n]
  }
  bbox() {
    const n = this.curves
    for (var r = n[0].bbox(), i = 1; i < n.length; i++) P.expandbox(r, n[i].bbox())
    return r
  }
  offset(n) {
    const r = []
    return (
      this.curves.forEach(function (i) {
        r.push(...i.offset(n))
      }),
      new ue(r)
    )
  }
}
const { abs: ee, min: Gr, max: Vr, cos: _h, sin: vh, acos: mh, sqrt: ne } = Math,
  xh = Math.PI
class V {
  constructor(n) {
    let r = n && n.forEach ? n : Array.from(arguments).slice(),
      i = !1
    if (typeof r[0] == 'object') {
      i = r.length
      const p = []
      ;(r.forEach(function (y) {
        ;['x', 'y', 'z'].forEach(function (m) {
          typeof y[m] < 'u' && p.push(y[m])
        })
      }),
        (r = p))
    }
    let o = !1
    const a = r.length
    if (i) {
      if (i > 4) {
        if (arguments.length !== 1)
          throw new Error('Only new Bezier(point[]) is accepted for 4th and higher order curves')
        o = !0
      }
    } else if (a !== 6 && a !== 8 && a !== 9 && a !== 12 && arguments.length !== 1)
      throw new Error('Only new Bezier(point[]) is accepted for 4th and higher order curves')
    const s = (this._3d = (!o && (a === 9 || a === 12)) || (n && n[0] && typeof n[0].z < 'u')),
      u = (this.points = [])
    for (let p = 0, y = s ? 3 : 2; p < a; p += y) {
      var l = { x: r[p], y: r[p + 1] }
      ;(s && (l.z = r[p + 2]), u.push(l))
    }
    const f = (this.order = u.length - 1),
      h = (this.dims = ['x', 'y'])
    ;(s && h.push('z'), (this.dimlen = h.length))
    const c = P.align(u, { p1: u[0], p2: u[f] }),
      d = P.dist(u[0], u[f])
    ;((this._linear = c.reduce((p, y) => p + ee(y.y), 0) < d / 50),
      (this._lut = []),
      (this._t1 = 0),
      (this._t2 = 1),
      this.update())
  }
  static quadraticFromPoints(n, r, i, o) {
    if ((typeof o > 'u' && (o = 0.5), o === 0)) return new V(r, r, i)
    if (o === 1) return new V(n, r, r)
    const a = V.getABC(2, n, r, i, o)
    return new V(n, a.A, i)
  }
  static cubicFromPoints(n, r, i, o, a) {
    typeof o > 'u' && (o = 0.5)
    const s = V.getABC(3, n, r, i, o)
    typeof a > 'u' && (a = P.dist(r, s.C))
    const u = (a * (1 - o)) / o,
      l = P.dist(n, i),
      f = (i.x - n.x) / l,
      h = (i.y - n.y) / l,
      c = a * f,
      d = a * h,
      p = u * f,
      y = u * h,
      m = { x: r.x - c, y: r.y - d },
      _ = { x: r.x + p, y: r.y + y },
      g = s.A,
      w = { x: g.x + (m.x - g.x) / (1 - o), y: g.y + (m.y - g.y) / (1 - o) },
      C = { x: g.x + (_.x - g.x) / o, y: g.y + (_.y - g.y) / o },
      x = { x: n.x + (w.x - n.x) / o, y: n.y + (w.y - n.y) / o },
      b = { x: i.x + (C.x - i.x) / (1 - o), y: i.y + (C.y - i.y) / (1 - o) }
    return new V(n, x, b, i)
  }
  static getUtils() {
    return P
  }
  getUtils() {
    return V.getUtils()
  }
  static get PolyBezier() {
    return ue
  }
  valueOf() {
    return this.toString()
  }
  toString() {
    return P.pointsToString(this.points)
  }
  toSVG() {
    if (this._3d) return !1
    const n = this.points,
      r = n[0].x,
      i = n[0].y,
      o = ['M', r, i, this.order === 2 ? 'Q' : 'C']
    for (let a = 1, s = n.length; a < s; a++) (o.push(n[a].x), o.push(n[a].y))
    return o.join(' ')
  }
  setRatios(n) {
    if (n.length !== this.points.length) throw new Error('incorrect number of ratio values')
    ;((this.ratios = n), (this._lut = []))
  }
  verify() {
    const n = this.coordDigest()
    n !== this._print && ((this._print = n), this.update())
  }
  coordDigest() {
    return this.points
      .map(function (n, r) {
        return '' + r + n.x + n.y + (n.z ? n.z : 0)
      })
      .join('')
  }
  update() {
    ;((this._lut = []), (this.dpoints = P.derive(this.points, this._3d)), this.computedirection())
  }
  computedirection() {
    const n = this.points,
      r = P.angle(n[0], n[this.order], n[1])
    this.clockwise = r > 0
  }
  length() {
    return P.length(this.derivative.bind(this))
  }
  static getABC(n = 2, r, i, o, a = 0.5) {
    const s = P.projectionratio(a, n),
      u = 1 - s,
      l = { x: s * r.x + u * o.x, y: s * r.y + u * o.y },
      f = P.abcratio(a, n)
    return { A: { x: i.x + (i.x - l.x) / f, y: i.y + (i.y - l.y) / f }, B: i, C: l, S: r, E: o }
  }
  getABC(n, r) {
    r = r || this.get(n)
    let i = this.points[0],
      o = this.points[this.order]
    return V.getABC(this.order, i, r, o, n)
  }
  getLUT(n) {
    if ((this.verify(), (n = n || 100), this._lut.length === n + 1)) return this._lut
    ;((this._lut = []), n++, (this._lut = []))
    for (let r = 0, i, o; r < n; r++)
      ((o = r / (n - 1)), (i = this.compute(o)), (i.t = o), this._lut.push(i))
    return this._lut
  }
  on(n, r) {
    r = r || 5
    const i = this.getLUT(),
      o = []
    for (let a = 0, s, u = 0; a < i.length; a++)
      ((s = i[a]), P.dist(s, n) < r && (o.push(s), (u += a / i.length)))
    return o.length ? (t /= o.length) : !1
  }
  project(n) {
    const r = this.getLUT(),
      i = r.length - 1,
      o = P.closest(r, n),
      a = o.mpos,
      s = (a - 1) / i,
      u = (a + 1) / i,
      l = 0.1 / i
    let f = o.mdist,
      h = s,
      c = h,
      d
    f += 1
    for (let p; h < u + l; h += l)
      ((d = this.compute(h)), (p = P.dist(n, d)), p < f && ((f = p), (c = h)))
    return ((c = c < 0 ? 0 : c > 1 ? 1 : c), (d = this.compute(c)), (d.t = c), (d.d = f), d)
  }
  get(n) {
    return this.compute(n)
  }
  point(n) {
    return this.points[n]
  }
  compute(n) {
    return this.ratios
      ? P.computeWithRatios(n, this.points, this.ratios, this._3d)
      : P.compute(n, this.points, this._3d, this.ratios)
  }
  raise() {
    const n = this.points,
      r = [n[0]],
      i = n.length
    for (let o = 1, a, s; o < i; o++)
      ((a = n[o]),
        (s = n[o - 1]),
        (r[o] = { x: ((i - o) / i) * a.x + (o / i) * s.x, y: ((i - o) / i) * a.y + (o / i) * s.y }))
    return ((r[i] = n[i - 1]), new V(r))
  }
  derivative(n) {
    return P.compute(n, this.dpoints[0], this._3d)
  }
  dderivative(n) {
    return P.compute(n, this.dpoints[1], this._3d)
  }
  align() {
    let n = this.points
    return new V(P.align(n, { p1: n[0], p2: n[n.length - 1] }))
  }
  curvature(n) {
    return P.curvature(n, this.dpoints[0], this.dpoints[1], this._3d)
  }
  inflections() {
    return P.inflections(this.points)
  }
  normal(n) {
    return this._3d ? this.__normal3(n) : this.__normal2(n)
  }
  __normal2(n) {
    const r = this.derivative(n),
      i = ne(r.x * r.x + r.y * r.y)
    return { t: n, x: -r.y / i, y: r.x / i }
  }
  __normal3(n) {
    const r = this.derivative(n),
      i = this.derivative(n + 0.01),
      o = ne(r.x * r.x + r.y * r.y + r.z * r.z),
      a = ne(i.x * i.x + i.y * i.y + i.z * i.z)
    ;((r.x /= o), (r.y /= o), (r.z /= o), (i.x /= a), (i.y /= a), (i.z /= a))
    const s = { x: i.y * r.z - i.z * r.y, y: i.z * r.x - i.x * r.z, z: i.x * r.y - i.y * r.x },
      u = ne(s.x * s.x + s.y * s.y + s.z * s.z)
    ;((s.x /= u), (s.y /= u), (s.z /= u))
    const l = [
      s.x * s.x,
      s.x * s.y - s.z,
      s.x * s.z + s.y,
      s.x * s.y + s.z,
      s.y * s.y,
      s.y * s.z - s.x,
      s.x * s.z - s.y,
      s.y * s.z + s.x,
      s.z * s.z,
    ]
    return {
      t: n,
      x: l[0] * r.x + l[1] * r.y + l[2] * r.z,
      y: l[3] * r.x + l[4] * r.y + l[5] * r.z,
      z: l[6] * r.x + l[7] * r.y + l[8] * r.z,
    }
  }
  hull(n) {
    let r = this.points,
      i = [],
      o = [],
      a = 0
    for (
      o[a++] = r[0], o[a++] = r[1], o[a++] = r[2], this.order === 3 && (o[a++] = r[3]);
      r.length > 1;

    ) {
      i = []
      for (let s = 0, u, l = r.length - 1; s < l; s++)
        ((u = P.lerp(n, r[s], r[s + 1])), (o[a++] = u), i.push(u))
      r = i
    }
    return o
  }
  split(n, r) {
    if (n === 0 && r) return this.split(r).left
    if (r === 1) return this.split(n).right
    const i = this.hull(n),
      o = {
        left: this.order === 2 ? new V([i[0], i[3], i[5]]) : new V([i[0], i[4], i[7], i[9]]),
        right: this.order === 2 ? new V([i[5], i[4], i[2]]) : new V([i[9], i[8], i[6], i[3]]),
        span: i,
      }
    return (
      (o.left._t1 = P.map(0, 0, 1, this._t1, this._t2)),
      (o.left._t2 = P.map(n, 0, 1, this._t1, this._t2)),
      (o.right._t1 = P.map(n, 0, 1, this._t1, this._t2)),
      (o.right._t2 = P.map(1, 0, 1, this._t1, this._t2)),
      r ? ((r = P.map(r, n, 1, 0, 1)), o.right.split(r).left) : o
    )
  }
  extrema() {
    const n = {}
    let r = []
    return (
      this.dims.forEach(
        function (i) {
          let o = function (s) {
              return s[i]
            },
            a = this.dpoints[0].map(o)
          ;((n[i] = P.droots(a)),
            this.order === 3 && ((a = this.dpoints[1].map(o)), (n[i] = n[i].concat(P.droots(a)))),
            (n[i] = n[i].filter(function (s) {
              return s >= 0 && s <= 1
            })),
            (r = r.concat(n[i].sort(P.numberSort))))
        }.bind(this)
      ),
      (n.values = r.sort(P.numberSort).filter(function (i, o) {
        return r.indexOf(i) === o
      })),
      n
    )
  }
  bbox() {
    const n = this.extrema(),
      r = {}
    return (
      this.dims.forEach(
        function (i) {
          r[i] = P.getminmax(this, i, n[i])
        }.bind(this)
      ),
      r
    )
  }
  overlaps(n) {
    const r = this.bbox(),
      i = n.bbox()
    return P.bboxoverlap(r, i)
  }
  offset(n, r) {
    if (typeof r < 'u') {
      const i = this.get(n),
        o = this.normal(n),
        a = { c: i, n: o, x: i.x + o.x * r, y: i.y + o.y * r }
      return (this._3d && (a.z = i.z + o.z * r), a)
    }
    if (this._linear) {
      const i = this.normal(0),
        o = this.points.map(function (a) {
          const s = { x: a.x + n * i.x, y: a.y + n * i.y }
          return (a.z && i.z && (s.z = a.z + n * i.z), s)
        })
      return [new V(o)]
    }
    return this.reduce().map(function (i) {
      return i._linear ? i.offset(n)[0] : i.scale(n)
    })
  }
  simple() {
    if (this.order === 3) {
      const o = P.angle(this.points[0], this.points[3], this.points[1]),
        a = P.angle(this.points[0], this.points[3], this.points[2])
      if ((o > 0 && a < 0) || (o < 0 && a > 0)) return !1
    }
    const n = this.normal(0),
      r = this.normal(1)
    let i = n.x * r.x + n.y * r.y
    return (this._3d && (i += n.z * r.z), ee(mh(i)) < xh / 3)
  }
  reduce() {
    let n,
      r = 0,
      i = 0,
      o = 0.01,
      a,
      s = [],
      u = [],
      l = this.extrema().values
    for (
      l.indexOf(0) === -1 && (l = [0].concat(l)), l.indexOf(1) === -1 && l.push(1), r = l[0], n = 1;
      n < l.length;
      n++
    )
      ((i = l[n]), (a = this.split(r, i)), (a._t1 = r), (a._t2 = i), s.push(a), (r = i))
    return (
      s.forEach(function (f) {
        for (r = 0, i = 0; i <= 1; )
          for (i = r + o; i <= 1 + o; i += o)
            if (((a = f.split(r, i)), !a.simple())) {
              if (((i -= o), ee(r - i) < o)) return []
              ;((a = f.split(r, i)),
                (a._t1 = P.map(r, 0, 1, f._t1, f._t2)),
                (a._t2 = P.map(i, 0, 1, f._t1, f._t2)),
                u.push(a),
                (r = i))
              break
            }
        r < 1 &&
          ((a = f.split(r, 1)), (a._t1 = P.map(r, 0, 1, f._t1, f._t2)), (a._t2 = f._t2), u.push(a))
      }),
      u
    )
  }
  translate(n, r, i) {
    i = typeof i == 'number' ? i : r
    const o = this.order
    let a = this.points.map((s, u) => (1 - u / o) * r + (u / o) * i)
    return new V(this.points.map((s, u) => ({ x: s.x + n.x * a[u], y: s.y + n.y * a[u] })))
  }
  scale(n) {
    const r = this.order
    let i = !1
    if ((typeof n == 'function' && (i = n), i && r === 2)) return this.raise().scale(i)
    const o = this.clockwise,
      a = this.points
    if (this._linear) return this.translate(this.normal(0), i ? i(0) : n, i ? i(1) : n)
    const s = i ? i(0) : n,
      u = i ? i(1) : n,
      l = [this.offset(0, 10), this.offset(1, 10)],
      f = [],
      h = P.lli4(l[0], l[0].c, l[1], l[1].c)
    if (!h) throw new Error('cannot scale this curve. Try reducing it first.')
    return (
      [0, 1].forEach(function (c) {
        const d = (f[c * r] = P.copy(a[c * r]))
        ;((d.x += (c ? u : s) * l[c].n.x), (d.y += (c ? u : s) * l[c].n.y))
      }),
      i
        ? ([0, 1].forEach(function (c) {
            if (!(r === 2 && c)) {
              var d = a[c + 1],
                p = { x: d.x - h.x, y: d.y - h.y },
                y = i ? i((c + 1) / r) : n
              i && !o && (y = -y)
              var m = ne(p.x * p.x + p.y * p.y)
              ;((p.x /= m), (p.y /= m), (f[c + 1] = { x: d.x + y * p.x, y: d.y + y * p.y }))
            }
          }),
          new V(f))
        : ([0, 1].forEach(c => {
            if (r === 2 && c) return
            const d = f[c * r],
              p = this.derivative(c),
              y = { x: d.x + p.x, y: d.y + p.y }
            f[c + 1] = P.lli4(d, y, h, a[c + 1])
          }),
          new V(f))
    )
  }
  outline(n, r, i, o) {
    if (((r = r === void 0 ? n : r), this._linear)) {
      const b = this.normal(0),
        A = this.points[0],
        S = this.points[this.points.length - 1]
      let M, R, O
      ;(i === void 0 && ((i = n), (o = r)),
        (M = { x: A.x + b.x * n, y: A.y + b.y * n }),
        (O = { x: S.x + b.x * i, y: S.y + b.y * i }),
        (R = { x: (M.x + O.x) / 2, y: (M.y + O.y) / 2 }))
      const z = [M, R, O]
      ;((M = { x: A.x - b.x * r, y: A.y - b.y * r }),
        (O = { x: S.x - b.x * o, y: S.y - b.y * o }),
        (R = { x: (M.x + O.x) / 2, y: (M.y + O.y) / 2 }))
      const N = [O, R, M],
        j = P.makeline(N[2], z[0]),
        k = P.makeline(z[2], N[0]),
        E = [j, new V(z), k, new V(N)]
      return new ue(E)
    }
    const a = this.reduce(),
      s = a.length,
      u = []
    let l = [],
      f,
      h = 0,
      c = this.length()
    const d = typeof i < 'u' && typeof o < 'u'
    function p(b, A, S, M, R) {
      return function (O) {
        const z = M / S,
          N = (M + R) / S,
          j = A - b
        return P.map(O, 0, 1, b + z * j, b + N * j)
      }
    }
    ;(a.forEach(function (b) {
      const A = b.length()
      ;(d
        ? (u.push(b.scale(p(n, i, c, h, A))), l.push(b.scale(p(-r, -o, c, h, A))))
        : (u.push(b.scale(n)), l.push(b.scale(-r))),
        (h += A))
    }),
      (l = l
        .map(function (b) {
          return (
            (f = b.points),
            f[3] ? (b.points = [f[3], f[2], f[1], f[0]]) : (b.points = [f[2], f[1], f[0]]),
            b
          )
        })
        .reverse()))
    const y = u[0].points[0],
      m = u[s - 1].points[u[s - 1].points.length - 1],
      _ = l[s - 1].points[l[s - 1].points.length - 1],
      g = l[0].points[0],
      w = P.makeline(_, y),
      C = P.makeline(m, g),
      x = [w].concat(u).concat([C]).concat(l)
    return new ue(x)
  }
  outlineshapes(n, r, i) {
    r = r || n
    const o = this.outline(n, r).curves,
      a = []
    for (let s = 1, u = o.length; s < u / 2; s++) {
      const l = P.makeshape(o[s], o[u - s], i)
      ;((l.startcap.virtual = s > 1), (l.endcap.virtual = s < u / 2 - 1), a.push(l))
    }
    return a
  }
  intersects(n, r) {
    return n
      ? n.p1 && n.p2
        ? this.lineIntersects(n)
        : (n instanceof V && (n = n.reduce()), this.curveintersects(this.reduce(), n, r))
      : this.selfintersects(r)
  }
  lineIntersects(n) {
    const r = Gr(n.p1.x, n.p2.x),
      i = Gr(n.p1.y, n.p2.y),
      o = Vr(n.p1.x, n.p2.x),
      a = Vr(n.p1.y, n.p2.y)
    return P.roots(this.points, n).filter(s => {
      var u = this.get(s)
      return P.between(u.x, r, o) && P.between(u.y, i, a)
    })
  }
  selfintersects(n) {
    const r = this.reduce(),
      i = r.length - 2,
      o = []
    for (let a = 0, s, u, l; a < i; a++)
      ((u = r.slice(a, a + 1)),
        (l = r.slice(a + 2)),
        (s = this.curveintersects(u, l, n)),
        o.push(...s))
    return o
  }
  curveintersects(n, r, i) {
    const o = []
    n.forEach(function (s) {
      r.forEach(function (u) {
        s.overlaps(u) && o.push({ left: s, right: u })
      })
    })
    let a = []
    return (
      o.forEach(function (s) {
        const u = P.pairiteration(s.left, s.right, i)
        u.length > 0 && (a = a.concat(u))
      }),
      a
    )
  }
  arcs(n) {
    return ((n = n || 0.5), this._iterate(n, []))
  }
  _error(n, r, i, o) {
    const a = (o - i) / 4,
      s = this.get(i + a),
      u = this.get(o - a),
      l = P.dist(n, r),
      f = P.dist(n, s),
      h = P.dist(n, u)
    return ee(f - l) + ee(h - l)
  }
  _iterate(n, r) {
    let i = 0,
      o = 1,
      a
    do {
      ;((a = 0), (o = 1))
      let s = this.get(i),
        u,
        l,
        f,
        h,
        c = !1,
        d = !1,
        p,
        y = o,
        m = 1
      do
        if (
          ((d = c),
          (h = f),
          (y = (i + o) / 2),
          (u = this.get(y)),
          (l = this.get(o)),
          (f = P.getccenter(s, u, l)),
          (f.interval = { start: i, end: o }),
          (c = this._error(f, s, i, o) <= n),
          (p = d && !c),
          p || (m = o),
          c)
        ) {
          if (o >= 1) {
            if (((f.interval.end = m = 1), (h = f), o > 1)) {
              let g = { x: f.x + f.r * _h(f.e), y: f.y + f.r * vh(f.e) }
              f.e += P.angle({ x: f.x, y: f.y }, g, this.get(1))
            }
            break
          }
          o = o + (o - i) / 2
        } else o = y
      while (!p && a++ < 100)
      if (a >= 100) break
      ;((h = h || f), r.push(h), (i = m))
    } while (o < 1)
    return r
  }
}
function Sn(e, n) {
  ;(n == null || n > e.length) && (n = e.length)
  for (var r = 0, i = Array(n); r < n; r++) i[r] = e[r]
  return i
}
function bh(e) {
  if (Array.isArray(e)) return e
}
function wh(e) {
  if (Array.isArray(e)) return Sn(e)
}
function kh(e) {
  if ((typeof Symbol < 'u' && e[Symbol.iterator] != null) || e['@@iterator'] != null)
    return Array.from(e)
}
function Ah(e, n) {
  var r = e == null ? null : (typeof Symbol < 'u' && e[Symbol.iterator]) || e['@@iterator']
  if (r != null) {
    var i,
      o,
      a,
      s,
      u = [],
      l = !0,
      f = !1
    try {
      if (((a = (r = r.call(e)).next), n !== 0))
        for (; !(l = (i = a.call(r)).done) && (u.push(i.value), u.length !== n); l = !0);
    } catch (h) {
      ;((f = !0), (o = h))
    } finally {
      try {
        if (!l && r.return != null && ((s = r.return()), Object(s) !== s)) return
      } finally {
        if (f) throw o
      }
    }
    return u
  }
}
function Ch() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Sh() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Mh(e, n) {
  if (e == null) return {}
  var r,
    i,
    o = Th(e, n)
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e)
    for (i = 0; i < a.length; i++)
      ((r = a[i]), n.includes(r) || ({}.propertyIsEnumerable.call(e, r) && (o[r] = e[r])))
  }
  return o
}
function Th(e, n) {
  if (e == null) return {}
  var r = {}
  for (var i in e)
    if ({}.hasOwnProperty.call(e, i)) {
      if (n.includes(i)) continue
      r[i] = e[i]
    }
  return r
}
function Ph(e, n) {
  return bh(e) || Ah(e, n) || to(e, n) || Ch()
}
function Oh(e) {
  return wh(e) || kh(e) || to(e) || Sh()
}
function Eh(e, n) {
  if (typeof e != 'object' || !e) return e
  var r = e[Symbol.toPrimitive]
  if (r !== void 0) {
    var i = r.call(e, n)
    if (typeof i != 'object') return i
    throw new TypeError('@@toPrimitive must return a primitive value.')
  }
  return String(e)
}
function zh(e) {
  var n = Eh(e, 'string')
  return typeof n == 'symbol' ? n : n + ''
}
function to(e, n) {
  if (e) {
    if (typeof e == 'string') return Sn(e, n)
    var r = {}.toString.call(e).slice(8, -1)
    return (
      r === 'Object' && e.constructor && (r = e.constructor.name),
      r === 'Map' || r === 'Set'
        ? Array.from(e)
        : r === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
          ? Sn(e, n)
          : void 0
    )
  }
}
var Rh = function () {
  var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [],
    n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [],
    r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0,
    i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1,
    o = (n instanceof Array ? (n.length ? n : [void 0]) : [n]).map(function (u) {
      return { keyAccessor: u, isProp: !(u instanceof Function) }
    }),
    a = e.reduce(function (u, l) {
      var f = u,
        h = l
      return (
        o.forEach(function (c, d) {
          var p = c.keyAccessor,
            y = c.isProp,
            m
          if (y) {
            var _ = h,
              g = _[p],
              w = Mh(_, [p].map(zh))
            ;((m = g), (h = w))
          } else m = p(h, d)
          d + 1 < o.length
            ? (f.hasOwnProperty(m) || (f[m] = {}), (f = f[m]))
            : r
              ? (f.hasOwnProperty(m) || (f[m] = []), f[m].push(h))
              : (f[m] = h)
        }),
        u
      )
    }, {})
  r instanceof Function &&
    (function u(l) {
      var f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1
      f === o.length
        ? Object.keys(l).forEach(function (h) {
            return (l[h] = r(l[h]))
          })
        : Object.values(l).forEach(function (h) {
            return u(h, f + 1)
          })
    })(a)
  var s = a
  return (
    i &&
      ((s = []),
      (function u(l) {
        var f = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : []
        f.length === o.length
          ? s.push({ keys: f, vals: l })
          : Object.entries(l).forEach(function (h) {
              var c = Ph(h, 2),
                d = c[0],
                p = c[1]
              return u(p, [].concat(Oh(f), [d]))
            })
      })(a),
      n instanceof Array && n.length === 0 && s.length === 1 && (s[0].keys = [])),
    s
  )
}
function Nh(e, n) {
  switch (arguments.length) {
    case 0:
      break
    case 1:
      this.range(e)
      break
    default:
      this.range(n).domain(e)
      break
  }
  return this
}
const Br = Symbol('implicit')
function eo() {
  var e = new dr(),
    n = [],
    r = [],
    i = Br
  function o(a) {
    let s = e.get(a)
    if (s === void 0) {
      if (i !== Br) return i
      e.set(a, (s = n.push(a) - 1))
    }
    return r[s % r.length]
  }
  return (
    (o.domain = function (a) {
      if (!arguments.length) return n.slice()
      ;((n = []), (e = new dr()))
      for (const s of a) e.has(s) || e.set(s, n.push(s) - 1)
      return o
    }),
    (o.range = function (a) {
      return arguments.length ? ((r = Array.from(a)), o) : r.slice()
    }),
    (o.unknown = function (a) {
      return arguments.length ? ((i = a), o) : i
    }),
    (o.copy = function () {
      return eo(n, r).unknown(i)
    }),
    Nh.apply(o, arguments),
    o
  )
}
function $h(e) {
  for (var n = (e.length / 6) | 0, r = new Array(n), i = 0; i < n; )
    r[i] = '#' + e.slice(i * 6, ++i * 6)
  return r
}
const Ih = $h('a6cee31f78b4b2df8a33a02cfb9a99e31a1cfdbf6fff7f00cab2d66a3d9affff99b15928')
function Dh(e, n) {
  n === void 0 && (n = {})
  var r = n.insertAt
  if (!(typeof document > 'u')) {
    var i = document.head || document.getElementsByTagName('head')[0],
      o = document.createElement('style')
    ;((o.type = 'text/css'),
      r === 'top' && i.firstChild ? i.insertBefore(o, i.firstChild) : i.appendChild(o),
      o.styleSheet ? (o.styleSheet.cssText = e) : o.appendChild(document.createTextNode(e)))
  }
}
var jh = `.force-graph-container canvas {
  display: block;
  user-select: none;
  outline: none;
  -webkit-tap-highlight-color: transparent;
}

.force-graph-container .clickable {
  cursor: pointer;
}

.force-graph-container .grabbable {
  cursor: move;
  cursor: grab;
  cursor: -moz-grab;
  cursor: -webkit-grab;
}

.force-graph-container .grabbable:active {
  cursor: grabbing;
  cursor: -moz-grabbing;
  cursor: -webkit-grabbing;
}
`
Dh(jh)
function Mn(e, n) {
  ;(n == null || n > e.length) && (n = e.length)
  for (var r = 0, i = Array(n); r < n; r++) i[r] = e[r]
  return i
}
function Fh(e) {
  if (Array.isArray(e)) return e
}
function Uh(e) {
  if (Array.isArray(e)) return Mn(e)
}
function Wr(e, n, r) {
  if (no()) return Reflect.construct.apply(null, arguments)
  var i = [null]
  i.push.apply(i, n)
  var o = new (e.bind.apply(e, i))()
  return o
}
function ye(e, n, r) {
  return (
    (n = Bh(n)) in e
      ? Object.defineProperty(e, n, { value: r, enumerable: !0, configurable: !0, writable: !0 })
      : (e[n] = r),
    e
  )
}
function no() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}))
  } catch {}
  return (no = function () {
    return !!e
  })()
}
function Lh(e) {
  if ((typeof Symbol < 'u' && e[Symbol.iterator] != null) || e['@@iterator'] != null)
    return Array.from(e)
}
function Hh(e, n) {
  var r = e == null ? null : (typeof Symbol < 'u' && e[Symbol.iterator]) || e['@@iterator']
  if (r != null) {
    var i,
      o,
      a,
      s,
      u = [],
      l = !0,
      f = !1
    try {
      if (((a = (r = r.call(e)).next), n !== 0))
        for (; !(l = (i = a.call(r)).done) && (u.push(i.value), u.length !== n); l = !0);
    } catch (h) {
      ;((f = !0), (o = h))
    } finally {
      try {
        if (!l && r.return != null && ((s = r.return()), Object(s) !== s)) return
      } finally {
        if (f) throw o
      }
    }
    return u
  }
}
function qh() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Gh() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
}
function Xr(e, n) {
  var r = Object.keys(e)
  if (Object.getOwnPropertySymbols) {
    var i = Object.getOwnPropertySymbols(e)
    ;(n &&
      (i = i.filter(function (o) {
        return Object.getOwnPropertyDescriptor(e, o).enumerable
      })),
      r.push.apply(r, i))
  }
  return r
}
function Ht(e) {
  for (var n = 1; n < arguments.length; n++) {
    var r = arguments[n] != null ? arguments[n] : {}
    n % 2
      ? Xr(Object(r), !0).forEach(function (i) {
          ye(e, i, r[i])
        })
      : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r))
        : Xr(Object(r)).forEach(function (i) {
            Object.defineProperty(e, i, Object.getOwnPropertyDescriptor(r, i))
          })
  }
  return e
}
function le(e, n) {
  return Fh(e) || Hh(e, n) || ro(e, n) || qh()
}
function ut(e) {
  return Uh(e) || Lh(e) || ro(e) || Gh()
}
function Vh(e, n) {
  if (typeof e != 'object' || !e) return e
  var r = e[Symbol.toPrimitive]
  if (r !== void 0) {
    var i = r.call(e, n)
    if (typeof i != 'object') return i
    throw new TypeError('@@toPrimitive must return a primitive value.')
  }
  return (n === 'string' ? String : Number)(e)
}
function Bh(e) {
  var n = Vh(e, 'string')
  return typeof n == 'symbol' ? n : n + ''
}
function Tn(e) {
  '@babel/helpers - typeof'
  return (
    (Tn =
      typeof Symbol == 'function' && typeof Symbol.iterator == 'symbol'
        ? function (n) {
            return typeof n
          }
        : function (n) {
            return n &&
              typeof Symbol == 'function' &&
              n.constructor === Symbol &&
              n !== Symbol.prototype
              ? 'symbol'
              : typeof n
          }),
    Tn(e)
  )
}
function ro(e, n) {
  if (e) {
    if (typeof e == 'string') return Mn(e, n)
    var r = {}.toString.call(e).slice(8, -1)
    return (
      r === 'Object' && e.constructor && (r = e.constructor.name),
      r === 'Map' || r === 'Set'
        ? Array.from(e)
        : r === 'Arguments' || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
          ? Mn(e, n)
          : void 0
    )
  }
}
var Wh = eo(Ih)
function Yr(e, n, r) {
  !n ||
    typeof r != 'string' ||
    e
      .filter(function (i) {
        return !i[r]
      })
      .forEach(function (i) {
        i[r] = Wh(n(i))
      })
}
function Xh(e, n) {
  var r = e.nodes,
    i = e.links,
    o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
    a = o.nodeFilter,
    s =
      a === void 0
        ? function () {
            return !0
          }
        : a,
    u = o.onLoopError,
    l =
      u === void 0
        ? function (p) {
            throw 'Invalid DAG structure! Found cycle in node path: '.concat(p.join(' -> '), '.')
          }
        : u,
    f = {}
  ;(r.forEach(function (p) {
    return (f[n(p)] = { data: p, out: [], depth: -1, skip: !s(p) })
  }),
    i.forEach(function (p) {
      var y = p.source,
        m = p.target,
        _ = x(y),
        g = x(m)
      if (!f.hasOwnProperty(_)) throw 'Missing source node with id: '.concat(_)
      if (!f.hasOwnProperty(g)) throw 'Missing target node with id: '.concat(g)
      var w = f[_],
        C = f[g]
      w.out.push(C)
      function x(b) {
        return Tn(b) === 'object' ? n(b) : b
      }
    }))
  var h = []
  d(Object.values(f))
  var c = Object.assign.apply(
    Object,
    [{}].concat(
      ut(
        Object.entries(f)
          .filter(function (p) {
            var y = le(p, 2),
              m = y[1]
            return !m.skip
          })
          .map(function (p) {
            var y = le(p, 2),
              m = y[0],
              _ = y[1]
            return ye({}, m, _.depth)
          })
      )
    )
  )
  return c
  function d(p) {
    for (
      var y = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [],
        m = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0,
        _ = function () {
          var x = p[g]
          if (y.indexOf(x) !== -1) {
            var b = [].concat(ut(y.slice(y.indexOf(x))), [x]).map(function (A) {
              return n(A.data)
            })
            return (
              h.some(function (A) {
                return (
                  A.length === b.length &&
                  A.every(function (S, M) {
                    return S === b[M]
                  })
                )
              }) || (h.push(b), l(b)),
              1
            )
          }
          m > x.depth && ((x.depth = m), d(x.out, [].concat(ut(y), [x]), m + (x.skip ? 0 : 1)))
        },
        g = 0,
        w = p.length;
      g < w;
      g++
    )
      _()
  }
}
var Yh = 2,
  K = function (n, r) {
    return r.onNeedsRedraw && r.onNeedsRedraw()
  },
  Zr = function (n, r) {
    if (!r.isShadow) {
      var i = q(r.linkDirectionalParticles)
      r.graphData.links.forEach(function (o) {
        var a = Math.round(Math.abs(i(o)))
        a
          ? (o.__photons = ut(Array(a)).map(function () {
              return {}
            }))
          : delete o.__photons
      })
    }
  },
  Ge = Dn({
    props: {
      graphData: {
        default: { nodes: [], links: [] },
        onChange: function (n, r) {
          ;((r.engineRunning = !1), Zr(n, r))
        },
      },
      dagMode: {
        onChange: function (n, r) {
          !n &&
            (r.graphData.nodes || []).forEach(function (i) {
              return (i.fx = i.fy = void 0)
            })
        },
      },
      dagLevelDistance: {},
      dagNodeFilter: {
        default: function (n) {
          return !0
        },
      },
      onDagError: { triggerUpdate: !1 },
      nodeRelSize: { default: 4, triggerUpdate: !1, onChange: K },
      nodeId: { default: 'id' },
      nodeVal: { default: 'val', triggerUpdate: !1, onChange: K },
      nodeColor: { default: 'color', triggerUpdate: !1, onChange: K },
      nodeAutoColorBy: {},
      nodeCanvasObject: { triggerUpdate: !1, onChange: K },
      nodeCanvasObjectMode: {
        default: function () {
          return 'replace'
        },
        triggerUpdate: !1,
        onChange: K,
      },
      nodeVisibility: { default: !0, triggerUpdate: !1, onChange: K },
      linkSource: { default: 'source' },
      linkTarget: { default: 'target' },
      linkVisibility: { default: !0, triggerUpdate: !1, onChange: K },
      linkColor: { default: 'color', triggerUpdate: !1, onChange: K },
      linkAutoColorBy: {},
      linkLineDash: { triggerUpdate: !1, onChange: K },
      linkWidth: { default: 1, triggerUpdate: !1, onChange: K },
      linkCurvature: { default: 0, triggerUpdate: !1, onChange: K },
      linkCanvasObject: { triggerUpdate: !1, onChange: K },
      linkCanvasObjectMode: {
        default: function () {
          return 'replace'
        },
        triggerUpdate: !1,
        onChange: K,
      },
      linkDirectionalArrowLength: { default: 0, triggerUpdate: !1, onChange: K },
      linkDirectionalArrowColor: { triggerUpdate: !1, onChange: K },
      linkDirectionalArrowRelPos: { default: 0.5, triggerUpdate: !1, onChange: K },
      linkDirectionalParticles: { default: 0, triggerUpdate: !1, onChange: Zr },
      linkDirectionalParticleSpeed: { default: 0.01, triggerUpdate: !1 },
      linkDirectionalParticleOffset: { default: 0, triggerUpdate: !1 },
      linkDirectionalParticleWidth: { default: 4, triggerUpdate: !1 },
      linkDirectionalParticleColor: { triggerUpdate: !1 },
      linkDirectionalParticleCanvasObject: { triggerUpdate: !1 },
      globalScale: { default: 1, triggerUpdate: !1 },
      d3AlphaMin: { default: 0, triggerUpdate: !1 },
      d3AlphaDecay: {
        default: 0.0228,
        triggerUpdate: !1,
        onChange: function (n, r) {
          r.forceLayout.alphaDecay(n)
        },
      },
      d3AlphaTarget: {
        default: 0,
        triggerUpdate: !1,
        onChange: function (n, r) {
          r.forceLayout.alphaTarget(n)
        },
      },
      d3VelocityDecay: {
        default: 0.4,
        triggerUpdate: !1,
        onChange: function (n, r) {
          r.forceLayout.velocityDecay(n)
        },
      },
      warmupTicks: { default: 0, triggerUpdate: !1 },
      cooldownTicks: { default: 1 / 0, triggerUpdate: !1 },
      cooldownTime: { default: 15e3, triggerUpdate: !1 },
      onUpdate: { default: function () {}, triggerUpdate: !1 },
      onFinishUpdate: { default: function () {}, triggerUpdate: !1 },
      onEngineTick: { default: function () {}, triggerUpdate: !1 },
      onEngineStop: { default: function () {}, triggerUpdate: !1 },
      onNeedsRedraw: { triggerUpdate: !1 },
      isShadow: { default: !1, triggerUpdate: !1 },
    },
    methods: {
      d3Force: function (n, r, i) {
        return i === void 0 ? n.forceLayout.force(r) : (n.forceLayout.force(r, i), this)
      },
      d3ReheatSimulation: function (n) {
        return (n.forceLayout.alpha(1), this.resetCountdown(), this)
      },
      resetCountdown: function (n) {
        return ((n.cntTicks = 0), (n.startTickTime = new Date()), (n.engineRunning = !0), this)
      },
      isEngineRunning: function (n) {
        return !!n.engineRunning
      },
      tickFrame: function (n) {
        return (!n.isShadow && r(), o(), !n.isShadow && a(), !n.isShadow && s(), i(), this)
        function r() {
          n.engineRunning &&
            (++n.cntTicks > n.cooldownTicks ||
            new Date() - n.startTickTime > n.cooldownTime ||
            (n.d3AlphaMin > 0 && n.forceLayout.alpha() < n.d3AlphaMin)
              ? ((n.engineRunning = !1), n.onEngineStop())
              : (n.forceLayout.tick(), n.onEngineTick()))
        }
        function i() {
          var u = q(n.nodeVisibility),
            l = q(n.nodeVal),
            f = q(n.nodeColor),
            h = q(n.nodeCanvasObjectMode),
            c = n.ctx,
            d = n.isShadow / n.globalScale,
            p = n.graphData.nodes.filter(u)
          ;(c.save(),
            p.forEach(function (y) {
              var m = h(y)
              if (
                n.nodeCanvasObject &&
                (m === 'before' || m === 'replace') &&
                (n.nodeCanvasObject(y, c, n.globalScale), m === 'replace')
              ) {
                c.restore()
                return
              }
              var _ = Math.sqrt(Math.max(0, l(y) || 1)) * n.nodeRelSize + d
              ;(c.beginPath(),
                c.arc(y.x, y.y, _, 0, 2 * Math.PI, !1),
                (c.fillStyle = f(y) || 'rgba(31, 120, 180, 0.92)'),
                c.fill(),
                n.nodeCanvasObject && m === 'after' && n.nodeCanvasObject(y, n.ctx, n.globalScale))
            }),
            c.restore())
        }
        function o() {
          var u = q(n.linkVisibility),
            l = q(n.linkColor),
            f = q(n.linkWidth),
            h = q(n.linkLineDash),
            c = q(n.linkCurvature),
            d = q(n.linkCanvasObjectMode),
            p = n.ctx,
            y = n.isShadow * 2,
            m = n.graphData.links.filter(u)
          m.forEach(A)
          var _ = [],
            g = [],
            w = m
          if (n.linkCanvasObject) {
            var C = [],
              x = []
            ;(m.forEach(function (S) {
              return ({ before: _, after: g, replace: C }[d(S)] || x).push(S)
            }),
              (w = [].concat(ut(_), g, x)),
              (_ = _.concat(C)))
          }
          ;(p.save(),
            _.forEach(function (S) {
              return n.linkCanvasObject(S, p, n.globalScale)
            }),
            p.restore())
          var b = Rh(w, [l, f, h])
          ;(p.save(),
            Object.entries(b).forEach(function (S) {
              var M = le(S, 2),
                R = M[0],
                O = M[1],
                z = !R || R === 'undefined' ? 'rgba(0,0,0,0.15)' : R
              Object.entries(O).forEach(function (N) {
                var j = le(N, 2),
                  k = j[0],
                  E = j[1],
                  T = (k || 1) / n.globalScale + y
                Object.entries(E).forEach(function ($) {
                  var D = le($, 2)
                  D[0]
                  var F = D[1],
                    U = h(F[0])
                  ;(p.beginPath(),
                    F.forEach(function (L) {
                      var H = L.source,
                        Y = L.target
                      if (!(!H || !Y || !H.hasOwnProperty('x') || !Y.hasOwnProperty('x'))) {
                        p.moveTo(H.x, H.y)
                        var X = L.__controlPoints
                        X
                          ? p[X.length === 2 ? 'quadraticCurveTo' : 'bezierCurveTo'].apply(
                              p,
                              ut(X).concat([Y.x, Y.y])
                            )
                          : p.lineTo(Y.x, Y.y)
                      }
                    }),
                    (p.strokeStyle = z),
                    (p.lineWidth = T),
                    p.setLineDash(U || []),
                    p.stroke())
                })
              })
            }),
            p.restore(),
            p.save(),
            g.forEach(function (S) {
              return n.linkCanvasObject(S, p, n.globalScale)
            }),
            p.restore())
          function A(S) {
            var M = c(S)
            if (!M) {
              S.__controlPoints = null
              return
            }
            var R = S.source,
              O = S.target
            if (!(!R || !O || !R.hasOwnProperty('x') || !O.hasOwnProperty('x'))) {
              var z = Math.sqrt(Math.pow(O.x - R.x, 2) + Math.pow(O.y - R.y, 2))
              if (z > 0) {
                var N = Math.atan2(O.y - R.y, O.x - R.x),
                  j = z * M,
                  k = {
                    x: (R.x + O.x) / 2 + j * Math.cos(N - Math.PI / 2),
                    y: (R.y + O.y) / 2 + j * Math.sin(N - Math.PI / 2),
                  }
                S.__controlPoints = [k.x, k.y]
              } else {
                var E = M * 70
                S.__controlPoints = [O.x, O.y - E, O.x + E, O.y]
              }
            }
          }
        }
        function a() {
          var u = 1.6,
            l = 0.2,
            f = q(n.linkDirectionalArrowLength),
            h = q(n.linkDirectionalArrowRelPos),
            c = q(n.linkVisibility),
            d = q(n.linkDirectionalArrowColor || n.linkColor),
            p = q(n.nodeVal),
            y = n.ctx
          ;(y.save(),
            n.graphData.links.filter(c).forEach(function (m) {
              var _ = f(m)
              if (!(!_ || _ < 0)) {
                var g = m.source,
                  w = m.target
                if (!(!g || !w || !g.hasOwnProperty('x') || !w.hasOwnProperty('x'))) {
                  var C = Math.sqrt(Math.max(0, p(g) || 1)) * n.nodeRelSize,
                    x = Math.sqrt(Math.max(0, p(w) || 1)) * n.nodeRelSize,
                    b = Math.min(1, Math.max(0, h(m))),
                    A = d(m) || 'rgba(0,0,0,0.28)',
                    S = _ / u / 2,
                    M =
                      m.__controlPoints &&
                      Wr(V, [g.x, g.y].concat(ut(m.__controlPoints), [w.x, w.y])),
                    R = M
                      ? function (T) {
                          return M.get(T)
                        }
                      : function (T) {
                          return { x: g.x + (w.x - g.x) * T || 0, y: g.y + (w.y - g.y) * T || 0 }
                        },
                    O = M ? M.length() : Math.sqrt(Math.pow(w.x - g.x, 2) + Math.pow(w.y - g.y, 2)),
                    z = C + _ + (O - C - x - _) * b,
                    N = R(z / O),
                    j = R((z - _) / O),
                    k = R((z - _ * (1 - l)) / O),
                    E = Math.atan2(N.y - j.y, N.x - j.x) - Math.PI / 2
                  ;(y.beginPath(),
                    y.moveTo(N.x, N.y),
                    y.lineTo(j.x + S * Math.cos(E), j.y + S * Math.sin(E)),
                    y.lineTo(k.x, k.y),
                    y.lineTo(j.x - S * Math.cos(E), j.y - S * Math.sin(E)),
                    (y.fillStyle = A),
                    y.fill())
                }
              }
            }),
            y.restore())
        }
        function s() {
          var u = q(n.linkDirectionalParticles),
            l = q(n.linkDirectionalParticleSpeed),
            f = q(n.linkDirectionalParticleOffset),
            h = q(n.linkDirectionalParticleWidth),
            c = q(n.linkVisibility),
            d = q(n.linkDirectionalParticleColor || n.linkColor),
            p = n.ctx
          ;(p.save(),
            n.graphData.links.filter(c).forEach(function (y) {
              var m = u(y)
              if (!(!y.hasOwnProperty('__photons') || !y.__photons.length)) {
                var _ = y.source,
                  g = y.target
                if (!(!_ || !g || !_.hasOwnProperty('x') || !g.hasOwnProperty('x'))) {
                  var w = l(y),
                    C = Math.abs(f(y)),
                    x = y.__photons || [],
                    b = Math.max(0, h(y) / 2) / Math.sqrt(n.globalScale),
                    A = d(y) || 'rgba(0,0,0,0.28)'
                  p.fillStyle = A
                  var S = y.__controlPoints
                      ? Wr(V, [_.x, _.y].concat(ut(y.__controlPoints), [g.x, g.y]))
                      : null,
                    M = 0,
                    R = !1
                  ;(x.forEach(function (O) {
                    var z = !!O.__singleHop
                    if (
                      (O.hasOwnProperty('__progressRatio') ||
                        (O.__progressRatio = z ? 0 : (M + C) / m),
                      !z && M++,
                      (O.__progressRatio += w),
                      O.__progressRatio >= 1)
                    )
                      if (!z) O.__progressRatio = O.__progressRatio % 1
                      else {
                        R = !0
                        return
                      }
                    var N = O.__progressRatio,
                      j = S
                        ? S.get(N)
                        : { x: _.x + (g.x - _.x) * N || 0, y: _.y + (g.y - _.y) * N || 0 }
                    n.linkDirectionalParticleCanvasObject
                      ? n.linkDirectionalParticleCanvasObject(j.x, j.y, y, p, n.globalScale)
                      : (p.beginPath(), p.arc(j.x, j.y, b, 0, 2 * Math.PI, !1), p.fill())
                  }),
                    R &&
                      (y.__photons = y.__photons.filter(function (O) {
                        return !O.__singleHop || O.__progressRatio <= 1
                      })))
                }
              }
            }),
            p.restore())
        }
      },
      emitParticle: function (n, r) {
        return (
          r && (!r.__photons && (r.__photons = []), r.__photons.push({ __singleHop: !0 })),
          this
        )
      },
    },
    stateInit: function () {
      return {
        forceLayout: ch()
          .force('link', rh())
          .force('charge', hh())
          .force('center', oc())
          .force('dagRadial', null)
          .stop(),
        engineRunning: !1,
      }
    },
    init: function (n, r) {
      r.ctx = n
    },
    update: function (n, r) {
      ;((n.engineRunning = !1),
        n.onUpdate(),
        n.nodeAutoColorBy !== null && Yr(n.graphData.nodes, q(n.nodeAutoColorBy), n.nodeColor),
        n.linkAutoColorBy !== null && Yr(n.graphData.links, q(n.linkAutoColorBy), n.linkColor),
        n.graphData.links.forEach(function (d) {
          ;((d.source = d[n.linkSource]), (d.target = d[n.linkTarget]))
        }),
        n.forceLayout.stop().alpha(1).nodes(n.graphData.nodes))
      var i = n.forceLayout.force('link')
      i &&
        i
          .id(function (d) {
            return d[n.nodeId]
          })
          .links(n.graphData.links)
      var o =
          n.dagMode &&
          Xh(
            n.graphData,
            function (d) {
              return d[n.nodeId]
            },
            { nodeFilter: n.dagNodeFilter, onLoopError: n.onDagError || void 0 }
          ),
        a = Math.max.apply(Math, ut(Object.values(o || []))),
        s =
          n.dagLevelDistance ||
          (n.graphData.nodes.length / (a || 1)) *
            Yh *
            (['radialin', 'radialout'].indexOf(n.dagMode) !== -1 ? 0.7 : 1)
      if (['lr', 'rl', 'td', 'bu'].includes(r.dagMode)) {
        var u = ['lr', 'rl'].includes(r.dagMode) ? 'fx' : 'fy'
        n.graphData.nodes.filter(n.dagNodeFilter).forEach(function (d) {
          return delete d[u]
        })
      }
      if (['lr', 'rl', 'td', 'bu'].includes(n.dagMode)) {
        var l = ['rl', 'bu'].includes(n.dagMode),
          f = function (p) {
            return (o[p[n.nodeId]] - a / 2) * s * (l ? -1 : 1)
          },
          h = ['lr', 'rl'].includes(n.dagMode) ? 'fx' : 'fy'
        n.graphData.nodes.filter(n.dagNodeFilter).forEach(function (d) {
          return (d[h] = f(d))
        })
      }
      n.forceLayout.force(
        'dagRadial',
        ['radialin', 'radialout'].indexOf(n.dagMode) !== -1
          ? dh(function (d) {
              var p = o[d[n.nodeId]] || -1
              return (n.dagMode === 'radialin' ? a - p : p) * s
            }).strength(function (d) {
              return n.dagNodeFilter(d) ? 1 : 0
            })
          : null
      )
      for (
        var c = 0;
        c < n.warmupTicks && !(n.d3AlphaMin > 0 && n.forceLayout.alpha() < n.d3AlphaMin);
        c++
      )
        n.forceLayout.tick()
      ;(this.resetCountdown(), n.onFinishUpdate())
    },
  })
function io(e, n) {
  var r = e instanceof Array ? e : [e],
    i = new n()
  return (
    i._destructor && i._destructor(),
    {
      linkProp: function (a) {
        return {
          default: i[a](),
          onChange: function (u, l) {
            r.forEach(function (f) {
              return l[f][a](u)
            })
          },
          triggerUpdate: !1,
        }
      },
      linkMethod: function (a) {
        return function (s) {
          for (var u = arguments.length, l = new Array(u > 1 ? u - 1 : 0), f = 1; f < u; f++)
            l[f - 1] = arguments[f]
          var h = []
          return (
            r.forEach(function (c) {
              var d = s[c],
                p = d[a].apply(d, l)
              p !== d && h.push(p)
            }),
            h.length ? h[0] : this
          )
        }
      },
    }
  )
}
var Zh = 800,
  Kh = 4,
  Qh = 5,
  oo = io('forceGraph', Ge),
  Jh = io(['forceGraph', 'shadowGraph'], Ge),
  td = Object.assign.apply(
    Object,
    ut(
      [
        'nodeColor',
        'nodeAutoColorBy',
        'nodeCanvasObject',
        'nodeCanvasObjectMode',
        'linkColor',
        'linkAutoColorBy',
        'linkLineDash',
        'linkWidth',
        'linkCanvasObject',
        'linkCanvasObjectMode',
        'linkDirectionalArrowLength',
        'linkDirectionalArrowColor',
        'linkDirectionalArrowRelPos',
        'linkDirectionalParticles',
        'linkDirectionalParticleSpeed',
        'linkDirectionalParticleOffset',
        'linkDirectionalParticleWidth',
        'linkDirectionalParticleColor',
        'linkDirectionalParticleCanvasObject',
        'dagMode',
        'dagLevelDistance',
        'dagNodeFilter',
        'onDagError',
        'd3AlphaMin',
        'd3AlphaDecay',
        'd3VelocityDecay',
        'warmupTicks',
        'cooldownTicks',
        'cooldownTime',
        'onEngineTick',
        'onEngineStop',
      ].map(function (e) {
        return ye({}, e, oo.linkProp(e))
      })
    ).concat(
      ut(
        [
          'nodeRelSize',
          'nodeId',
          'nodeVal',
          'nodeVisibility',
          'linkSource',
          'linkTarget',
          'linkVisibility',
          'linkCurvature',
        ].map(function (e) {
          return ye({}, e, Jh.linkProp(e))
        })
      )
    )
  ),
  ed = Object.assign.apply(
    Object,
    ut(
      ['d3Force', 'd3ReheatSimulation', 'emitParticle'].map(function (e) {
        return ye({}, e, oo.linkMethod(e))
      })
    )
  )
function un(e) {
  if (e.canvas) {
    var n = e.canvas.width,
      r = e.canvas.height
    n === 300 && r === 150 && (n = r = 0)
    var i = window.devicePixelRatio
    ;((n /= i),
      (r /= i),
      [e.canvas, e.shadowCanvas].forEach(function (a) {
        ;((a.style.width = ''.concat(e.width, 'px')),
          (a.style.height = ''.concat(e.height, 'px')),
          (a.width = e.width * i),
          (a.height = e.height * i),
          !n && !r && a.getContext('2d').scale(i, i))
      }))
    var o = gt(e.canvas).k
    ;(e.zoom.translateBy(e.zoom.__baseElem, (e.width - n) / 2 / o, (e.height - r) / 2 / o),
      (e.needsRedraw = !0))
  }
}
function ao(e) {
  var n = window.devicePixelRatio
  e.setTransform(n, 0, 0, n, 0, 0)
}
function Kr(e, n, r) {
  ;(e.save(), ao(e), e.clearRect(0, 0, n, r), e.restore())
}
var nd = Dn({
  props: Ht(
    {
      width: {
        default: window.innerWidth,
        onChange: function (n, r) {
          return un(r)
        },
        triggerUpdate: !1,
      },
      height: {
        default: window.innerHeight,
        onChange: function (n, r) {
          return un(r)
        },
        triggerUpdate: !1,
      },
      graphData: {
        default: { nodes: [], links: [] },
        onChange: function (n, r) {
          ;([n.nodes, n.links].every(function (o) {
            return (o || []).every(function (a) {
              return !a.hasOwnProperty('__indexColor')
            })
          }) && r.colorTracker.reset(),
            [
              { type: 'Node', objs: n.nodes },
              { type: 'Link', objs: n.links },
            ].forEach(i),
            r.forceGraph.graphData(n),
            r.shadowGraph.graphData(n))
          function i(o) {
            var a = o.type,
              s = o.objs
            s.filter(function (u) {
              if (!u.hasOwnProperty('__indexColor')) return !0
              var l = r.colorTracker.lookup(u.__indexColor)
              return !l || !l.hasOwnProperty('d') || l.d !== u
            }).forEach(function (u) {
              u.__indexColor = r.colorTracker.register({ type: a, d: u })
            })
          }
        },
        triggerUpdate: !1,
      },
      backgroundColor: {
        onChange: function (n, r) {
          r.canvas && n && (r.canvas.style.background = n)
        },
        triggerUpdate: !1,
      },
      nodeLabel: { default: 'name', triggerUpdate: !1 },
      nodePointerAreaPaint: {
        onChange: function (n, r) {
          ;(r.shadowGraph.nodeCanvasObject(
            n
              ? function (i, o, a) {
                  return n(i, i.__indexColor, o, a)
                }
              : null
          ),
            r.flushShadowCanvas && r.flushShadowCanvas())
        },
        triggerUpdate: !1,
      },
      linkPointerAreaPaint: {
        onChange: function (n, r) {
          ;(r.shadowGraph.linkCanvasObject(
            n
              ? function (i, o, a) {
                  return n(i, i.__indexColor, o, a)
                }
              : null
          ),
            r.flushShadowCanvas && r.flushShadowCanvas())
        },
        triggerUpdate: !1,
      },
      linkLabel: { default: 'name', triggerUpdate: !1 },
      linkHoverPrecision: { default: 4, triggerUpdate: !1 },
      minZoom: {
        default: 0.01,
        onChange: function (n, r) {
          r.zoom.scaleExtent([n, r.zoom.scaleExtent()[1]])
        },
        triggerUpdate: !1,
      },
      maxZoom: {
        default: 1e3,
        onChange: function (n, r) {
          r.zoom.scaleExtent([r.zoom.scaleExtent()[0], n])
        },
        triggerUpdate: !1,
      },
      enableNodeDrag: { default: !0, triggerUpdate: !1 },
      enableZoomInteraction: { default: !0, triggerUpdate: !1 },
      enablePanInteraction: { default: !0, triggerUpdate: !1 },
      enableZoomPanInteraction: { default: !0, triggerUpdate: !1 },
      enablePointerInteraction: {
        default: !0,
        onChange: function (n, r) {
          r.hoverObj = null
        },
        triggerUpdate: !1,
      },
      autoPauseRedraw: { default: !0, triggerUpdate: !1 },
      onNodeDrag: { default: function () {}, triggerUpdate: !1 },
      onNodeDragEnd: { default: function () {}, triggerUpdate: !1 },
      onNodeClick: { triggerUpdate: !1 },
      onNodeRightClick: { triggerUpdate: !1 },
      onNodeHover: { triggerUpdate: !1 },
      onLinkClick: { triggerUpdate: !1 },
      onLinkRightClick: { triggerUpdate: !1 },
      onLinkHover: { triggerUpdate: !1 },
      onBackgroundClick: { triggerUpdate: !1 },
      onBackgroundRightClick: { triggerUpdate: !1 },
      showPointerCursor: { default: !0, triggerUpdate: !1 },
      onZoom: { triggerUpdate: !1 },
      onZoomEnd: { triggerUpdate: !1 },
      onRenderFramePre: { triggerUpdate: !1 },
      onRenderFramePost: { triggerUpdate: !1 },
    },
    td
  ),
  aliases: { stopAnimation: 'pauseAnimation' },
  methods: Ht(
    {
      graph2ScreenCoords: function (n, r, i) {
        var o = gt(n.canvas)
        return { x: r * o.k + o.x, y: i * o.k + o.y }
      },
      screen2GraphCoords: function (n, r, i) {
        var o = gt(n.canvas)
        return { x: (r - o.x) / o.k, y: (i - o.y) / o.k }
      },
      centerAt: function (n, r, i, o) {
        if (!n.canvas) return null
        if (r !== void 0 || i !== void 0) {
          var a = Object.assign({}, r !== void 0 ? { x: r } : {}, i !== void 0 ? { y: i } : {})
          return (
            o
              ? n.tweenGroup.add(new xr(s()).to(a, o).easing(Ft.Quadratic.Out).onUpdate(u).start())
              : u(a),
            this
          )
        }
        return s()
        function s() {
          var l = gt(n.canvas)
          return { x: (n.width / 2 - l.x) / l.k, y: (n.height / 2 - l.y) / l.k }
        }
        function u(l) {
          var f = l.x,
            h = l.y
          ;(n.zoom.translateTo(
            n.zoom.__baseElem,
            f === void 0 ? s().x : f,
            h === void 0 ? s().y : h
          ),
            (n.needsRedraw = !0))
        }
      },
      zoom: function (n, r, i) {
        if (!n.canvas) return null
        if (r !== void 0)
          return (
            i
              ? n.tweenGroup.add(
                  new xr({ k: o() })
                    .to({ k: r }, i)
                    .easing(Ft.Quadratic.Out)
                    .onUpdate(function (s) {
                      var u = s.k
                      return a(u)
                    })
                    .start()
                )
              : a(r),
            this
          )
        return o()
        function o() {
          return gt(n.canvas).k
        }
        function a(s) {
          ;(n.zoom.scaleTo(n.zoom.__baseElem, s), (n.needsRedraw = !0))
        }
      },
      zoomToFit: function (n) {
        for (
          var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0,
            i = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 10,
            o = arguments.length,
            a = new Array(o > 3 ? o - 3 : 0),
            s = 3;
          s < o;
          s++
        )
          a[s - 3] = arguments[s]
        var u = this.getGraphBbox.apply(this, a)
        if (u) {
          var l = { x: (u.x[0] + u.x[1]) / 2, y: (u.y[0] + u.y[1]) / 2 },
            f = Math.max(
              1e-12,
              Math.min(
                1e12,
                (n.width - i * 2) / (u.x[1] - u.x[0]),
                (n.height - i * 2) / (u.y[1] - u.y[0])
              )
            )
          ;(this.centerAt(l.x, l.y, r), this.zoom(f, r))
        }
        return this
      },
      getGraphBbox: function (n) {
        var r =
            arguments.length > 1 && arguments[1] !== void 0
              ? arguments[1]
              : function () {
                  return !0
                },
          i = q(n.nodeVal),
          o = function (u) {
            return Math.sqrt(Math.max(0, i(u) || 1)) * n.nodeRelSize
          },
          a = n.graphData.nodes.filter(r).map(function (s) {
            return { x: s.x, y: s.y, r: o(s) }
          })
        return a.length
          ? {
              x: [
                yr(a, function (s) {
                  return s.x - s.r
                }),
                gr(a, function (s) {
                  return s.x + s.r
                }),
              ],
              y: [
                yr(a, function (s) {
                  return s.y - s.r
                }),
                gr(a, function (s) {
                  return s.y + s.r
                }),
              ],
            }
          : null
      },
      pauseAnimation: function (n) {
        return (
          n.animationFrameRequestId &&
            (cancelAnimationFrame(n.animationFrameRequestId), (n.animationFrameRequestId = null)),
          this
        )
      },
      resumeAnimation: function (n) {
        return (n.animationFrameRequestId || this._animationCycle(), this)
      },
      _destructor: function () {
        ;(this.pauseAnimation(), this.graphData({ nodes: [], links: [] }))
      },
    },
    ed
  ),
  stateInit: function () {
    return {
      lastSetZoom: 1,
      zoom: sl(),
      forceGraph: new Ge(),
      shadowGraph: new Ge()
        .cooldownTicks(0)
        .nodeColor('__indexColor')
        .linkColor('__indexColor')
        .isShadow(!0),
      colorTracker: new Df(),
      tweenGroup: new Pi(),
    }
  },
  init: function (n, r) {
    var i = this
    n.innerHTML = ''
    var o = document.createElement('div')
    ;(o.classList.add('force-graph-container'),
      (o.style.position = 'relative'),
      n.appendChild(o),
      (r.canvas = document.createElement('canvas')),
      r.backgroundColor && (r.canvas.style.background = r.backgroundColor),
      o.appendChild(r.canvas),
      (r.shadowCanvas = document.createElement('canvas')))
    var a = r.canvas.getContext('2d'),
      s = r.shadowCanvas.getContext('2d', { willReadFrequently: !0 }),
      u = { x: -1e12, y: -1e12 },
      l = function () {
        var c = null,
          d = window.devicePixelRatio,
          p = u.x > 0 && u.y > 0 ? s.getImageData(u.x * d, u.y * d, 1, 1) : null
        return (p && (c = r.colorTracker.lookup(p.data)), c)
      }
    ;(st(r.canvas).call(
      _s()
        .subject(function () {
          if (!r.enableNodeDrag) return null
          var h = l()
          return h && h.type === 'Node' ? h.d : null
        })
        .on('start', function (h) {
          var c = h.subject
          ;((c.__initialDragPos = { x: c.x, y: c.y, fx: c.fx, fy: c.fy }),
            h.active || ((c.fx = c.x), (c.fy = c.y)),
            r.canvas.classList.add('grabbable'))
        })
        .on('drag', function (h) {
          var c = h.subject,
            d = c.__initialDragPos,
            p = h,
            y = gt(r.canvas).k,
            m = { x: d.x + (p.x - d.x) / y - c.x, y: d.y + (p.y - d.y) / y - c.y }
          ;(['x', 'y'].forEach(function (_) {
            return (c['f'.concat(_)] = c[_] = d[_] + (p[_] - d[_]) / y)
          }),
            !(
              !c.__dragged &&
              Qh >=
                Math.sqrt(
                  cl(
                    ['x', 'y'].map(function (_) {
                      return Math.pow(h[_] - d[_], 2)
                    })
                  )
                )
            ) &&
              (r.forceGraph.d3AlphaTarget(0.3).resetCountdown(),
              (r.isPointerDragging = !0),
              (c.__dragged = !0),
              r.onNodeDrag(c, m)))
        })
        .on('end', function (h) {
          var c = h.subject,
            d = c.__initialDragPos,
            p = { x: c.x - d.x, y: c.y - d.y }
          ;(d.fx === void 0 && (c.fx = void 0),
            d.fy === void 0 && (c.fy = void 0),
            delete c.__initialDragPos,
            r.forceGraph.d3AlphaTarget() && r.forceGraph.d3AlphaTarget(0).resetCountdown(),
            r.canvas.classList.remove('grabbable'),
            (r.isPointerDragging = !1),
            c.__dragged && (delete c.__dragged, r.onNodeDragEnd(c, p)))
        })
    ),
      r.zoom((r.zoom.__baseElem = st(r.canvas))),
      r.zoom.__baseElem.on('dblclick.zoom', null),
      r.zoom
        .filter(function (h) {
          return (
            !h.button &&
            r.enableZoomPanInteraction &&
            (h.type !== 'wheel' || q(r.enableZoomInteraction)(h)) &&
            (h.type === 'wheel' || q(r.enablePanInteraction)(h))
          )
        })
        .on('zoom', function (h) {
          var c = h.transform
          ;([a, s].forEach(function (d) {
            ;(ao(d), d.translate(c.x, c.y), d.scale(c.k, c.k))
          }),
            (r.isPointerDragging = !0),
            r.onZoom && r.onZoom(Ht(Ht({}, c), i.centerAt())),
            (r.needsRedraw = !0))
        })
        .on('end', function (h) {
          ;((r.isPointerDragging = !1),
            r.onZoomEnd && r.onZoomEnd(Ht(Ht({}, h.transform), i.centerAt())))
        }),
      un(r),
      r.forceGraph
        .onNeedsRedraw(function () {
          return (r.needsRedraw = !0)
        })
        .onFinishUpdate(function () {
          gt(r.canvas).k === r.lastSetZoom &&
            r.graphData.nodes.length &&
            (r.zoom.scaleTo(
              r.zoom.__baseElem,
              (r.lastSetZoom = Kh / Math.cbrt(r.graphData.nodes.length))
            ),
            (r.needsRedraw = !0))
        }),
      (r.tooltip = new ic(o)),
      ['pointermove', 'pointerdown'].forEach(function (h) {
        return o.addEventListener(
          h,
          function (c) {
            ;(h === 'pointerdown' && ((r.isPointerPressed = !0), (r.pointerDownEvent = c)),
              !r.isPointerDragging &&
                c.type === 'pointermove' &&
                r.onBackgroundClick &&
                (c.pressure > 0 || r.isPointerPressed) &&
                (c.pointerType === 'mouse' ||
                  c.movementX === void 0 ||
                  [c.movementX, c.movementY].some(function (y) {
                    return Math.abs(y) > 1
                  })) &&
                (r.isPointerDragging = !0))
            var d = p(o)
            ;((u.x = c.pageX - d.left), (u.y = c.pageY - d.top))
            function p(y) {
              var m = y.getBoundingClientRect(),
                _ = window.pageXOffset || document.documentElement.scrollLeft,
                g = window.pageYOffset || document.documentElement.scrollTop
              return { top: m.top + g, left: m.left + _ }
            }
          },
          { passive: !0 }
        )
      }),
      o.addEventListener(
        'pointerup',
        function (h) {
          if (r.isPointerPressed) {
            if (((r.isPointerPressed = !1), r.isPointerDragging)) {
              r.isPointerDragging = !1
              return
            }
            var c = [h, r.pointerDownEvent]
            requestAnimationFrame(function () {
              if (h.button === 0)
                if (r.hoverObj) {
                  var d = r['on'.concat(r.hoverObj.type, 'Click')]
                  d && d.apply(void 0, [r.hoverObj.d].concat(c))
                } else r.onBackgroundClick && r.onBackgroundClick.apply(r, c)
              if (h.button === 2)
                if (r.hoverObj) {
                  var p = r['on'.concat(r.hoverObj.type, 'RightClick')]
                  p && p.apply(void 0, [r.hoverObj.d].concat(c))
                } else r.onBackgroundRightClick && r.onBackgroundRightClick.apply(r, c)
            })
          }
        },
        { passive: !0 }
      ),
      o.addEventListener('contextmenu', function (h) {
        return !r.onBackgroundRightClick && !r.onNodeRightClick && !r.onLinkRightClick
          ? !0
          : (h.preventDefault(), !1)
      }),
      r.forceGraph(a),
      r.shadowGraph(s))
    var f = Hl(function () {
      ;(Kr(s, r.width, r.height),
        r.shadowGraph.linkWidth(function (c) {
          return q(r.linkWidth)(c) + r.linkHoverPrecision
        }))
      var h = gt(r.canvas)
      r.shadowGraph.globalScale(h.k).tickFrame()
    }, Zh)
    ;((r.flushShadowCanvas = f.flush),
      (this._animationCycle = function h() {
        var c =
          !r.autoPauseRedraw ||
          !!r.needsRedraw ||
          r.forceGraph.isEngineRunning() ||
          r.graphData.links.some(function (C) {
            return C.__photons && C.__photons.length
          })
        if (((r.needsRedraw = !1), r.enablePointerInteraction)) {
          var d = r.isPointerDragging ? null : l()
          if (d !== r.hoverObj) {
            var p = r.hoverObj,
              y = p ? p.type : null,
              m = d ? d.type : null
            if (y && y !== m) {
              var _ = r['on'.concat(y, 'Hover')]
              _ && _(null, p.d)
            }
            if (m) {
              var g = r['on'.concat(m, 'Hover')]
              g && g(d.d, y === m ? p.d : null)
            }
            ;(r.tooltip.content((d && q(r[''.concat(d.type.toLowerCase(), 'Label')])(d.d)) || null),
              r.canvas.classList[
                ((d && r['on'.concat(m, 'Click')]) || (!d && r.onBackgroundClick)) &&
                q(r.showPointerCursor)(d == null ? void 0 : d.d)
                  ? 'add'
                  : 'remove'
              ]('clickable'),
              (r.hoverObj = d))
          }
          c && f()
        }
        if (c) {
          Kr(a, r.width, r.height)
          var w = gt(r.canvas).k
          ;(r.onRenderFramePre && r.onRenderFramePre(a, w),
            r.forceGraph.globalScale(w).tickFrame(),
            r.onRenderFramePost && r.onRenderFramePost(a, w))
        }
        ;(r.tweenGroup.update(), (r.animationFrameRequestId = requestAnimationFrame(h)))
      })())
  },
  update: function (n) {},
})
const Ke = {
    width: v.number,
    height: v.number,
    graphData: v.shape({
      nodes: v.arrayOf(v.object).isRequired,
      links: v.arrayOf(v.object).isRequired,
    }),
    backgroundColor: v.string,
    nodeRelSize: v.number,
    nodeId: v.string,
    nodeLabel: v.oneOfType([v.string, v.func]),
    nodeVal: v.oneOfType([v.number, v.string, v.func]),
    nodeVisibility: v.oneOfType([v.bool, v.string, v.func]),
    nodeColor: v.oneOfType([v.string, v.func]),
    nodeAutoColorBy: v.oneOfType([v.string, v.func]),
    onNodeHover: v.func,
    onNodeClick: v.func,
    linkSource: v.string,
    linkTarget: v.string,
    linkLabel: v.oneOfType([v.string, v.func]),
    linkVisibility: v.oneOfType([v.bool, v.string, v.func]),
    linkColor: v.oneOfType([v.string, v.func]),
    linkAutoColorBy: v.oneOfType([v.string, v.func]),
    linkWidth: v.oneOfType([v.number, v.string, v.func]),
    linkCurvature: v.oneOfType([v.number, v.string, v.func]),
    linkDirectionalArrowLength: v.oneOfType([v.number, v.string, v.func]),
    linkDirectionalArrowColor: v.oneOfType([v.string, v.func]),
    linkDirectionalArrowRelPos: v.oneOfType([v.number, v.string, v.func]),
    linkDirectionalParticles: v.oneOfType([v.number, v.string, v.func]),
    linkDirectionalParticleSpeed: v.oneOfType([v.number, v.string, v.func]),
    linkDirectionalParticleOffset: v.oneOfType([v.number, v.string, v.func]),
    linkDirectionalParticleWidth: v.oneOfType([v.number, v.string, v.func]),
    linkDirectionalParticleColor: v.oneOfType([v.string, v.func]),
    onLinkHover: v.func,
    onLinkClick: v.func,
    dagMode: v.oneOf(['td', 'bu', 'lr', 'rl', 'zin', 'zout', 'radialin', 'radialout']),
    dagLevelDistance: v.number,
    dagNodeFilter: v.func,
    onDagError: v.func,
    d3AlphaMin: v.number,
    d3AlphaDecay: v.number,
    d3VelocityDecay: v.number,
    warmupTicks: v.number,
    cooldownTicks: v.number,
    cooldownTime: v.number,
    onEngineTick: v.func,
    onEngineStop: v.func,
    getGraphBbox: v.func,
  },
  so = {
    zoomToFit: v.func,
    onNodeRightClick: v.func,
    onNodeDrag: v.func,
    onNodeDragEnd: v.func,
    onLinkRightClick: v.func,
    linkHoverPrecision: v.number,
    onBackgroundClick: v.func,
    onBackgroundRightClick: v.func,
    showPointerCursor: v.oneOfType([v.bool, v.func]),
    enablePointerInteraction: v.bool,
    enableNodeDrag: v.bool,
  },
  Vn = {
    showNavInfo: v.bool,
    nodeOpacity: v.number,
    nodeResolution: v.number,
    nodeThreeObject: v.oneOfType([v.object, v.string, v.func]),
    nodeThreeObjectExtend: v.oneOfType([v.bool, v.string, v.func]),
    nodePositionUpdate: v.func,
    linkOpacity: v.number,
    linkResolution: v.number,
    linkCurveRotation: v.oneOfType([v.number, v.string, v.func]),
    linkMaterial: v.oneOfType([v.object, v.string, v.func]),
    linkThreeObject: v.oneOfType([v.object, v.string, v.func]),
    linkThreeObjectExtend: v.oneOfType([v.bool, v.string, v.func]),
    linkPositionUpdate: v.func,
    linkDirectionalArrowResolution: v.number,
    linkDirectionalParticleResolution: v.number,
    linkDirectionalParticleThreeObject: v.oneOfType([v.object, v.string, v.func]),
    forceEngine: v.oneOf(['d3', 'ngraph']),
    ngraphPhysics: v.object,
    numDimensions: v.oneOf([1, 2, 3]),
  },
  rd = Object.assign({}, Ke, so, {
    linkLineDash: v.oneOfType([v.arrayOf(v.number), v.string, v.func]),
    nodeCanvasObjectMode: v.oneOfType([v.string, v.func]),
    nodeCanvasObject: v.func,
    nodePointerAreaPaint: v.func,
    linkCanvasObjectMode: v.oneOfType([v.string, v.func]),
    linkCanvasObject: v.func,
    linkPointerAreaPaint: v.func,
    linkDirectionalParticleCanvasObject: v.func,
    autoPauseRedraw: v.bool,
    minZoom: v.number,
    maxZoom: v.number,
    enableZoomInteraction: v.oneOfType([v.bool, v.func]),
    enablePanInteraction: v.oneOfType([v.bool, v.func]),
    onZoom: v.func,
    onZoomEnd: v.func,
    onRenderFramePre: v.func,
    onRenderFramePost: v.func,
  })
Object.assign({}, Ke, so, Vn, {
  enableNavigationControls: v.bool,
  controlType: v.oneOf(['trackball', 'orbit', 'fly']),
  rendererConfig: v.object,
  extraRenderers: v.arrayOf(v.shape({ render: v.func.isRequired })),
})
Object.assign({}, Ke, Vn, {
  nodeDesc: v.oneOfType([v.string, v.func]),
  linkDesc: v.oneOfType([v.string, v.func]),
})
Object.assign({}, Ke, Vn, { markerAttrs: v.object, yOffset: v.number, glScale: v.number })
const uo = Po(nd, {
  methodNames: [
    'emitParticle',
    'd3Force',
    'd3ReheatSimulation',
    'stopAnimation',
    'pauseAnimation',
    'resumeAnimation',
    'centerAt',
    'zoom',
    'zoomToFit',
    'getGraphBbox',
    'screen2GraphCoords',
    'graph2ScreenCoords',
  ],
})
uo.displayName = 'ForceGraph2D'
uo.propTypes = rd
export { uo as default }
